(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,575,88],[377,351,304,56],[683,351,258,61],[779,0,209,110],[0,351,375,61],[320,90,237,61],[779,112,192,61],[0,200,364,80],[0,90,318,108],[366,235,420,56],[0,293,420,56],[422,293,420,56],[788,175,100,100],[890,175,100,100],[377,409,100,100],[479,409,100,100],[581,409,100,100],[577,0,200,233]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_101 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7copy = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CMNS50 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.g_title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_101();
	this.instance.setTransform(0,23.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_100();
	this.instance_1.setTransform(0,-3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-3,287.5,70.7);


(lib.g_SpeakerPic_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_99();
	this.instance.setTransform(-14.5,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap11();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.5,0,129,126.5);


(lib.g_SpeakerPic_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_98();
	this.instance.setTransform(-2.25,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap7copy();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,0,104.5,151);


(lib.g_SpeakerPic_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_97();
	this.instance.setTransform(-43.65,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap9();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.6,0,187.5,126.5);


(lib.g_SpeakerPic_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_96();
	this.instance.setTransform(-9.2,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap8();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,0,118.5,126.5);


(lib.g_SpeakerPic_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_95();
	this.instance.setTransform(2.1,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap10();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,126.5);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_94();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182,40);


(lib.g_Logo_CMNS50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CMNS50();
	this.instance.setTransform(-10,-12,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-12,100,116.5);


(lib.g_contenttxt_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_93();
	this.instance.setTransform(-2,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,0,159,54);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_90();
	this.instance.setTransform(0,7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_91();
	this.instance_1.setTransform(0,7,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_92();
	this.instance_2.setTransform(0,7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0633").ss(1,1,1).p("AwZjHMAgzAAAIAAGPMggzAAAg");
	this.shape.setTransform(105,20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AwZDIIAAmPMAgzAAAIAAGPg");
	this.shape_1.setTransform(105,20);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AwZDIIAAmPMAgzAAAIAAGPg");
	this.shape_2.setTransform(105,20);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#CC0633").ss(1,1,1).p("AwZjRMAgzAAAIAAGjMggzAAAg");
	this.shape_3.setTransform(105,21);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AwZDSIAAmjMAgzAAAIAAGjg");
	this.shape_4.setTransform(105,21);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("AwZDSIAAmjMAgzAAAIAAGjg");
	this.shape_5.setTransform(105,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,212,44);


// stage content:
(lib.cmns50th_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("synched",0);
	this.instance.setTransform(112,-21.9,1,1,0,0,0,82,18.1);
	this.instance._off = true;
	var instanceFilter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-2,-2,186,44);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({y:18.1},24,cjs.Ease.get(1)).to({_off:true},260).wait(6));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(1).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(1)).wait(6));

	// Logo_CMNS50
	this.instance_1 = new lib.g_Logo_CMNS50("synched",0);
	this.instance_1.setTransform(266,69.1,0.6,0.6,0,0,0,82.2,30.1);
	this.instance_1._off = true;
	var instance_1Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-12,-14,104,121);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(38).to({_off:false},0).to({regY:30.2,x:265.95,y:79.1},21,cjs.Ease.get(1)).wait(203).to({startPosition:0},0).to({x:275.95},22,cjs.Ease.get(1)).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(38).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 21,cjs.Ease.get(1)).wait(203).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(1)).wait(6));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("AgYTiMAAAgnDIAxAAMAAAAnDg");
	var mask_graphics_18 = new cjs.Graphics().p("Aj7zhIH3CeMgFEAiiIizCDg");
	var mask_graphics_19 = new cjs.Graphics().p("AnWzhIOtE2Ip+eNIkvEAg");
	var mask_graphics_20 = new cjs.Graphics().p("AqlzhIVMHHIupaFImjF3g");
	var mask_graphics_21 = new cjs.Graphics().p("AtszhIbZJSIzFWIIoUHpg");
	var mask_graphics_22 = new cjs.Graphics().p("AwpzhMAhTALVI3USZIp/JVg");
	var mask_graphics_23 = new cjs.Graphics().p("AzczhMAm5ANSI7VO1IrkK8g");
	var mask_graphics_24 = new cjs.Graphics().p("AzTzhMAmnAMaI62T6IrxGvg");
	var mask_graphics_25 = new cjs.Graphics().p("AzKzhMAmVALkI6XYyIr+Ctg");
	var mask_graphics_26 = new cjs.Graphics().p("AzBS7MAAAgnDMAmDAKxI56dgg");
	var mask_graphics_27 = new cjs.Graphics().p("Ay4RDMAAAgnDMAlxAJ+MgZdAiDg");
	var mask_graphics_28 = new cjs.Graphics().p("AyxPPMAAAgnDMAliAJOMgZCAmbg");
	var mask_graphics_29 = new cjs.Graphics().p("AyUQaIgQgzMAAAgnxIe6GgIGPD1ImINdIpNR9In9Gmg");
	var mask_graphics_30 = new cjs.Graphics().p("Ax5RhIgfgrMAAAgpUMAgSAF1IEfFjIkYOiIn0TYIpcDrg");
	var mask_graphics_31 = new cjs.Graphics().p("AxhSiIgtgiMAAAgqxMAhlAFNIC3HJIiwPkImiUrIq1A+g");
	var mask_graphics_32 = new cjs.Graphics().p("AgpYSIwhlkIg6gbMAAAgsGMAivAEoIBZImIhSQhIlUV4g");
	var mask_graphics_33 = new cjs.Graphics().p("Ax8SIMAAAgtTMAjzAEGIAGZHIABCMIkPW+g");
	var mask_graphics_34 = new cjs.Graphics().p("AyLTtIhdi7MAAAgqxMAlWAC3IB3DsIAEW3IiaTsIiAC5g");
	var mask_graphics_35 = new cjs.Graphics().p("AyWU/Iiph3MAAAgsIMAmmAB0IDXCYIACXlIhiUaIjAB2g");
	var mask_graphics_36 = new cjs.Graphics().p("AyfV/IjkhCMAAAgtNMAnkABCIEiBVIABYKIg3U9IjyBCg");
	var mask_graphics_37 = new cjs.Graphics().p("AymWtIkOgeMAAAgt8MAoSAAdIFWAmIABYkIgZVWIkVAeg");
	var mask_graphics_38 = new cjs.Graphics().p("AyqXJIkngHMAAAguaMAosAAIIF3AJIAAWVIgGYEIkrAHg");
	var mask_graphics_39 = new cjs.Graphics().p("A3bXSMAAAgujMAu3AAAMAAAAujg");
	var mask_graphics_249 = new cjs.Graphics().p("A3CT7Igy5gIAyvHIW7gyIX8AyIAAM7IAAceI3aAyg");
	var mask_graphics_250 = new cjs.Graphics().p("A13TmIhb4PICKvYIVdhGIW9AyIgGM7IgFb8I2aAmg");
	var mask_graphics_251 = new cjs.Graphics().p("A0sTSIiD2/IDgvpIUAhaIV/AzIgNM7IgKbZI1cAag");
	var mask_graphics_252 = new cjs.Graphics().p("AziS9Iir1vIE2v6ISlhtIVAAzIgUM7IgOa3I0eAOg");
	var mask_graphics_253 = new cjs.Graphics().p("AyZSpIjT0gIGLwLIRLiBIUDA0IgbM7IgTaVIzgADg");
	var mask_graphics_254 = new cjs.Graphics().p("ABwTpIzAhYIj7zTIHewbIPyiUITGA0IggM7IgYZ0g");
	var mask_graphics_255 = new cjs.Graphics().p("ACATNIyJhWIkgyGIIwwrIOainISKA1IgoM7IgcZTg");
	var mask_graphics_256 = new cjs.Graphics().p("ACQSyIxThUIlGw6IKDw7INBi6IRPA2IguM7IggYyg");
	var mask_graphics_257 = new cjs.Graphics().p("ACgSXIwdhSIlsvvILVxKILqjNIQUA2Ig1M7IglYSg");
	var mask_graphics_258 = new cjs.Graphics().p("ACwR8IvnhQImSukIMlxaIKVjfIPZA2Ig7M7IgpXyg");
	var mask_graphics_259 = new cjs.Graphics().p("AFkSEIlKgKIp8hEIjaj9IlOnbIKgtpICAi9IIhlNIGeh0IHQAbIBmEOIgIGjIACD7IgdTIIlICEg");
	var mask_graphics_260 = new cjs.Graphics().p("AmqQ3IkbiZIgNgJImVltIKos4IB2i7IGum6IFBkCIHBAdIDnCSIAOGWIAMDzIgYShIinEjIrtATg");
	var mask_graphics_261 = new cjs.Graphics().p("ApSP5IgPgFInlkOIKtsGIKQxuIMYA4IA4JzIgZY7IrVA2g");
	var mask_graphics_262 = new cjs.Graphics().p("Aj3Q2IjrglIgOgEInbjaIH/sXIBBiQIC/mMIFEonIGgg7IEkAWIB5FWIAQCsIAHI5IgWOzIolC9IgdAEg");
	var mask_graphics_263 = new cjs.Graphics().p("Al3QwIgOgDInQioIFTsmIAriOICWmDIE5oJIFZiXIEVAXIDKDtIAQCjIAWIcIgcODIl1FDIgUANIpJAPg");
	var mask_graphics_264 = new cjs.Graphics().p("AkOQ5InTh5ICps1IAWiMIBsl7IEtnqIEVjyIEGAWIEaCHIAQCbIAmH+IgiNTIjTHeIooBKg");
	var mask_graphics_265 = new cjs.Graphics().p("AlnQjIkHgoIABvOIBElzIHzsZIJfA5IBGJzIhGWOIj6BAIggAIIjuA9g");
	var mask_graphics_266 = new cjs.Graphics().p("AptPqIABszIADiQIABgDIAtj2IAchzIHQriIAigmIJLA3IALADIBFJsIhCUsIgQBIIoCCBg");
	var mask_graphics_267 = new cjs.Graphics().p("AptPaIABsqIAIiOIABgDIAsj0IAihvIHMrZIAkgeIJFA3IAJAEIBFJmIhCUdIgcA+InQB2IgtAFg");
	var mask_graphics_268 = new cjs.Graphics().p("AptPJIABshIAMiMIABgDIAsjxIAohrIHHrSIAogUII/A2IAHAGIBEJeIAAAeIhDTxIgoAzInLB2IgsACg");
	var mask_graphics_269 = new cjs.Graphics().p("AAFQYIpyhgIABsYIAQiKIABgDIArjvIAvhmIHBrKIAsgMII5A1IAFAIIBDJYIABAeIhETiIg0AoInFB0g");
	var mask_graphics_270 = new cjs.Graphics().p("ApuOmIACsPIAUiIIABgDIArjsIA1hiIG8rDIAvgDIIzA1IACAKIBGJuIhGTUIhAAeInAByg");
	var mask_graphics_271 = new cjs.Graphics().p("AOTSaIgagEIABsGIAZiJIArjqIHzsYIJgA5IBGJzIhGTGIoICEg");
	var mask_graphics_272 = new cjs.Graphics().p("ApUObIgagEIABsGIAZiKIArjpIHzsZIJfA5IBGJzIhGTGIoICFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:-2.5,y:110}).wait(1).to({graphics:mask_graphics_18,x:20.65,y:110}).wait(1).to({graphics:mask_graphics_19,x:42.85,y:110}).wait(1).to({graphics:mask_graphics_20,x:64.05,y:110}).wait(1).to({graphics:mask_graphics_21,x:84.275,y:110}).wait(1).to({graphics:mask_graphics_22,x:103.5,y:110}).wait(1).to({graphics:mask_graphics_23,x:121.725,y:110}).wait(1).to({graphics:mask_graphics_24,x:120.975,y:110}).wait(1).to({graphics:mask_graphics_25,x:120.225,y:110}).wait(1).to({graphics:mask_graphics_26,x:119.55,y:113.875}).wait(1).to({graphics:mask_graphics_27,x:118.85,y:125.925}).wait(1).to({graphics:mask_graphics_28,x:118.2,y:137.525}).wait(1).to({graphics:mask_graphics_29,x:117.2,y:139.7}).wait(1).to({graphics:mask_graphics_30,x:116.275,y:141.725}).wait(1).to({graphics:mask_graphics_31,x:115.4,y:143.575}).wait(1).to({graphics:mask_graphics_32,x:114.6,y:150.175}).wait(1).to({graphics:mask_graphics_33,x:114.1,y:159.025}).wait(1).to({graphics:mask_graphics_34,x:125.075,y:151.375}).wait(1).to({graphics:mask_graphics_35,x:134.025,y:145.125}).wait(1).to({graphics:mask_graphics_36,x:141.025,y:140.25}).wait(1).to({graphics:mask_graphics_37,x:146,y:136.775}).wait(1).to({graphics:mask_graphics_38,x:149.025,y:134.7}).wait(1).to({graphics:mask_graphics_39,x:150,y:134}).wait(210).to({graphics:mask_graphics_249,x:147.5,y:127.5}).wait(1).to({graphics:mask_graphics_250,x:151.85,y:129.975}).wait(1).to({graphics:mask_graphics_251,x:156.175,y:132.4}).wait(1).to({graphics:mask_graphics_252,x:160.45,y:134.825}).wait(1).to({graphics:mask_graphics_253,x:164.675,y:137.175}).wait(1).to({graphics:mask_graphics_254,x:168.85,y:140}).wait(1).to({graphics:mask_graphics_255,x:173,y:142.925}).wait(1).to({graphics:mask_graphics_256,x:177.1,y:145.775}).wait(1).to({graphics:mask_graphics_257,x:181.15,y:148.625}).wait(1).to({graphics:mask_graphics_258,x:185.15,y:151.45}).wait(1).to({graphics:mask_graphics_259,x:188.3,y:149.475}).wait(1).to({graphics:mask_graphics_260,x:194.05,y:148.475}).wait(1).to({graphics:mask_graphics_261,x:200.025,y:148.35}).wait(1).to({graphics:mask_graphics_262,x:218.625,y:150.7}).wait(1).to({graphics:mask_graphics_263,x:237.475,y:152.35}).wait(1).to({graphics:mask_graphics_264,x:256.175,y:156.25}).wait(1).to({graphics:mask_graphics_265,x:274.675,y:160.075}).wait(1).to({graphics:mask_graphics_266,x:289.75,y:158.9}).wait(1).to({graphics:mask_graphics_267,x:304.775,y:157.675}).wait(1).to({graphics:mask_graphics_268,x:319.775,y:156.5}).wait(1).to({graphics:mask_graphics_269,x:334.775,y:155.375}).wait(1).to({graphics:mask_graphics_270,x:349.75,y:154.35}).wait(1).to({graphics:mask_graphics_271,x:213.475,y:127.525}).wait(1).to({graphics:mask_graphics_272,x:364.675,y:153.075}).wait(19));

	// Pattern_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA3932").s().p("ABtGYQhIAAg/gbQhCgbgygxQgugugag7Qgag5gFg+IgCAAQgEhcgnhTQgmhQhBg+QhBg9hSgiQhVgjhdAAIsMAAIAAgqIMMABQBnAABeAnQBdAmBJBJQBEBFAnBWQAlBWAGBdIABAAQAFA9AaA1QAaA0ArAoQArAoA2AWQA3AWA9ABIVuAAIAAAog");
	this.shape.setTransform(149.875,105.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BC2939").s().p("ABsGZQhXAAhOghQhQghg9g+Qg5g5gghJQghhHgEhPIgCAAQgFhKgghFQgghCg2gzQg2gzhEgbQhGgdhNAAIsMAAIAAgqIMMABQBXAABPAgQBQAhA9A+QA6A5AgBJQAgBHAFBPIABAAQAFBKAgBFQAgBCA2AzQA2AzBEAbQBFAdBNAAIVvAAIAAAqg");
	this.shape_1.setTransform(149.875,112.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BE4F31").s().p("ABsGZQhmAAhdgnQhegnhJhJQhEhEgnhXQglhWgFhdIgBAAQgFg8gbg2QgZg0grgoQgrgog2gVQg4gXg9AAIsMAAIAAgqIMMABQBHAABBAbQBBAbAzAyQAuAuAaA6QAaA5AFA/IABAAQAEBbAnBSQAmBRBBA+QBBA9BSAiQBVAjBcAAIVvAAIAAAqg");
	this.shape_2.setTransform(149.875,120.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EAA93B").s().p("ABtI4Qh4AAhvgvQhrgthShSQhShSgthsQgqhigEhrIAAAAQgFgpgTglQgUgmgfgdQgggdgogQQgpgQgsAAIsOAAIAAgpIMOABQA0gBAxAUQAvATAmAiQAlAiAXAuQAYAuAEAzIAAAAQAFBqAsBgQAsBgBMBJQBMBJBhAnQBkAqBtAAIVuAAIAAApgABtD5Qg1AAgxgTQgugTgmgjQglghgXguQgXgtgFgyIgBAAQgEhrguhiQgshghLhIQhNhJhggoQhlgphtAAIsMgBIAAgpIMMAAQB4AABvAwQBrAtBSBSQBTBSAtBrQApBhAFBpIAAAAQAFArAUAnQAUAmAgAdQAfAcAnAQQApAQAtAAIVuAAIAAApg");
	this.shape_3.setTransform(149.875,112.95);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},17).to({state:[]},255).to({state:[]},1).wait(18));

	// SpeakerPic_5
	this.instance_2 = new lib.g_SpeakerPic_5("synched",0);
	this.instance_2.setTransform(145.95,362.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_2._off = true;
	var instance_2Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_3];
	this.instance_2.cache(-16,-2,133,131);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(100).to({_off:false},0).to({x:146.95,y:345.8},20,cjs.Ease.get(1)).wait(143).to({startPosition:0},0).to({x:147.95,y:330.8},22,cjs.Ease.get(0.8)).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_3).wait(100).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(1)).wait(143).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(0.8)).wait(5));

	// SpeakerPic_4
	this.instance_3 = new lib.g_SpeakerPic_1("synched",0);
	this.instance_3.setTransform(202.95,392.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_3._off = true;
	var instance_3Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_4];
	this.instance_3.cache(-2,-2,104,131);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(94).to({_off:false},0).to({x:228.95,y:427.7},20,cjs.Ease.get(1)).wait(149).to({startPosition:0},0).to({x:262.95,y:402.7},22,cjs.Ease.get(0.8)).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_4).wait(94).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(1)).wait(149).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(0.8)).wait(5));

	// SpeakerPic_3
	this.instance_4 = new lib.g_SpeakerPic_3("synched",0);
	this.instance_4.setTransform(66.95,392.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_4._off = true;
	var instance_4Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_5];
	this.instance_4.cache(-46,-2,192,131);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(88).to({_off:false},0).to({x:72.95,y:427.7},22,cjs.Ease.get(1)).wait(153).to({startPosition:0},0).to({x:56.95,y:412.7},22,cjs.Ease.get(0.8)).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_5).wait(88).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 22,cjs.Ease.get(1)).wait(153).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(0.8)).wait(5));

	// SpeakerPic_2
	this.instance_5 = new lib.g_SpeakerPic_2("synched",0);
	this.instance_5.setTransform(202.95,296.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_5._off = true;
	var instance_5Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_6];
	this.instance_5.cache(-11,-2,123,131);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(82).to({_off:false},0).to({x:231.95,y:281.7},24,cjs.Ease.get(1)).wait(157).to({startPosition:0},0).to({x:252.95,y:276.7},22,cjs.Ease.get(0.8)).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_6).wait(82).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(1)).wait(157).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(0.8)).wait(5));

	// SpeakerPic_1
	this.instance_6 = new lib.g_SpeakerPic_4("synched",0);
	this.instance_6.setTransform(66.95,296.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_6._off = true;
	var instance_6Filter_7 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_6.filters = [instance_6Filter_7];
	this.instance_6.cache(-4,-2,109,155);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(75).to({_off:false},0).to({x:65.95,y:282.7},26,cjs.Ease.get(1)).wait(162).to({startPosition:0},0).to({x:56.95,y:276.7},22,cjs.Ease.get(0.8)).to({_off:true},1).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_7).wait(75).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 26,cjs.Ease.get(1)).wait(162).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22,cjs.Ease.get(0.8)).wait(5));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_48 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(48).to({graphics:mask_1_graphics_48,x:150,y:300}).wait(243));

	// Text_1
	this.instance_7 = new lib.g_title_1("synched",0);
	this.instance_7.setTransform(-152.95,205.9,1,1,0,0,0,111.3,31.4);
	this.instance_7._off = true;
	var instance_7Filter_8 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_7.filters = [instance_7Filter_8];
	this.instance_7.cache(-2,-5,292,75);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(48).to({_off:false},0).to({x:117.45},20,cjs.Ease.get(0.9)).wait(184).to({startPosition:0},0).to({x:131.3},22).to({_off:true},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(instance_7Filter_8).wait(48).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(0.9)).wait(184).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 22).wait(16));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_102 = new cjs.Graphics().p("EgV0AsnIAA+AMAtTAAAIAAeAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(102).to({graphics:mask_2_graphics_102,x:150.275,y:285.525}).wait(189));

	// Text_2
	this.instance_8 = new lib.g_contenttxt_1("synched",0);
	this.instance_8.setTransform(-172.6,531.15,1,1,0,0,0,96.5,45);
	this.instance_8._off = true;
	var instance_8Filter_9 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_8.filters = [instance_8Filter_9];
	this.instance_8.cache(-4,-2,163,58);

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(102).to({_off:false},0).to({x:168.95},25,cjs.Ease.get(1)).wait(133).to({startPosition:0},0).to({x:148.95},24).to({_off:true},1).wait(6));
	this.timeline.addTween(cjs.Tween.get(instance_8Filter_9).wait(102).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 25,cjs.Ease.get(1)).wait(133).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 24).wait(6));

	// btn_CTA
	this.instance_9 = new lib.btn_CTA();
	this.instance_9.setTransform(45,557);
	this.instance_9.alpha = 0.8984;
	this.instance_9._off = true;
	var instance_9Filter_10 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_9.filters = [instance_9Filter_10];
	this.instance_9.cache(-3,-3,216,48);
	new cjs.ButtonHelper(this.instance_9, 0, 1, 2, false, new lib.btn_CTA(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(123).to({_off:false},0).to({y:547,alpha:1},23,cjs.Ease.get(1)).wait(145));
	this.timeline.addTween(cjs.Tween.get(instance_9Filter_10).wait(123).to(new cjs.ColorFilter(1,1,1,1,255,255,100,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 23,cjs.Ease.get(1)).wait(145));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance, startFrame:1, endFrame:1, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:0, endFrame:0, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:2, endFrame:25, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance_1, startFrame:38, endFrame:38, x:-12, y:-14, w:104, h:121});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-12, y:-14, w:104, h:121});
	this.filterCacheList.push({instance: this.instance_1, startFrame:39, endFrame:59, x:-12, y:-14, w:104, h:121});
	this.filterCacheList.push({instance: this.instance_1, startFrame:262, endFrame:262, x:-12, y:-14, w:104, h:121});
	this.filterCacheList.push({instance: this.instance_1, startFrame:263, endFrame:284, x:-12, y:-14, w:104, h:121});
	this.filterCacheList.push({instance: this.instance_2, startFrame:100, endFrame:100, x:-16, y:-2, w:133, h:131});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-16, y:-2, w:133, h:131});
	this.filterCacheList.push({instance: this.instance_2, startFrame:101, endFrame:120, x:-16, y:-2, w:133, h:131});
	this.filterCacheList.push({instance: this.instance_2, startFrame:263, endFrame:263, x:-16, y:-2, w:133, h:131});
	this.filterCacheList.push({instance: this.instance_2, startFrame:264, endFrame:285, x:-16, y:-2, w:133, h:131});
	this.filterCacheList.push({instance: this.instance_3, startFrame:94, endFrame:94, x:-2, y:-2, w:104, h:131});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:104, h:131});
	this.filterCacheList.push({instance: this.instance_3, startFrame:95, endFrame:114, x:-2, y:-2, w:104, h:131});
	this.filterCacheList.push({instance: this.instance_3, startFrame:263, endFrame:263, x:-2, y:-2, w:104, h:131});
	this.filterCacheList.push({instance: this.instance_3, startFrame:264, endFrame:285, x:-2, y:-2, w:104, h:131});
	this.filterCacheList.push({instance: this.instance_4, startFrame:88, endFrame:88, x:-46, y:-2, w:192, h:131});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-46, y:-2, w:192, h:131});
	this.filterCacheList.push({instance: this.instance_4, startFrame:89, endFrame:110, x:-46, y:-2, w:192, h:131});
	this.filterCacheList.push({instance: this.instance_4, startFrame:263, endFrame:263, x:-46, y:-2, w:192, h:131});
	this.filterCacheList.push({instance: this.instance_4, startFrame:264, endFrame:285, x:-46, y:-2, w:192, h:131});
	this.filterCacheList.push({instance: this.instance_5, startFrame:82, endFrame:82, x:-11, y:-2, w:123, h:131});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-11, y:-2, w:123, h:131});
	this.filterCacheList.push({instance: this.instance_5, startFrame:83, endFrame:106, x:-11, y:-2, w:123, h:131});
	this.filterCacheList.push({instance: this.instance_5, startFrame:263, endFrame:263, x:-11, y:-2, w:123, h:131});
	this.filterCacheList.push({instance: this.instance_5, startFrame:264, endFrame:285, x:-11, y:-2, w:123, h:131});
	this.filterCacheList.push({instance: this.instance_6, startFrame:75, endFrame:75, x:-4, y:-2, w:109, h:155});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-4, y:-2, w:109, h:155});
	this.filterCacheList.push({instance: this.instance_6, startFrame:76, endFrame:101, x:-4, y:-2, w:109, h:155});
	this.filterCacheList.push({instance: this.instance_6, startFrame:263, endFrame:263, x:-4, y:-2, w:109, h:155});
	this.filterCacheList.push({instance: this.instance_6, startFrame:264, endFrame:285, x:-4, y:-2, w:109, h:155});
	this.filterCacheList.push({instance: this.instance_7, startFrame:48, endFrame:48, x:-2, y:-5, w:292, h:75});
	this.filterCacheList.push({instance: this.instance_7, startFrame:0, endFrame:0, x:-2, y:-5, w:292, h:75});
	this.filterCacheList.push({instance: this.instance_7, startFrame:49, endFrame:68, x:-2, y:-5, w:292, h:75});
	this.filterCacheList.push({instance: this.instance_7, startFrame:252, endFrame:252, x:-2, y:-5, w:292, h:75});
	this.filterCacheList.push({instance: this.instance_7, startFrame:253, endFrame:274, x:-2, y:-5, w:292, h:75});
	this.filterCacheList.push({instance: this.instance_8, startFrame:102, endFrame:102, x:-4, y:-2, w:163, h:58});
	this.filterCacheList.push({instance: this.instance_8, startFrame:0, endFrame:0, x:-4, y:-2, w:163, h:58});
	this.filterCacheList.push({instance: this.instance_8, startFrame:103, endFrame:127, x:-4, y:-2, w:163, h:58});
	this.filterCacheList.push({instance: this.instance_8, startFrame:260, endFrame:260, x:-4, y:-2, w:163, h:58});
	this.filterCacheList.push({instance: this.instance_8, startFrame:261, endFrame:284, x:-4, y:-2, w:163, h:58});
	this.filterCacheList.push({instance: this.instance_9, startFrame:123, endFrame:123, x:-3, y:-3, w:216, h:48});
	this.filterCacheList.push({instance: this.instance_9, startFrame:0, endFrame:0, x:-3, y:-3, w:216, h:48});
	this.filterCacheList.push({instance: this.instance_9, startFrame:124, endFrame:146, x:-3, y:-3, w:216, h:48});
	this.filterCacheList.push({instance: this.instance_9, startFrame:146, endFrame:291, x:-3, y:-3, w:216, h:48});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,307.5,600);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 600,
	fps: 24,
	color: "#A6192E",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png?1697662733447", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;