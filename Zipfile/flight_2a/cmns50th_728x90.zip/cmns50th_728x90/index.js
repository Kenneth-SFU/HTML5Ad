(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,175,745,112],[366,289,304,56],[0,419,190,46],[628,351,274,46],[0,371,274,46],[832,453,174,46],[480,405,141,46],[0,289,364,80],[0,0,746,173],[747,235,260,56],[672,293,260,56],[366,347,260,56],[904,351,100,100],[628,399,100,100],[730,399,100,100],[276,405,100,100],[378,405,100,100],[748,0,200,233]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_89 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7copy = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CMNS50 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.g_title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_89();
	this.instance.setTransform(0,24.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_88();
	this.instance_1.setTransform(0,-1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1,372.5,81.7);


(lib.g_SpeakerPic_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_87();
	this.instance.setTransform(2.5,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap11();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,119);


(lib.g_SpeakerPic_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_86();
	this.instance.setTransform(-18.5,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap7copy();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.5,0,137,119);


(lib.g_SpeakerPic_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_85();
	this.instance.setTransform(-18.6,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap9();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.6,0,137,119);


(lib.g_SpeakerPic_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_84();
	this.instance.setTransform(6.45,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap8();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,119);


(lib.g_SpeakerPic_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Name
	this.instance = new lib.CachedBmp_83();
	this.instance.setTransform(14.65,96,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlgFhQiTiSAAjPQAAjOCTiTQCSiSDOAAQDPAACSCSQCTCTAADOQAADPiTCSQiSCTjPAAQjOAAiSiTg");
	mask.setTransform(50,50);

	// FlashAICB
	this.instance_1 = new lib.Bitmap10();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,119);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_82();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182,40);


(lib.g_Logo_CMNS50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CMNS50();
	this.instance.setTransform(0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,69.9);


(lib.g_contenttxt_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_81();
	this.instance.setTransform(0,4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,4,373,86.5);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_78();
	this.instance.setTransform(0,2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_79();
	this.instance_1.setTransform(0,2,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_80();
	this.instance_2.setTransform(0,2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0633").ss(1,1,1).p("AqJifIUTAAIAAE/I0TAAg");
	this.shape.setTransform(65,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_1.setTransform(65,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_2.setTransform(65,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,132,34);


// stage content:
(lib.cmns50th_728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask_Color
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,51,51,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(63,48,50,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_1.setTransform(364,45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(74,46,50,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_2.setTransform(364,45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(84,43,50,0.29)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_3.setTransform(364,45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(94,41,49,0.376)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_4.setTransform(364,45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(104,39,49,0.459)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_5.setTransform(364,45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(112,37,48,0.533)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_6.setTransform(364,45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(120,35,48,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_7.setTransform(364,45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(127,34,48,0.667)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_8.setTransform(364,45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(134,32,47,0.722)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_9.setTransform(364,45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(140,31,47,0.776)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_10.setTransform(364,45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(146,30,47,0.824)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_11.setTransform(364,45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(150,29,47,0.863)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_12.setTransform(364,45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(155,28,46,0.902)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_13.setTransform(364,45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(158,27,46,0.929)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_14.setTransform(364,45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(161,26,46,0.957)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_15.setTransform(364,45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(163,26,46,0.976)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_16.setTransform(364,45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(165,25,46,0.988)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_17.setTransform(364,45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(166,25,46,0.996)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_18.setTransform(364,45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#A6192E").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_19.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},438).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).wait(2));

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("synched",0);
	this.instance.setTransform(112,-21.9,1,1,0,0,0,82,18.1);
	this.instance._off = true;
	var instanceFilter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-2,-2,186,44);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({y:18.1},24,cjs.Ease.get(1)).wait(117).to({startPosition:0},0).to({x:102},36,cjs.Ease.get(0.5)).wait(73).to({startPosition:0},0).to({x:112},51,cjs.Ease.get(0.5)).to({_off:true},156).wait(1));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(1).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(1)).wait(117).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 36,cjs.Ease.get(0.5)).wait(73).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 51,cjs.Ease.get(0.5)).wait(1));

	// Logo_CMNS50
	this.instance_1 = new lib.g_Logo_CMNS50("synched",0);
	this.instance_1.setTransform(653,0);
	this.instance_1._off = true;
	var instance_1Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-2,-2,64,74);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(38).to({_off:false},0).to({y:10},18,cjs.Ease.get(1)).wait(83).to({x:658},0).to({x:668},21,cjs.Ease.get(1)).to({_off:true},1).wait(298));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(38).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(83).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 21,cjs.Ease.get(1)).wait(298));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("AgHHCIAAuDIAPAAIAAODg");
	var mask_graphics_18 = new cjs.Graphics().p("AhYnMICxAxIgBNSIiwAWg");
	var mask_graphics_19 = new cjs.Graphics().p("AimnXIFNBgIgEMjIlJAsg");
	var mask_graphics_20 = new cjs.Graphics().p("AjvnhIHfCMIgFL3InaBAg");
	var mask_graphics_21 = new cjs.Graphics().p("Ak0nqIJpC1IgGLOIpjBSg");
	var mask_graphics_22 = new cjs.Graphics().p("Al1nzILrDcIgIKnIrjBkg");
	var mask_graphics_23 = new cjs.Graphics().p("An4nzIPxDpIhcKnIuVBXg");
	var mask_graphics_24 = new cjs.Graphics().p("Ap2nzITtD1IisKmIxBBMg");
	var mask_graphics_25 = new cjs.Graphics().p("ArxnzIXjEBIj6KmIzpBAg");
	var mask_graphics_26 = new cjs.Graphics().p("AtpnzIbTEMIlHKmI2MA1g");
	var mask_graphics_27 = new cjs.Graphics().p("AvcnzIe6EYImRKlI4pAqg");
	var mask_graphics_28 = new cjs.Graphics().p("AxNnzMAiaAEjInXKkI7DAgg");
	var mask_graphics_29 = new cjs.Graphics().p("AxoE2IAAsaMAjRAFUIg1C+Il0GIIkqAeI3DARg");
	var mask_graphics_30 = new cjs.Graphics().p("AyZFZIAAsuMAkCAGAIAxCbImtFTIkuA1I3nAIg");
	var mask_graphics_31 = new cjs.Graphics().p("Aw7HJIikhRIAAtAMAkwAGqICPB5InhEkIkxBKg");
	var mask_graphics_32 = new cjs.Graphics().p("AxNG4IjTgnIAAtRMAlcAHPIDkBbIoRD5IkzBeg");
	var mask_graphics_33 = new cjs.Graphics().p("A1aGoIAAtgMAq1AIxIlsCEIoHC8g");
	var mask_graphics_34 = new cjs.Graphics().p("A1aGhIAAtgMAq1AIyIlMDHIomCGg");
	var mask_graphics_35 = new cjs.Graphics().p("A1ZGcIAAtgMAqzAIyIkyD+Io/BZg");
	var mask_graphics_36 = new cjs.Graphics().p("A1YGYIAAtgMAqxAIxIkdEqIpSA2g");
	var mask_graphics_37 = new cjs.Graphics().p("A1YGVIAAtgMAqxAIxIkPFIIpgAeg");
	var mask_graphics_38 = new cjs.Graphics().p("A1YGTIAAtgMAqxAIxIkGFbIppAPg");
	var mask_graphics_39 = new cjs.Graphics().p("A1YGSIAAtgMAqxAIyIkDFhIpsAKg");
	var mask_graphics_139 = new cjs.Graphics().p("AxLO2IomwIIj6nsINKnbMAuNAAZIAAMiIAATGI3aAyg");
	var mask_graphics_140 = new cjs.Graphics().p("AvsPBIpKu4IjloAINjofMAp7AAVIBWLhIADSgI1bCXg");
	var mask_graphics_141 = new cjs.Graphics().p("AuOPLIpttoIjRoUIN8pjMAlrAATICrKgIAHR5IzeD9g");
	var mask_graphics_142 = new cjs.Graphics().p("AsxPVIqQsYIi8opIOUqmMAhdAAQID/JgIALRTIxhFig");
	var mask_graphics_143 = new cjs.Graphics().p("ArVPfIqzrIIimo+IOrrpIdRAOIFTIhIAPQsIvlHGg");
	var mask_graphics_144 = new cjs.Graphics().p("Ap5PpIrVp6IiTpRIPDssIZJALIGmHhIARQIItqIog");
	var mask_graphics_145 = new cjs.Graphics().p("AoePzIr3osIh/plIPbttIVBAIIH4GjIAVPiIrwKKg");
	var mask_graphics_146 = new cjs.Graphics().p("AmqP+IsaneIidp5IQLusISqgGIH1FuIAZO9Ip4Lsg");
	var mask_graphics_147 = new cjs.Graphics().p("Ak4QNIs7mQIi7qOIQ6vpIQVgUIHyE4IAcOYIoANNg");
	var mask_graphics_148 = new cjs.Graphics().p("AwjLTIjYqiIRnwnIOCghIHvEEIAfN0ImIOsIw7ALg");
	var mask_graphics_149 = new cjs.Graphics().p("AvUMnIj1q1ISVxjILwgvIHrDPIAjNRIkSQKIwOAXg");
	var mask_graphics_150 = new cjs.Graphics().p("AuGN8IkRrJITCygIJfg8IHoCcIAmMsIidRoIviAjg");
	var mask_graphics_151 = new cjs.Graphics().p("As4PPIkurcITwzcIHOhJIHlBoIAqMJIgqTGIu2Aug");
	var mask_graphics_152 = new cjs.Graphics().p("AAEQQIleg1InUi+Ij6rfINnsbIC3iXID8iaIEwgUIB2ATIF0DEIAdL+IgYMpIhrEzIlpAUg");
	var mask_graphics_153 = new cjs.Graphics().p("Ah+PwIlWhEIlQk8IjHrgIN3rxIDAiBIEPhPIEqAJIBSA+IEGEfIAPLzIgVMeIjGDVIlkAXg");
	var mask_graphics_154 = new cjs.Graphics().p("Aj+PaIlPhSIjNm6IiUrjIOGrEIDKhsIEggEIElAmIAvBoICXF5IABAPIABLZIgRMTIkhB5IlfAYg");
	var mask_graphics_155 = new cjs.Graphics().p("Aq9OLIgOgEIit0bIOVqZIDUhXIJQCJIA4JzIgWUTIgEDEIrUA2g");
	var mask_graphics_156 = new cjs.Graphics().p("AkvPbIlTkDIgelMIiluQIMBlkICnhtIDJhZIEtAGIC8B7IAoGmIAICzIgiSHIhUDRIk3ApIl9ABg");
	var mask_graphics_157 = new cjs.Graphics().p("AhSPrIlAhCIiolsIgPk/IjJtfIMVisIClhfIC+hZIEYg/IBrC3IAqGUIgBCqIgvRVIikCHIkmA4g");
	var mask_graphics_158 = new cjs.Graphics().p("AjxOjIkHgpIABsGIjtsuIMpAKIJakuIBGJzIhGTGIj5BAIghAIIjtA8g");
	var mask_graphics_159 = new cjs.Graphics().p("AAxLFIjFinIhRgyImsmHIGUl2IAIgMIDWkWICtiaIDBA+IAbAMIEeFhIALGwIhiCGIifC3IlYEDg");
	var mask_graphics_160 = new cjs.Graphics().p("AlnO/IjtgkIgagEIABsGIAZiKIArjpIHzsZIJfA5IBGJzIhGTGIkaBIIjuA9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:-0.75,y:45}).wait(1).to({graphics:mask_graphics_18,x:7.125,y:46.125}).wait(1).to({graphics:mask_graphics_19,x:14.625,y:47.175}).wait(1).to({graphics:mask_graphics_20,x:21.7,y:48.175}).wait(1).to({graphics:mask_graphics_21,x:28.375,y:49.125}).wait(1).to({graphics:mask_graphics_22,x:34.625,y:50}).wait(1).to({graphics:mask_graphics_23,x:47.825,y:50}).wait(1).to({graphics:mask_graphics_24,x:60.625,y:50}).wait(1).to({graphics:mask_graphics_25,x:73.075,y:50}).wait(1).to({graphics:mask_graphics_26,x:85.175,y:50}).wait(1).to({graphics:mask_graphics_27,x:96.85,y:50}).wait(1).to({graphics:mask_graphics_28,x:108.2,y:50}).wait(1).to({graphics:mask_graphics_29,x:111.15,y:48.45}).wait(1).to({graphics:mask_graphics_30,x:116.35,y:47.025}).wait(1).to({graphics:mask_graphics_31,x:123.55,y:45.725}).wait(1).to({graphics:mask_graphics_32,x:130.2,y:44.9}).wait(1).to({graphics:mask_graphics_33,x:136.275,y:44.125}).wait(1).to({graphics:mask_graphics_34,x:136.35,y:44.775}).wait(1).to({graphics:mask_graphics_35,x:136.425,y:45.3}).wait(1).to({graphics:mask_graphics_36,x:136.475,y:45.725}).wait(1).to({graphics:mask_graphics_37,x:136.5,y:46.025}).wait(1).to({graphics:mask_graphics_38,x:136.525,y:46.2}).wait(1).to({graphics:mask_graphics_39,x:136.525,y:46.25}).wait(100).to({graphics:mask_graphics_139,x:110,y:145}).wait(1).to({graphics:mask_graphics_140,x:119.9,y:144.95}).wait(1).to({graphics:mask_graphics_141,x:129.725,y:144.875}).wait(1).to({graphics:mask_graphics_142,x:139.475,y:144.85}).wait(1).to({graphics:mask_graphics_143,x:149.15,y:144.775}).wait(1).to({graphics:mask_graphics_144,x:158.75,y:144.75}).wait(1).to({graphics:mask_graphics_145,x:168.275,y:144.675}).wait(1).to({graphics:mask_graphics_146,x:175.225,y:144.45}).wait(1).to({graphics:mask_graphics_147,x:182.125,y:143.85}).wait(1).to({graphics:mask_graphics_148,x:189,y:143.775}).wait(1).to({graphics:mask_graphics_149,x:195.8,y:143.775}).wait(1).to({graphics:mask_graphics_150,x:202.525,y:143.75}).wait(1).to({graphics:mask_graphics_151,x:209.225,y:143.75}).wait(1).to({graphics:mask_graphics_152,x:217.05,y:150.55}).wait(1).to({graphics:mask_graphics_153,x:224.775,y:157.025}).wait(1).to({graphics:mask_graphics_154,x:232.45,y:162.45}).wait(1).to({graphics:mask_graphics_155,x:240.65,y:164.25}).wait(1).to({graphics:mask_graphics_156,x:248,y:164.75}).wait(1).to({graphics:mask_graphics_157,x:255.275,y:163.425}).wait(1).to({graphics:mask_graphics_158,x:262.85,y:161.925}).wait(1).to({graphics:mask_graphics_159,x:311.6,y:161.65}).wait(1).to({graphics:mask_graphics_160,x:364.675,y:159.075}).wait(299));

	// Pattern_2
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DA3932").s().p("AVJGAQhDAAg9gZQg9gZgvgwQgsgrgZg3QgYg1gEg8IgCAAQgEhVglhOQgkhLg9g7Qg8g6hOggQhQgghYAAMgrJAABIAAgnMArJgABQBiAABYAkQBYAlBEBFQBABAAlBSQAjBQAGBYIAAAAQAEA4AZAzQAZAwAoAmQAoAmAzAUQA1AWA5gBINDAAIAAAng");
	this.shape_20.setTransform(126,93.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#EAA93B").s().p("AVJIWQhyAAhngsQhlgrhNhMQhNhOgrhlQgnhdgEhkIABAAQgFgngTgjQgSgkgegbQgegbgmgOQgmgPgpAAMgrMAABIAAgnMArMgABQAxAAAuASQAsASAjAgQAkAgAVArQAWAsAEAwIAAAAQAFBkApBaQAqBaBIBEQBHBFBbAlQBfAnBmAAINDAAIAAAngAVJDqQgxAAgvgSQgsgSgkggQgighgWgqQgVgqgFgvIgBAAQgEhlgrhcQgphahIhEQhHhFhbglQhegnhoAAMgrJAABIAAgnMArJgABQByAABpAsQBjArBOBMQBOBPAqBjQAnBcAEBjIABAAQAEAoATAlQASAkAeAbQAeAbAmAOQAnAPApAAINDAAIAAAng");
	this.shape_21.setTransform(126,101.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BE4F31").s().p("AVJGAQhhAAhYgkQhYglhEhEQhBhBgkhRQgjhRgFhYIgBAAQgFg4gYgzQgZgxgoglQgogmgzgUQg1gVg5AAMgrKAABIAAgnMArKgABQBDAAA9AZQA9AaAwAvQArArAYA3QAZA1AFA8IABAAQAEBVAkBOQAkBMA9A6QA9A6BNAfQBRAhBXAAINDAAIAAAng");
	this.shape_22.setTransform(126,108.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BC2939").s().p("AVJGAQhSAAhLgfQhKgfg6g6Qg2g2gfhDQgehEgEhKIgBAAQgFhGgfhAQgdg/gzgvQgygwhAgaQhDgbhJAAMgrJAABIAAgnMArJgABQBTAABKAfQBLAfA5A6QA2A2AfBDQAfBEAEBKIABAAQAEBGAfBBQAeA9AzAwQAyAwBAAaQBCAbBJAAINDAAIAAAng");
	this.shape_23.setTransform(126,101.2);

	var maskedShapeInstanceList = [this.shape_20,this.shape_21,this.shape_22,this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]},17).to({state:[]},144).wait(298));

	// SpeakerPic_5
	this.instance_2 = new lib.g_SpeakerPic_5("synched",0);
	this.instance_2.setTransform(712.9,38.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_2._off = true;
	var instance_2Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_3];
	this.instance_2.cache(-2,-2,104,123);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(188).to({_off:false},0).to({x:682.8},20,cjs.Ease.get(1)).wait(76).to({startPosition:0},0).to({y:8.7},16,cjs.Ease.get(0.8)).to({_off:true},1).wait(158));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_3).wait(188).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(1)).wait(76).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 16,cjs.Ease.get(0.8)).wait(158));

	// SpeakerPic_4
	this.instance_3 = new lib.g_SpeakerPic_1("synched",0);
	this.instance_3.setTransform(679.95,38.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_3._off = true;
	var instance_3Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_4];
	this.instance_3.cache(-2,-2,104,123);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(180).to({_off:false},0).to({x:581},20,cjs.Ease.get(1)).wait(76).to({startPosition:0},0).to({y:68.7},19,cjs.Ease.get(0.8)).to({_off:true},1).wait(163));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_4).wait(180).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(1)).wait(76).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 19,cjs.Ease.get(0.8)).wait(163));

	// SpeakerPic_3
	this.instance_4 = new lib.g_SpeakerPic_3("synched",0);
	this.instance_4.setTransform(679.85,38.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_4._off = true;
	var instance_4Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_5];
	this.instance_4.cache(-21,-2,141,123);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(174).to({_off:false},0).to({x:466.15},22,cjs.Ease.get(1)).wait(72).to({startPosition:0},0).to({y:8.7},24,cjs.Ease.get(0.8)).to({_off:true},1).wait(166));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_5).wait(174).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 22,cjs.Ease.get(1)).wait(72).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 24,cjs.Ease.get(0.8)).wait(166));

	// SpeakerPic_2
	this.instance_5 = new lib.g_SpeakerPic_2("synched",0);
	this.instance_5.setTransform(692.9,38.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_5._off = true;
	var instance_5Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_6];
	this.instance_5.cache(-2,-2,104,123);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(168).to({_off:false},0).to({x:361.25},24,cjs.Ease.get(1)).wait(68).to({startPosition:0},0).to({y:68.7},29,cjs.Ease.get(0.8)).to({_off:true},1).wait(169));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_6).wait(168).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(1)).wait(68).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 29,cjs.Ease.get(0.8)).wait(169));

	// SpeakerPic_1
	this.instance_6 = new lib.g_SpeakerPic_4("synched",0);
	this.instance_6.setTransform(692.9,38.7,0.701,0.7007,0,0,0,49.9,50);
	this.instance_6._off = true;
	var instance_6Filter_7 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_6.filters = [instance_6Filter_7];
	this.instance_6.cache(-20,-2,141,123);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(161).to({_off:false},0).to({x:263.4},26,cjs.Ease.get(1)).wait(64).to({startPosition:0},0).to({y:8.7},34,cjs.Ease.get(0.8)).to({_off:true},1).wait(173));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_7).wait(161).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 26,cjs.Ease.get(1)).wait(64).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 34,cjs.Ease.get(0.8)).wait(173));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_56 = new cjs.Graphics().p("Eg43ATiMAAAgnDMBxvAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(56).to({graphics:mask_1_graphics_56,x:364,y:125}).wait(403));

	// Text_1
	this.instance_7 = new lib.g_title_1("synched",0);
	this.instance_7.setTransform(255,29);
	this.instance_7._off = true;
	var instance_7Filter_8 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_7.filters = [instance_7Filter_8];
	this.instance_7.cache(-2,-3,377,86);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(37).to({_off:false},0).to({y:8},19,cjs.Ease.get(1)).wait(83).to({regX:111.3,regY:31.4,x:366.3,y:39.4},0).to({startPosition:0},20).to({_off:true},2).wait(298));
	this.timeline.addTween(cjs.Tween.get(instance_7Filter_8).wait(37).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(1)).wait(83).to(new cjs.ColorFilter(0,0,0,1,166,25,47,0), 20).wait(298));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_305 = new cjs.Graphics().p("A/AHCIAAuDMA+BAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(305).to({graphics:mask_2_graphics_305,x:436.025,y:45}).wait(154));

	// Text_2
	this.instance_8 = new lib.g_contenttxt_1("synched",0);
	this.instance_8.setTransform(-44.6,44.15,1,1,0,0,0,96.5,45);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(305).to({_off:false},0).to({x:344},25,cjs.Ease.get(1)).wait(26).to({startPosition:0},0).to({_off:true},102).wait(1));

	// btn_CTA
	this.instance_9 = new lib.btn_CTA();
	this.instance_9.setTransform(30,68);
	this.instance_9._off = true;
	var instance_9Filter_9 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_9.filters = [instance_9Filter_9];
	this.instance_9.cache(-3,-3,136,38);
	new cjs.ButtonHelper(this.instance_9, 0, 1, 2, false, new lib.btn_CTA(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(326).to({_off:false},0).to({y:58},23,cjs.Ease.get(1)).to({_off:true},109).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_9Filter_9).wait(326).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 23,cjs.Ease.get(1)).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance, startFrame:1, endFrame:1, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:0, endFrame:0, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:2, endFrame:25, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:142, endFrame:142, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:143, endFrame:178, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:251, endFrame:251, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance, startFrame:252, endFrame:302, x:-2, y:-2, w:186, h:44});
	this.filterCacheList.push({instance: this.instance_1, startFrame:38, endFrame:38, x:-2, y:-2, w:64, h:74});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-2, y:-2, w:64, h:74});
	this.filterCacheList.push({instance: this.instance_1, startFrame:39, endFrame:56, x:-2, y:-2, w:64, h:74});
	this.filterCacheList.push({instance: this.instance_1, startFrame:139, endFrame:139, x:-2, y:-2, w:64, h:74});
	this.filterCacheList.push({instance: this.instance_1, startFrame:140, endFrame:160, x:-2, y:-2, w:64, h:74});
	this.filterCacheList.push({instance: this.instance_2, startFrame:188, endFrame:188, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_2, startFrame:189, endFrame:208, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_2, startFrame:284, endFrame:284, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_2, startFrame:285, endFrame:300, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_3, startFrame:180, endFrame:180, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_3, startFrame:181, endFrame:200, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_3, startFrame:276, endFrame:276, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_3, startFrame:277, endFrame:295, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_4, startFrame:174, endFrame:174, x:-21, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-21, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_4, startFrame:175, endFrame:196, x:-21, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_4, startFrame:268, endFrame:268, x:-21, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_4, startFrame:269, endFrame:292, x:-21, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_5, startFrame:168, endFrame:168, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_5, startFrame:169, endFrame:192, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_5, startFrame:260, endFrame:260, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_5, startFrame:261, endFrame:289, x:-2, y:-2, w:104, h:123});
	this.filterCacheList.push({instance: this.instance_6, startFrame:161, endFrame:161, x:-20, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-20, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_6, startFrame:162, endFrame:187, x:-20, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_6, startFrame:251, endFrame:251, x:-20, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_6, startFrame:252, endFrame:285, x:-20, y:-2, w:141, h:123});
	this.filterCacheList.push({instance: this.instance_7, startFrame:37, endFrame:37, x:-2, y:-3, w:377, h:86});
	this.filterCacheList.push({instance: this.instance_7, startFrame:0, endFrame:0, x:-2, y:-3, w:377, h:86});
	this.filterCacheList.push({instance: this.instance_7, startFrame:38, endFrame:56, x:-2, y:-3, w:377, h:86});
	this.filterCacheList.push({instance: this.instance_7, startFrame:139, endFrame:139, x:-2, y:-3, w:377, h:86});
	this.filterCacheList.push({instance: this.instance_7, startFrame:140, endFrame:159, x:-2, y:-3, w:377, h:86});
	this.filterCacheList.push({instance: this.instance_9, startFrame:326, endFrame:326, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_9, startFrame:0, endFrame:0, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_9, startFrame:327, endFrame:349, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_9, startFrame:350, endFrame:458, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_9, startFrame:458, endFrame:459, x:-3, y:-3, w:136, h:38});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,748,154.7);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 728,
	height: 90,
	fps: 24,
	color: "#A6192E",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;