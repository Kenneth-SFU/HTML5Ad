(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.g_txt02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.text = new cjs.Text("Learn how we're building a better future, one breakthrough at a time.", "22px 'Lava FNI'", "#FFFFFF");
	this.text.lineHeight = 26;
	this.text.lineWidth = 416;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,420,61.1);


(lib.g_txt01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgvDYIAAlVIhFAAIAAhaIDpAAIAABaIhFAAIAAFVg");
	this.shape.setTransform(-61.5,29.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhFDYQgvgRAAg3IAAkfQAAg3AvgRICLAAQAvARAAA3IAABoIhgAAIAAhcIgGgGIgdAAIgGAGIAAEHIAGAGIAdAAIAGgGIAAhbIBgAAIAABnQAAA3gvARg");
	this.shape_1.setTransform(-86.7,29.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICBAAIA3FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_2.setTransform(-112.8,29.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ah0DYIAAmvIC6AAQAvARAAA3IAACKQAAA2gvARIhaAAIAACWgAgUgLIAjAAIAGgGIAAhyIgGgGIgjAAg");
	this.shape_3.setTransform(-138.3,29.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ABFDYIAAj1IgDAAIgeBfIhHAAIgehfIgDAAIAAD1IhaAAIAAmvIBpAAIAzCWIAFAAIAziWIBpAAIAAGvg");
	this.shape_4.setTransform(-168.9,29.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhBDYIAAhaIASAAIAAj7IgSAAIAAhaICDAAIAABaIgSAAIAAD7IASAAIAABag");
	this.shape_5.setTransform(-194.4,29.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhgDYIAAmvIBfAAIAAFVIBiAAIAABag");
	this.shape_6.setTransform(-221.85,29.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICBAAIA3FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_7.setTransform(-246,29.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhkDYIAAmvIDFAAIAABaIhkAAIAABOIBfAAIAABZIhfAAIAABUIBoAAIAABag");
	this.shape_8.setTransform(-270.45,29.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAnDYIg2ioIgLAAIAACoIhgAAIAAmvIC6AAQAvARAAA3IAABcQAAAzgoASIA0CKIAAA8gAgagdIAjAAIAGgGIAAhgIgGgGIgjAAg");
	this.shape_9.setTransform(-294.475,29.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAnDYIg2ioIgLAAIAACoIhgAAIAAmvIC6AAQAvARAAA3IAABcQAAAzgoASIA0CKIAAA8gAgagdIAjAAIAGgGIAAhgIgGgGIgjAAg");
	this.shape_10.setTransform(-329.725,29.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhFDYQgvgRAAg3IAAkfQAAg3AvgRICLAAQAvARAAA3IAAEfQAAA3gvARgAgUiDIAAEHIAGAGIAdAAIAGgGIAAkHIgGgGIgdAAg");
	this.shape_11.setTransform(-356.7,29.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AhiDYIAAmvIDFAAIAABaIhlAAIAABUIBfAAIAABZIhfAAIAACog");
	this.shape_12.setTransform(-381.3,29.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhBDYIAAhaIASAAIAAj7IgSAAIAAhaICDAAIAABaIgSAAIAAD7IASAAIAABag");
	this.shape_13.setTransform(-409.8,29.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICBAAIA3FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_14.setTransform(-430.8,29.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("EgjUAEuIAApcMBGpAAAIAAJcg");
	this.shape_15.setTransform(-226.1,30.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-452.2,0,452.2,65.5);


(lib.g_txt_connect_to_excellence = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVBGIAAgHIAIgBQAGgCAAgIIAAg9QAAgEgCgCQgBgCgEAAIgJABIAAgHQANgFAKAAQAKAAAAAMIAABEQAAAIAFACIAJABIAAAHgAgJgvQgEgDAAgHQAAgGAEgDQADgDAGAAQAEAAAEADQAEADAAAGQAAAHgEADQgEADgEAAQgGAAgDgDg");
	this.shape.setTransform(133.825,56.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAMAuQgDgDAAgIQgEAHgIAEQgHAEgIAAQgLAAgHgGQgHgHAAgLQAAgUAdgGIAXgGIAAgFQAAgNgEgFQgFgFgLAAQgNAAgRAEIAAgJQATgKAWAAQAcAAAAAhIAAAtQAAANANAAIAEAAIAAAFQgJADgJAAQgLAAgEgEgAgDAFQgMAEgFADQgFADAAAGQAAAPARAAQAIAAAJgFIAAgdg");
	this.shape_1.setTransform(126.2,58.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgjBgIA6i/IANAAIg6C/g");
	this.shape_2.setTransform(116.6,58.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AANAuQgEgDAAgIQgFAHgGAEQgIAEgJAAQgKAAgHgGQgIgHAAgLQAAgUAdgGIAYgGIAAgFQAAgNgEgFQgEgFgLAAQgOAAgRAEIAAgJQATgKAWAAQAbAAAAAhIAAAtQAAANAOAAIADAAIAAAFQgHADgKAAQgKAAgEgEgAgDAFQgMAEgEADQgGADAAAGQAAAPAQAAQAKAAAIgFIAAgdg");
	this.shape_3.setTransform(107.7,58.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcAmQgLgMAAgWQAAgYANgPQANgPAVAAQANAAAJAFQAKAFAAAIQAAAEgDADQgDADgEAAQgFAAgHgIQgHgJgKABQgKAAgHAJQgGAKAAARQAAAlAfAAQANAAAPgFIAAALQgOAKgVAAQgTAAgLgNg");
	this.shape_4.setTransform(97.775,59);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPAAQABgMAOAAQAQAAAAAMQAAANgQAAQgOAAgBgNg");
	this.shape_5.setTransform(90.15,62.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgnASIAAgxIgBgGQgBgCgFAAIgJABIAAgHQAOgFAKAAQALAAAAAMIAAA0QAAALAEAFQAFAFALABQAIgBANgEIAAg+QgBgEgBgCQgCgCgEAAIgJABIAAgHQAOgFALAAQAKAAAAAMIAABDQAAAIAEACQAEADAJAAIAAAFQgIADgIAAQgSAAgBgOQgRAPgRAAQgaAAAAghg");
	this.shape_6.setTransform(81.55,59);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkBMIAAgHIAJgCQAFgBAAgJIAAhCIgPAAIAAgKIAPAAIAAgBQAAgZALgOQALgQAVAAQARAAAAAJQAAAIgJAAIgIgCIgJgBQgKgBgDAJQgDAFAAASIAAALIAXAAIAAAKIgXAAIAABCQABAJAEABIAJACIAAAHg");
	this.shape_7.setTransform(73.45,56.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AggAsIgBgaIAFgBQADAMAIAGQAHAFAJAAQATAAAAgOQAAgKgQgGIgKgDQgWgHAAgTQAAgNAKgJQAKgJAOAAQAOAAANAIIABAWIgHABQgFgMgFgEQgFgFgJAAQgPAAAAAOQAAALANAEIAMAFQAXAHAAATQAAAOgKAIQgLAJgPAAQgOAAgQgHg");
	this.shape_8.setTransform(64.6,58.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOApIAAhAIgSAAIAAgKIASAAIAAgTIAOgLIADAAIAAAeIAbAAIAAAKIgbAAIAAA1QAAANAEAEQAEAFALgBIALgBIAAAJQgJAFgMAAQgaAAAAgXg");
	this.shape_9.setTransform(51.375,57.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgVBGIAAgHIAIgBQAGgCAAgIIAAg9QAAgEgCgCQgBgCgEAAIgJABIAAgHQANgFAKAAQAKAAAAAMIAABEQAAAIAFACIAJABIAAAHgAgJgvQgEgDAAgHQAAgGAEgDQADgDAGAAQAEAAAEADQAEADAAAGQAAAHgEADQgEADgEAAQgGAAgDgDg");
	this.shape_10.setTransform(44.925,56.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggAsIgBgaIAFgBQAEAMAHAGQAHAFAKAAQASAAAAgOQAAgKgQgGIgKgDQgWgHAAgTQAAgNAKgJQAJgJAPAAQAOAAANAIIABAWIgHABQgFgMgFgEQgFgFgJAAQgQAAAAAOQAAALAOAEIAMAFQAXAHAAATQAAAOgKAIQgLAJgOAAQgPAAgQgHg");
	this.shape_11.setTransform(37.5,58.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVBGIAAgHIAIgBQAGgCAAgIIAAg9QAAgEgCgCQgBgCgEAAIgJABIAAgHQANgFAKAAQAKAAAAAMIAABEQAAAIAFACIAJABIAAAHgAgJgvQgEgDAAgHQAAgGAEgDQADgDAGAAQAEAAAEADQAEADAAAGQAAAHgEADQgEADgEAAQgGAAgDgDg");
	this.shape_12.setTransform(30.175,56.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgEBHIgth5QgDgKgOgBIAAgIIA3AAIAAAIQgRABAAAIIABAEIAdBXIAihWIABgFQAAgIgRgBIAAgIIAvAAIAAAHQgNACgGANIguB2g");
	this.shape_13.setTransform(20.425,57);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_14.setTransform(353.75,27.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgVAAIgEAEIAAC8IAEAFIAVAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_15.setTransform(336.05,27.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAYCbIgriHIgDAAIAACHIg9AAIAAk1IA9AAIAqCHIAEAAIAAiHIA8AAIAAE1g");
	this.shape_16.setTransform(317.15,27.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_17.setTransform(299.4,27.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_18.setTransform(283.75,27.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_19.setTransform(268.3,27.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_20.setTransform(251.95,27.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgVAAIgEAEIAAC8IAEAFIAVAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_21.setTransform(234.25,27.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAVCbIgThvIgDAAIgTBvIhBAAIAAg0IAhhnIghhmIAAg0IBBAAIATBvIADAAIAThvIBBAAIAAA0IghBmIAhBnIAAA0g");
	this.shape_22.setTransform(215.6,27.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_23.setTransform(198.05,27.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAADNQAAAogiAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_24.setTransform(173.9,27.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgiCbIAAj0IgxAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape_25.setTransform(155.85,27.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape_26.setTransform(132.2,27.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_27.setTransform(114.15,27.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_28.setTransform(96.4,27.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_29.setTransform(78.7,27.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_30.setTransform(59.8,27.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAADNQAAAoghAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_31.setTransform(40.9,27.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_32.setTransform(22,27.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(1,1,1).p("A9Yl+MA6xAAAIAAL9Mg6xAAAg");
	this.shape_33.setTransform(188.075,38.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,378.2,78.7);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo_H
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFAAIABgBIAAgTIgQggIAAAAIgEgBIAAgEIAWAAIAAAEIgGABIAAAAIAKAZIABAAIALgZIAAAAIgHgBIAAgEIASAAIAAAEIgDABIgBAAIgPAfIAAAUIAAABIAFAAIAAAEg");
	this.shape.setTransform(153.5837,36.2934,1.186,1.1851);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIABAAIAAgzIgDAAQgGAAgCABQgCACgCAHIgEAAIAAgPIAvAAIAAAPIgEAAQgBgHgCgCQgCgBgHgBIgCAAIAAA0IAAAAIAFAAIAAAFg");
	this.shape_1.setTransform(146.3789,36.323,1.186,1.1851);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAGgBIAAAAIAAgyIAAgBIgGAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_2.setTransform(140.7751,36.2637,1.186,1.1851);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgKgDgFgCQgFgEgBgIQAAgHAFgFQAFgGALAAQAKAAAIAFIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANADQAUADAAAOQAAAHgFAFQgGAHgMAAQgNAAgHgGg");
	this.shape_3.setTransform(135.5568,36.2934,1.186,1.1851);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIAAAAIAGABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQATABAAAQQAAANgMADIANAWIADABIADACIAAADgAgJAAIAHAAQAEAAADgDQACgEAAgGQABgMgKAAIgHAAg");
	this.shape_4.setTransform(128.3817,36.2637,1.186,1.1851);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAFgBIABAAIAAgzIgBAAIgFgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAWIAGAAQAFAAACgBQABgBABgGIAEAAIAAAUIgEAAIAAABQgBgGgBgBQgCgCgFAAIgGAAIAAAZIAKAAQAHAAACgBQADgCACgJIAEAAIAAARg");
	this.shape_5.setTransform(120.999,36.2934,1.186,1.1851);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAfIgSg4IgBAAIgEgBIAAgEIAWAAIAAAEIgFABIgBAAIANAsIAAAAIAOgsIAAAAIgGgBIAAgEIASAAIAAAEIgFABIAAAAIgSA4g");
	this.shape_6.setTransform(113.5867,36.2934,1.186,1.1851);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_7.setTransform(107.5679,36.2637,1.186,1.1851);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPAfIgegvIgBAAIAAAqIABAAIAFABIAAAEIgSAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIARAAIAcAtIAAgnIgBgBIgFAAIAAgFIASAAIAAAFIgFAAIgBABIAAA3g");
	this.shape_8.setTransform(101.2525,36.2637,1.186,1.1851);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAJIAAgiIAAAAIgFgBIAAgEIAWAAIAAAEIgFABIgBAAIAAAiQAAARANAAQAPAAAAgRIAAgiIgBAAIgFgBIAAgEIARAAIAAAEIgFABIAAAAIAAAiQAAAWgXAAQgWAAAAgWg");
	this.shape_9.setTransform(93.01,36.2934,1.186,1.1851);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIABAAIAFABIAAAEIgXAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAaAAIAAAAQATABAAARQAAAMgMADIANAWQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAIAEABIAAADgAgJAAIAHAAQAJAAAAgMQAAgNgJAAIgHAAg");
	this.shape_10.setTransform(167.6078,23.4648,1.186,1.1851);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAGgBIAAAAIAAgzIAAAAIgGgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAXIAGAAQAGAAABgCIACgHIAEAAIAAAUIgEAAQAAgFgCgBQgBgCgGAAIgGAAIAAAZIAKAAQAIAAACgBQACgCACgJIAEAAIAAARg");
	this.shape_11.setTransform(160.1955,23.4944,1.186,1.1851);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgLgDgEgCQgFgEAAgIQAAgHADgFQAGgHALABQALgBAHAGIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANACQAUAEAAAOQAAAHgFAFQgGAIgMAAQgNAAgHgHg");
	this.shape_12.setTransform(153.5837,23.524,1.186,1.1851);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAHAfIAAgFIAGAAIAAAAIgEgLIgVAAIgEALIABAAIAFAAIAAAFIgSAAIAAgFIAFAAIAAAAIAUg4IAIAAIATA4IABAAIAEAAIAAAFgAgKAKIASAAIgJgcg");
	this.shape_13.setTransform(146.0824,23.524,1.186,1.1851);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgGAAIAAAWIAAAAIAFABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQAUABgBARQAAAMgMADIANAWIADACIAEABIAAADgAgJAAIAHAAQAKAAAAgMQAAgNgJAAIgIAAg");
	this.shape_14.setTransform(138.2846,23.4648,1.186,1.1851);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVAfIAAgFIAFAAIABAAIAAgzIgBgBIgFAAIAAgEIArAAIAAAOIgEAAQgCgGgCgCQgCgBgGgBIgKAAIAAAZIAFAAQAGAAABgBQACgBABgGIAEAAIAAAUIgEAAQgBgGgCAAQgBgCgFAAIgGAAIAAAXIAAAAIAEAAIAAAFg");
	this.shape_15.setTransform(130.9612,23.524,1.186,1.1851);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAPAfIgegwIAAArIAAAAIAFAAIAAAFIgSAAIAAgFIAGAAIAAAAIAAgzIAAgBIgGAAIAAgEIARAAIAcAtIAAgoIgBgBIgFAAIAAgEIASAAIAAAEIgFAAIgBABIAAA4g");
	this.shape_16.setTransform(120.5839,23.524,1.186,1.1851);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTAXQgEgIAAgPQAAgfAYABQAXAAAAAeQAAAfgYABQgNgBgGgIgAgJgSQgCAGAAAMQAAAMACAGQADAIAGAAQAIAAADgIQABgFAAgOQAAgNgCgEQgCgIgIAAQgGABgDAHg");
	this.shape_17.setTransform(112.8751,23.524,1.186,1.1851);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAfIAAgFIAFAAIAAAAIAAgsIAAAAIgOAnIgIAAIgPgnIgBAAIAAAsIABAAIAFAAIAAAFIgRAAIAAgFIAEAAIABAAIAAgzIgBgBIgEAAIAAgEIATAAIAOAnIAAAAIANgnIATAAIAAAEIgEAAIgBABIAAAzIABAAIAEAAIAAAFg");
	this.shape_18.setTransform(104.6029,23.524,1.186,1.1851);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIAAAAIAAgzIAAgBIgFAAIAAgEIAVAAIAAAEIgFAAIAAABIAAAzIAAAAIAFAAIAAAFg");
	this.shape_19.setTransform(97.7243,23.524,1.186,1.1851);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAFAAQACARAOAAQAMAAAAgLQAAgIgLgCQgLgDgEgCQgGgEAAgIQAAgHAEgFQAGgHAKABQALgBAHAGIAAAOIgFAAQgDgPgKAAQgLAAAAAKQAAAIAOACQATAEAAAOQAAAHgEAFQgHAIgLAAQgNAAgIgHg");
	this.shape_20.setTransform(92.4467,23.524,1.186,1.1851);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABMA/QgIgFgFgIQgDgGgBgFIgBgVIgChYIAMABIAMgBIgCBSIABAVQABAGADAEQAEAFAJAEQAKAEALAAQAQAAAJgGQAFgDAEgEQADgFABgHIABgXIgBg+IgBgQIAKABIALgBIgBBPQAAAZgEALQgDAJgLAJQgPAJgZABQgbAAgNgKgAiWBIQgLgCgNgGQAEgLACgLQAIAIAHADQAKAFAMAAQAMAAAIgHQAIgGAAgLQAAgKgLgIIgTgKQgMgFgIgFQgOgJAAgTQAAgRALgLQAMgMAVABQAMAAAIACIAOAEIgEAIIgDALQgKgHgIgDIgOgCQgKAAgGAGQgGAFAAAJQAAAJAJAHQAGAFAVALQATAHAGAKQAFAIAAAKQAAAOgKAMQgNASgdAAgAg1BGIABgUIgBh4IA8ABIAQgBIgBAKIABAKIg1gCIAAAqIAZAAQAIAAAQgCIgBAKIAAAKQgNgCgNAAIgXAAIAAASQAAAdACARg");
	this.shape_21.setTransform(56.1855,28.3829,1.186,1.1851);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A6192E").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_22.setTransform(40.0563,19.9984,1.186,1.1851);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.8,40);


// stage content:
(lib.banner_728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {loop:28};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [386];
	// timeline functions:
	this.frame_386 = function() {
		var _this = this;
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('loop');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(386).call(this.frame_386).wait(14));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_92 = new cjs.Graphics().p("AgETiIAA4tIAAuWIAJAAIAAOWIAAYtg");
	var mask_graphics_93 = new cjs.Graphics().p("AgJTiMAAAgnDIATAAMAAAAnDg");
	var mask_graphics_94 = new cjs.Graphics().p("AgbTiMAAAgnDIA3AAMAAAAnDg");
	var mask_graphics_95 = new cjs.Graphics().p("Ag3TiMAAAgnDIBvAAMAAAAnDg");
	var mask_graphics_96 = new cjs.Graphics().p("AhfTiMAAAgnDIC/AAMAAAAnDg");
	var mask_graphics_97 = new cjs.Graphics().p("AiSTiMAAAgnDIElAAMAAAAnDg");
	var mask_graphics_98 = new cjs.Graphics().p("AjRTiMAAAgnDIGjAAMAAAAnDg");
	var mask_graphics_99 = new cjs.Graphics().p("AkbTiMAAAgnDII3AAMAAAAnDg");
	var mask_graphics_100 = new cjs.Graphics().p("AlxTiMAAAgnDILiAAMAAAAnDg");
	var mask_graphics_101 = new cjs.Graphics().p("AnRTiMAAAgnDIOjAAMAAAAnDg");
	var mask_graphics_102 = new cjs.Graphics().p("Ao+TiMAAAgnDIR9AAMAAAAnDg");
	var mask_graphics_103 = new cjs.Graphics().p("Aq1TiMAAAgnDIVrAAMAAAAnDg");
	var mask_graphics_104 = new cjs.Graphics().p("As4TiMAAAgnDIZxAAMAAAAnDg");
	var mask_graphics_105 = new cjs.Graphics().p("AvGTiMAAAgnDIeOAAMAAAAnDg");
	var mask_graphics_106 = new cjs.Graphics().p("AxgTiMAAAgnDMAjBAAAMAAAAnDg");
	var mask_graphics_107 = new cjs.Graphics().p("A0DTiMAAAgnDMAoHAAAMAAAAnDg");
	var mask_graphics_108 = new cjs.Graphics().p("A2dTiMAAAgnDMAs7AAAMAAAAnDg");
	var mask_graphics_109 = new cjs.Graphics().p("A4rTiMAAAgnDMAxXAAAMAAAAnDg");
	var mask_graphics_110 = new cjs.Graphics().p("A6uTiMAAAgnDMA1dAAAMAAAAnDg");
	var mask_graphics_111 = new cjs.Graphics().p("A8lTiMAAAgnDMA5LAAAMAAAAnDg");
	var mask_graphics_112 = new cjs.Graphics().p("A+STiMAAAgnDMA8lAAAMAAAAnDg");
	var mask_graphics_113 = new cjs.Graphics().p("A/yTiMAAAgnDMA/lAAAMAAAAnDg");
	var mask_graphics_114 = new cjs.Graphics().p("EghIATiMAAAgnDMBCRAAAMAAAAnDg");
	var mask_graphics_115 = new cjs.Graphics().p("EgiSATiMAAAgnDMBElAAAMAAAAnDg");
	var mask_graphics_116 = new cjs.Graphics().p("EgjRATiMAAAgnDMBGjAAAMAAAAnDg");
	var mask_graphics_117 = new cjs.Graphics().p("EgkEATiMAAAgnDMBIJAAAMAAAAnDg");
	var mask_graphics_118 = new cjs.Graphics().p("EgksATiMAAAgnDMBJZAAAMAAAAnDg");
	var mask_graphics_119 = new cjs.Graphics().p("EglIATiMAAAgnDMBKRAAAMAAAAnDg");
	var mask_graphics_120 = new cjs.Graphics().p("EglZATiMAAAgnDMBKzAAAMAAAAnDg");
	var mask_graphics_121 = new cjs.Graphics().p("EglfATiIAA4tIAAuWMBK/AAAIAAOWIAAYtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(92).to({graphics:mask_graphics_92,x:273.5,y:125}).wait(1).to({graphics:mask_graphics_93,x:274,y:125}).wait(1).to({graphics:mask_graphics_94,x:275.525,y:125}).wait(1).to({graphics:mask_graphics_95,x:278.075,y:125}).wait(1).to({graphics:mask_graphics_96,x:281.65,y:125}).wait(1).to({graphics:mask_graphics_97,x:286.25,y:125}).wait(1).to({graphics:mask_graphics_98,x:291.85,y:125}).wait(1).to({graphics:mask_graphics_99,x:298.5,y:125}).wait(1).to({graphics:mask_graphics_100,x:306.15,y:125}).wait(1).to({graphics:mask_graphics_101,x:314.825,y:125}).wait(1).to({graphics:mask_graphics_102,x:324.5,y:125}).wait(1).to({graphics:mask_graphics_103,x:335.225,y:125}).wait(1).to({graphics:mask_graphics_104,x:346.95,y:125}).wait(1).to({graphics:mask_graphics_105,x:359.7,y:125}).wait(1).to({graphics:mask_graphics_106,x:373.475,y:125}).wait(1).to({graphics:mask_graphics_107,x:388.025,y:125}).wait(1).to({graphics:mask_graphics_108,x:401.8,y:125}).wait(1).to({graphics:mask_graphics_109,x:414.55,y:125}).wait(1).to({graphics:mask_graphics_110,x:426.275,y:125}).wait(1).to({graphics:mask_graphics_111,x:437,y:125}).wait(1).to({graphics:mask_graphics_112,x:446.675,y:125}).wait(1).to({graphics:mask_graphics_113,x:455.35,y:125}).wait(1).to({graphics:mask_graphics_114,x:463,y:125}).wait(1).to({graphics:mask_graphics_115,x:469.65,y:125}).wait(1).to({graphics:mask_graphics_116,x:475.25,y:125}).wait(1).to({graphics:mask_graphics_117,x:479.825,y:125}).wait(1).to({graphics:mask_graphics_118,x:483.425,y:125}).wait(1).to({graphics:mask_graphics_119,x:485.975,y:125}).wait(1).to({graphics:mask_graphics_120,x:487.475,y:125}).wait(1).to({graphics:mask_graphics_121,x:488,y:125}).wait(219).to({graphics:null,x:0,y:0}).wait(60));

	// Connect_to_Excellence
	this.instance = new lib.g_txt_connect_to_excellence("synched",0);
	this.instance.setTransform(380.35,68.2,1,1,0,0,0,98.5,61.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({x:375.35,alpha:1},30,cjs.Ease.quadInOut).wait(80).to({startPosition:0},0).to({x:370.35,alpha:0},31,cjs.Ease.quadInOut).to({_off:true},1).wait(28));

	// g_txt_02
	this.instance_1 = new lib.g_txt02("synched",0);
	this.instance_1.setTransform(273,21.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(92).to({_off:false},0).to({alpha:1},29,cjs.Ease.quadInOut).wait(101).to({startPosition:0},0).to({x:268,alpha:0},30,cjs.Ease.quadInOut).to({_off:true},1).wait(147));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Eg43AHCIAAuDMBxvAAAIAAODg");
	mask_1.setTransform(364,45);

	// g_txt_01
	this.instance_2 = new lib.g_txt01("synched",0);
	this.instance_2.setTransform(1130.2,15);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:728},28,cjs.Ease.quadInOut).wait(64).to({startPosition:0},0).to({x:1183.2},29,cjs.Ease.quadInOut).to({_off:true},1).wait(235).to({_off:false},0).to({x:728},28,cjs.Ease.quadInOut).wait(15));

	// Logo
	this.instance_3 = new lib.g_SFULogo("synched",0);
	this.instance_3.setTransform(0.1,26.35,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(400));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(400));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,364,45);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;