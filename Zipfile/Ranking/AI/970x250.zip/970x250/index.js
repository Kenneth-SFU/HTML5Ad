(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Photo = function() {
	this.initialize(img.Photo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,500);


(lib.g_txt02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.text = new cjs.Text("Learn how we're building a better future, one breakthrough at a time.", "22px 'Lava FNI'", "#FFFFFF");
	this.text.lineHeight = 26;
	this.text.lineWidth = 416;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,420,109.6);


(lib.g_txt01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgvDYIAAlVIhFAAIAAhaIDpAAIAABaIhFAAIAAFVg");
	this.shape.setTransform(256.75,84.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhFDYQgvgRAAg3IAAkfQAAg3AvgRICLAAQAvARAAA3IAABoIhgAAIAAhcIgGgGIgdAAIgGAGIAAEHIAGAGIAdAAIAGgGIAAhbIBgAAIAABnQAAA3gvARg");
	this.shape_1.setTransform(231.55,84.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICCAAIA2FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_2.setTransform(205.45,84.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ah0DYIAAmvIC6AAQAvARAAA3IAACKQAAA2gvARIhaAAIAACWgAgUgLIAjAAIAGgGIAAhyIgGgGIgjAAg");
	this.shape_3.setTransform(179.95,84.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ABFDYIAAj1IgDAAIgeBfIhHAAIgehfIgDAAIAAD1IhaAAIAAmvIBpAAIAzCWIAFAAIAziWIBpAAIAAGvg");
	this.shape_4.setTransform(149.35,84.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhBDYIAAhaIASAAIAAj7IgSAAIAAhaICDAAIAABaIgSAAIAAD7IASAAIAABag");
	this.shape_5.setTransform(123.85,84.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhgDYIAAmvIBfAAIAAFVIBiAAIAABag");
	this.shape_6.setTransform(96.4,84.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICCAAIA2FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_7.setTransform(72.25,84.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhkDYIAAmvIDFAAIAABaIhlAAIAABOIBgAAIAABZIhgAAIAABUIBpAAIAABag");
	this.shape_8.setTransform(47.8,84.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAnDYIg2ioIgLAAIAACoIhgAAIAAmvIC6AAQAvARAAA3IAABcQAAAzgoASIA0CJIAAA9gAgagdIAjAAIAGgGIAAhgIgGgGIgjAAg");
	this.shape_9.setTransform(23.775,84.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAnDYIg2ioIgLAAIAACoIhgAAIAAmvIC6AAQAvARAAA3IAABcQAAAzgoASIA0CKIAAA8gAgagdIAjAAIAGgGIAAhgIgGgGIgjAAg");
	this.shape_10.setTransform(123.975,29.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhFDYQgvgRAAg3IAAkfQAAg3AvgRICLAAQAvARAAA3IAAEfQAAA3gvARgAgUiDIAAEHIAGAGIAdAAIAGgGIAAkHIgGgGIgdAAg");
	this.shape_11.setTransform(97,29.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AhiDYIAAmvIDFAAIAABaIhlAAIAABUIBfAAIAABZIhfAAIAACog");
	this.shape_12.setTransform(72.4,29.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhBDYIAAhaIASAAIAAj7IgSAAIAAhaICDAAIAABaIgSAAIAAD7IASAAIAABag");
	this.shape_13.setTransform(43.9,29.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAeDYIgHhUIgtAAIgHBUIhaAAIAAhIIA3lnICBAAIA3FnIAABIgAAPAqIgMiIIgFAAIgMCIIAdAAg");
	this.shape_14.setTransform(22.9,29.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("A3wJDIAAsOIgBAAIAAl3IayAAIAAIHIUxAAIAAJ+g");
	this.shape_15.setTransform(128.45,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.7,0,304.4,120.5);


(lib.g_txt_connect_to_excellence = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBNIAAgIIAKgBQAGgCAAgJIAAhDQAAgFgCgCQgBgCgFAAIgKABIAAgIQAPgFALAAQALAAAAAOIAABKQAAAJAGACIAKABIAAAIgAgKg0QgEgEAAgGQAAgHAEgEQAEgDAGAAQAEAAAEADQAFAEAAAHQAAAGgFAEQgEAEgEAAQgGAAgEgEg");
	this.shape.setTransform(145.875,102.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOAyQgEgDAAgIQgFAHgIAEQgIAFgKAAQgLAAgIgGQgIgIAAgMQAAgWAggIIAagGIAAgFQAAgOgFgGQgFgGgMAAQgOAAgTAFIAAgKQAVgMAXAAQAfAAAAAlIAAAyQAAAOAPAAIAEAAIAAAGQgJADgKABQgMAAgEgGgAgEAGQgMAEgGADQgFAEAAAGQAAAQARAAQAKAAAKgGIAAgfg");
	this.shape_1.setTransform(137.475,104.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnBqIBAjTIAPAAIhADTg");
	this.shape_2.setTransform(126.925,104);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAOAyQgEgDAAgIQgFAHgIAEQgIAFgKAAQgLAAgIgGQgIgIAAgMQAAgWAggIIAagGIAAgFQAAgOgFgGQgFgGgMAAQgOAAgTAFIAAgKQAVgMAXAAQAfAAAAAlIAAAyQAAAOAPAAIAEAAIAAAGQgJADgKABQgMAAgEgGgAgEAGQgMAEgGADQgFAEAAAGQAAAQARAAQAKAAAKgGIAAgfg");
	this.shape_3.setTransform(117.125,104.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAqQgMgOAAgXQAAgbAOgQQAPgRAXAAQAOAAAKAFQALAGAAAIQAAAFgDAEQgEADgEAAQgFAAgIgJQgIgJgLAAQgLAAgHAKQgHAKAAAUQAAApAiAAQAOAAARgGIAAALQgQAMgXAAQgVAAgMgOg");
	this.shape_4.setTransform(106.225,104.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQAAQAAgNAQAAQARAAAAANQAAAOgRAAQgQAAAAgOg");
	this.shape_5.setTransform(97.8,108.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrAUIAAg2QAAgFgBgCQgBgCgGAAIgJABIAAgIQAOgFAMAAQAMAAAAAOIAAA4QgBANAFAFQAFAGANAAQAIAAAPgFIAAhEQAAgFgCgCQgCgCgEAAIgKABIAAgIQAOgFAMAAQAMAAAAAOIAABJQAAAJAEADQAFACAJAAIAAAGQgIADgJABQgUAAgBgQQgTAQgSAAQgdAAAAgkg");
	this.shape_6.setTransform(88.35,104.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgnBUIAAgJIAJgBQAGgCAAgJIAAhKIgQAAIAAgLIAQAAIAAgBQAAgaAMgRQAMgRAXAAQASAAAAALQAAAIgJAAIgIgCQgGgCgEAAQgMAAgDAJQgDAGAAAUIAAALIAZAAIAAALIgZAAIAABKQAAAJAFACIAKABIAAAJg");
	this.shape_7.setTransform(79.425,101.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgjAxIgBgdIAFgBQAEANAJAGQAHAGAKAAQAVAAAAgPQAAgMgSgFIgLgEQgYgIAAgVQAAgOAKgKQALgKAPAAQAQAAAPAJIABAYIgHABQgHgNgEgFQgGgFgKAAQgRAAAAAQQAAALAPAFIANAFQAaAIgBAVQAAAPgLAJQgMAKgQAAQgQAAgRgHg");
	this.shape_8.setTransform(69.7,104.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQAtIAAhHIgTAAIAAgLIATAAIAAgVIAQgMIAEAAIAAAhIAeAAIAAALIgeAAIAAA7QAAANADAGQAFAEAMAAIAMgBIAAAJQgJAGgOABQgdgBAAgZg");
	this.shape_9.setTransform(55.15,103);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgYBNIAAgIIAKgBQAGgCAAgJIAAhDQAAgFgCgCQgBgCgFAAIgKABIAAgIQAPgFALAAQALAAAAAOIAABKQAAAJAGACIAKABIAAAIgAgKg0QgEgEAAgGQAAgHAEgEQAEgDAGAAQAEAAAEADQAFAEAAAHQAAAGgFAEQgEAEgEAAQgGAAgEgEg");
	this.shape_10.setTransform(48.075,102.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgjAxIgBgdIAFgBQAEANAJAGQAHAGAKAAQAVAAAAgPQAAgMgSgFIgLgEQgYgIAAgVQAAgOAKgKQAMgKAOAAQAQAAAPAJIABAYIgHABQgGgNgFgFQgGgFgKAAQgRAAAAAQQAAALAPAFIANAFQAaAIAAAVQAAAPgMAJQgMAKgQAAQgQAAgRgHg");
	this.shape_11.setTransform(39.9,104.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYBNIAAgIIAKgBQAGgCAAgJIAAhDQAAgFgCgCQgBgCgFAAIgKABIAAgIQAPgFALAAQALAAAAAOIAABKQAAAJAGACIAKABIAAAIgAgKg0QgEgEAAgGQAAgHAEgEQAEgDAGAAQAEAAAEADQAFAEAAAHQAAAGgFAEQgEAEgEAAQgGAAgEgEg");
	this.shape_12.setTransform(31.825,102.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFBOIgwiFQgEgLgPgCIAAgJIA9AAIAAAJQgTACAAAJIABAEIAfBgIAmhfIACgGQAAgIgUgCIAAgJIAzAAIAAAIQgOADgFAOIg0CCg");
	this.shape_13.setTransform(21.1,102.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_14.setTransform(176.5,66.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_15.setTransform(158.8,66.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_16.setTransform(139.9,66.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_17.setTransform(122.15,66.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_18.setTransform(106.5,66.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_19.setTransform(91.05,66.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_20.setTransform(74.7,66.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_21.setTransform(57,66.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAVCbIgThvIgDAAIgUBvIhAAAIAAg0IAhhnIghhmIAAg0IBAAAIAUBvIADAAIAThvIBBAAIAAA0IghBmIAhBnIAAA0g");
	this.shape_22.setTransform(38.35,66.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_23.setTransform(20.8,66.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAADNQAAAogiAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_24.setTransform(173.9,28.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgiCbIAAj0IgxAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape_25.setTransform(155.85,28.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape_26.setTransform(132.2,28.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_27.setTransform(114.15,28.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_28.setTransform(96.4,28.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_29.setTransform(78.7,28.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_30.setTransform(59.8,28.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAADNQAAAoghAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_31.setTransform(40.9,28.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_32.setTransform(22,28.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(1,1,1).p("AvYpmIexAAIAATNI+xAAg");
	this.shape_33.setTransform(98.5,61.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,199,125);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo_H
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFAAIABgBIAAgTIgQggIAAAAIgEgBIAAgEIAWAAIAAAEIgGABIAAAAIAKAZIABAAIALgZIAAAAIgHgBIAAgEIASAAIAAAEIgDABIgBAAIgPAfIAAAUIAAABIAFAAIAAAEg");
	this.shape.setTransform(153.5876,36.2938,1.186,1.1851);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIABAAIAAgzIgDAAQgGAAgCABQgCACgCAHIgEAAIAAgPIAvAAIAAAPIgEAAQgBgHgCgCQgCgBgHgBIgCAAIAAA0IAAAAIAFAAIAAAFg");
	this.shape_1.setTransform(146.3826,36.3234,1.186,1.1851);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAGgBIAAAAIAAgyIAAgBIgGAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_2.setTransform(140.7788,36.2642,1.186,1.1851);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgKgDgFgCQgFgEgBgIQAAgHAFgFQAFgGALAAQAKAAAIAFIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANADQAUADAAAOQAAAHgFAFQgGAHgMAAQgNAAgHgGg");
	this.shape_3.setTransform(135.5603,36.2938,1.186,1.1851);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIAAAAIAGABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQATABAAAQQAAANgMADIANAWIADABIADACIAAADgAgJAAIAHAAQAEAAADgDQACgEAAgGQABgMgKAAIgHAAg");
	this.shape_4.setTransform(128.385,36.2642,1.186,1.1851);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAFgBIABAAIAAgzIgBAAIgFgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAWIAGAAQAFAAACgBQABgBABgGIAEAAIAAAUIgEAAIAAABQgBgGgBgBQgCgCgFAAIgGAAIAAAZIAKAAQAHAAACgBQADgCACgJIAEAAIAAARg");
	this.shape_5.setTransform(121.0021,36.2938,1.186,1.1851);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAfIgSg4IgBAAIgEgBIAAgEIAWAAIAAAEIgFABIgBAAIANAsIAAAAIAOgsIAAAAIgGgBIAAgEIASAAIAAAEIgFABIAAAAIgSA4g");
	this.shape_6.setTransform(113.5896,36.2938,1.186,1.1851);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_7.setTransform(107.5706,36.2642,1.186,1.1851);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPAfIgegvIgBAAIAAAqIABAAIAFABIAAAEIgSAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIARAAIAcAtIAAgnIgBgBIgFAAIAAgFIASAAIAAAFIgFAAIgBABIAAA3g");
	this.shape_8.setTransform(101.2552,36.2642,1.186,1.1851);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAJIAAgiIAAAAIgFgBIAAgEIAWAAIAAAEIgFABIgBAAIAAAiQAAARANAAQAPAAAAgRIAAgiIgBAAIgFgBIAAgEIARAAIAAAEIgFABIAAAAIAAAiQAAAWgXAAQgWAAAAgWg");
	this.shape_9.setTransform(93.0124,36.2938,1.186,1.1851);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIABAAIAFABIAAAEIgXAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAaAAIAAAAQATABAAARQAAAMgMADIANAWQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAIAEABIAAADgAgJAAIAHAAQAJAAAAgMQAAgNgJAAIgHAAg");
	this.shape_10.setTransform(167.6121,23.4651,1.186,1.1851);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAGgBIAAAAIAAgzIAAAAIgGgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAXIAGAAQAGAAABgCIACgHIAEAAIAAAUIgEAAQAAgFgCgBQgBgCgGAAIgGAAIAAAZIAKAAQAIAAACgBQACgCACgJIAEAAIAAARg");
	this.shape_11.setTransform(160.1996,23.4947,1.186,1.1851);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgLgDgEgCQgFgEAAgIQAAgHADgFQAGgHALABQALgBAHAGIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANACQAUAEAAAOQAAAHgFAFQgGAIgMAAQgNAAgHgHg");
	this.shape_12.setTransform(153.5876,23.5243,1.186,1.1851);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAHAfIAAgFIAGAAIAAAAIgEgLIgVAAIgEALIABAAIAFAAIAAAFIgSAAIAAgFIAFAAIAAAAIAUg4IAIAAIATA4IABAAIAEAAIAAAFgAgKAKIASAAIgJgcg");
	this.shape_13.setTransform(146.0861,23.5243,1.186,1.1851);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgGAAIAAAWIAAAAIAFABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQAUABgBARQAAAMgMADIANAWIADACIAEABIAAADgAgJAAIAHAAQAKAAAAgMQAAgNgJAAIgIAAg");
	this.shape_14.setTransform(138.2881,23.4651,1.186,1.1851);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVAfIAAgFIAFAAIABAAIAAgzIgBgBIgFAAIAAgEIArAAIAAAOIgEAAQgCgGgCgCQgCgBgGgBIgKAAIAAAZIAFAAQAGAAABgBQACgBABgGIAEAAIAAAUIgEAAQgBgGgCAAQgBgCgFAAIgGAAIAAAXIAAAAIAEAAIAAAFg");
	this.shape_15.setTransform(130.9646,23.5243,1.186,1.1851);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAPAfIgegwIAAArIAAAAIAFAAIAAAFIgSAAIAAgFIAGAAIAAAAIAAgzIAAgBIgGAAIAAgEIARAAIAcAtIAAgoIgBgBIgFAAIAAgEIASAAIAAAEIgFAAIgBABIAAA4g");
	this.shape_16.setTransform(120.587,23.5243,1.186,1.1851);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTAXQgEgIAAgPQAAgfAYABQAXAAAAAeQAAAfgYABQgNgBgGgIgAgJgSQgCAGAAAMQAAAMACAGQADAIAGAAQAIAAADgIQABgFAAgOQAAgNgCgEQgCgIgIAAQgGABgDAHg");
	this.shape_17.setTransform(112.878,23.5243,1.186,1.1851);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAfIAAgFIAFAAIAAAAIAAgsIAAAAIgOAnIgIAAIgPgnIgBAAIAAAsIABAAIAFAAIAAAFIgRAAIAAgFIAEAAIABAAIAAgzIgBgBIgEAAIAAgEIATAAIAOAnIAAAAIANgnIATAAIAAAEIgEAAIgBABIAAAzIABAAIAEAAIAAAFg");
	this.shape_18.setTransform(104.6056,23.5243,1.186,1.1851);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIAAAAIAAgzIAAgBIgFAAIAAgEIAVAAIAAAEIgFAAIAAABIAAAzIAAAAIAFAAIAAAFg");
	this.shape_19.setTransform(97.7268,23.5243,1.186,1.1851);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAFAAQACARAOAAQAMAAAAgLQAAgIgLgCQgLgDgEgCQgGgEAAgIQAAgHAEgFQAGgHAKABQALgBAHAGIAAAOIgFAAQgDgPgKAAQgLAAAAAKQAAAIAOACQATAEAAAOQAAAHgEAFQgHAIgLAAQgNAAgIgHg");
	this.shape_20.setTransform(92.4491,23.5243,1.186,1.1851);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABMA/QgIgFgFgIQgDgGgBgFIgBgVIgChYIAMABIAMgBIgCBSIABAVQABAGADAEQAEAFAJAEQAKAEALAAQAQAAAJgGQAFgDAEgEQADgFABgHIABgXIgBg+IgBgQIAKABIALgBIgBBPQAAAZgEALQgDAJgLAJQgPAJgZABQgbAAgNgKgAiWBIQgLgCgNgGQAEgLACgLQAIAIAHADQAKAFAMAAQAMAAAIgHQAIgGAAgLQAAgKgLgIIgTgKQgMgFgIgFQgOgJAAgTQAAgRALgLQAMgMAVABQAMAAAIACIAOAEIgEAIIgDALQgKgHgIgDIgOgCQgKAAgGAGQgGAFAAAJQAAAJAJAHQAGAFAVALQATAHAGAKQAFAIAAAKQAAAOgKAMQgNASgdAAgAg1BGIABgUIgBh4IA8ABIAQgBIgBAKIABAKIg1gCIAAAqIAZAAQAIAAAQgCIgBAKIAAAKQgNgCgNAAIgXAAIAAASQAAAdACARg");
	this.shape_21.setTransform(56.187,28.3833,1.186,1.1851);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A6192E").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_22.setTransform(40.0573,19.9986,1.186,1.1851);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.8,40);


// stage content:
(lib.banner_970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {loop:28};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [386];
	// timeline functions:
	this.frame_386 = function() {
		var _this = this;
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('loop');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(386).call(this.frame_386).wait(14));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_92 = new cjs.Graphics().p("AgETiMAAAgnDIAJAAMAAAAnDg");
	var mask_graphics_93 = new cjs.Graphics().p("AgJTiMAAAgnDIATAAMAAAAnDg");
	var mask_graphics_94 = new cjs.Graphics().p("AgZTiMAAAgnDIAzAAMAAAAnDg");
	var mask_graphics_95 = new cjs.Graphics().p("Ag0TiMAAAgnDIBpAAMAAAAnDg");
	var mask_graphics_96 = new cjs.Graphics().p("AhaTiMAAAgnDIC0AAMAAAAnDg");
	var mask_graphics_97 = new cjs.Graphics().p("AiJTiMAAAgnDIETAAMAAAAnDg");
	var mask_graphics_98 = new cjs.Graphics().p("AjETiMAAAgnDIGJAAMAAAAnDg");
	var mask_graphics_99 = new cjs.Graphics().p("AkJTiMAAAgnDIIUAAMAAAAnDg");
	var mask_graphics_100 = new cjs.Graphics().p("AlaTiMAAAgnDIK0AAMAAAAnDg");
	var mask_graphics_101 = new cjs.Graphics().p("Am1TiMAAAgnDINqAAMAAAAnDg");
	var mask_graphics_102 = new cjs.Graphics().p("AoaTiMAAAgnDIQ1AAMAAAAnDg");
	var mask_graphics_103 = new cjs.Graphics().p("AqKTiMAAAgnDIUVAAMAAAAnDg");
	var mask_graphics_104 = new cjs.Graphics().p("AsFTiMAAAgnDIYLAAMAAAAnDg");
	var mask_graphics_105 = new cjs.Graphics().p("AuKTiMAAAgnDIcVAAMAAAAnDg");
	var mask_graphics_106 = new cjs.Graphics().p("AwaTiMAAAgnDMAg1AAAMAAAAnDg");
	var mask_graphics_107 = new cjs.Graphics().p("AyzTiMAAAgnDMAlnAAAMAAAAnDg");
	var mask_graphics_108 = new cjs.Graphics().p("A1DTiMAAAgnDMAqHAAAMAAAAnDg");
	var mask_graphics_109 = new cjs.Graphics().p("A3ITiMAAAgnDMAuRAAAMAAAAnDg");
	var mask_graphics_110 = new cjs.Graphics().p("A5DTiMAAAgnDMAyHAAAMAAAAnDg");
	var mask_graphics_111 = new cjs.Graphics().p("A6zTiMAAAgnDMA1nAAAMAAAAnDg");
	var mask_graphics_112 = new cjs.Graphics().p("A8ZTiMAAAgnDMA4zAAAMAAAAnDg");
	var mask_graphics_113 = new cjs.Graphics().p("A9zTiMAAAgnDMA7oAAAMAAAAnDg");
	var mask_graphics_114 = new cjs.Graphics().p("A/DTiMAAAgnDMA+HAAAMAAAAnDg");
	var mask_graphics_115 = new cjs.Graphics().p("EggJATiMAAAgnDMBATAAAMAAAAnDg");
	var mask_graphics_116 = new cjs.Graphics().p("EghEATiMAAAgnDMBCIAAAMAAAAnDg");
	var mask_graphics_117 = new cjs.Graphics().p("EghzATiMAAAgnDMBDoAAAMAAAAnDg");
	var mask_graphics_118 = new cjs.Graphics().p("EgiZATiMAAAgnDMBEzAAAMAAAAnDg");
	var mask_graphics_119 = new cjs.Graphics().p("EgizATiMAAAgnDMBFoAAAMAAAAnDg");
	var mask_graphics_120 = new cjs.Graphics().p("EgjEATiMAAAgnDMBGJAAAMAAAAnDg");
	var mask_graphics_121 = new cjs.Graphics().p("EgjJATiMAAAgnDMBGTAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(92).to({graphics:mask_graphics_92,x:935,y:125}).wait(1).to({graphics:mask_graphics_93,x:934.475,y:125}).wait(1).to({graphics:mask_graphics_94,x:932.875,y:125}).wait(1).to({graphics:mask_graphics_95,x:930.2,y:125}).wait(1).to({graphics:mask_graphics_96,x:926.45,y:125}).wait(1).to({graphics:mask_graphics_97,x:921.625,y:125}).wait(1).to({graphics:mask_graphics_98,x:915.725,y:125}).wait(1).to({graphics:mask_graphics_99,x:908.8,y:125}).wait(1).to({graphics:mask_graphics_100,x:900.75,y:125}).wait(1).to({graphics:mask_graphics_101,x:891.65,y:125}).wait(1).to({graphics:mask_graphics_102,x:881.5,y:125}).wait(1).to({graphics:mask_graphics_103,x:870.25,y:125}).wait(1).to({graphics:mask_graphics_104,x:857.95,y:125}).wait(1).to({graphics:mask_graphics_105,x:844.575,y:125}).wait(1).to({graphics:mask_graphics_106,x:830.125,y:125}).wait(1).to({graphics:mask_graphics_107,x:814.875,y:125}).wait(1).to({graphics:mask_graphics_108,x:800.425,y:125}).wait(1).to({graphics:mask_graphics_109,x:787.05,y:125}).wait(1).to({graphics:mask_graphics_110,x:774.75,y:125}).wait(1).to({graphics:mask_graphics_111,x:763.5,y:125}).wait(1).to({graphics:mask_graphics_112,x:753.35,y:125}).wait(1).to({graphics:mask_graphics_113,x:744.25,y:125}).wait(1).to({graphics:mask_graphics_114,x:736.225,y:125}).wait(1).to({graphics:mask_graphics_115,x:729.275,y:125}).wait(1).to({graphics:mask_graphics_116,x:723.4,y:125}).wait(1).to({graphics:mask_graphics_117,x:718.55,y:125}).wait(1).to({graphics:mask_graphics_118,x:714.8,y:125}).wait(1).to({graphics:mask_graphics_119,x:712.15,y:125}).wait(1).to({graphics:mask_graphics_120,x:710.525,y:125}).wait(1).to({graphics:mask_graphics_121,x:710,y:125}).wait(219).to({graphics:null,x:0,y:0}).wait(60));

	// Connect_to_Excellence
	this.instance = new lib.g_txt_connect_to_excellence("synched",0);
	this.instance.setTransform(629.95,153,1,1,0,0,0,98.5,61.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({x:619.95,alpha:1},30,cjs.Ease.quadInOut).wait(80).to({startPosition:0},0).to({x:609.95,alpha:0},31,cjs.Ease.quadInOut).to({_off:true},1).wait(28));

	// g_txt_02
	this.instance_1 = new lib.g_txt02("synched",0);
	this.instance_1.setTransform(518.55,115.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(92).to({_off:false},0).to({alpha:1},29,cjs.Ease.quadInOut).wait(101).to({startPosition:0},0).to({x:508.55,alpha:0},30,cjs.Ease.quadInOut).to({_off:true},1).wait(147));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3bXcMAAAgu3MAu3AAAMAAAAu3g");
	mask_1.setTransform(150,450);

	// Photo
	this.instance_2 = new lib.Photo();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(400));

	// g_txt_01
	this.instance_3 = new lib.g_txt01("synched",0);
	this.instance_3.setTransform(186.85,97.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:508.5},28,cjs.Ease.quadInOut).wait(64).to({startPosition:0},0).to({x:186.85},29,cjs.Ease.quadInOut).to({_off:true},1).wait(235).to({_off:false},0).to({x:508.5},28,cjs.Ease.quadInOut).wait(15));

	// Logo
	this.instance_4 = new lib.g_SFULogo("synched",0);
	this.instance_4.setTransform(485.1,30.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(400));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(400));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(485,125,485,125);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 970,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Photo.jpg?1761066661866", id:"Photo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;