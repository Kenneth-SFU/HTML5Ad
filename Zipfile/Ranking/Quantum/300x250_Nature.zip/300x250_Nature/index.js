(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Photo_nature = function() {
	this.initialize(img.Photo_nature);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,340);


(lib.g_txt02_Nature = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.text = new cjs.Text("Learn how we’re supporting a better future, as a partner for innovation.", "20px 'Lava FNI'", "#FFFFFF");
	this.text.lineHeight = 24;
	this.text.lineWidth = 251;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,255.1,109);


(lib.g_txt01_Nature = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgiCbIAAj0IgxAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape.setTransform(112.9,60.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgVAAIgEAEIAAC8IAEAFIAVAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_1.setTransform(94.85,60.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAWCbIgGg9IggAAIgEA9IhBAAIAAg0IAnkBIBdAAIAnEBIAAA0gAALAeIgJhhIgDAAIgJBhIAVAAg");
	this.shape_2.setTransform(76.2,60.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhTCbIAAk1ICGAAQAhAMAAAoIAABjQAAAmghAMIhBAAIAABsgAgOgIIAZAAIAEgEIAAhSIgEgEIgZAAg");
	this.shape_3.setTransform(57.95,60.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAyCbIAAiwIgDAAIgVBEIgzAAIgVhEIgCAAIAACwIhBAAIAAk1IBMAAIAkBsIADAAIAlhsIBLAAIAAE1g");
	this.shape_4.setTransform(36.05,60.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AguCbIAAhBIAMAAIAAizIgMAAIAAhBIBeAAIAABBIgOAAIAACzIAOAAIAABBg");
	this.shape_5.setTransform(17.8,60.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAyCbIAAiwIgCAAIgWBEIgzAAIgVhEIgCAAIAACwIhBAAIAAk1IBLAAIAlBsIAEAAIAkhsIBLAAIAAE1g");
	this.shape_6.setTransform(134.8,22.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgvCbQgigMAAgoIAAkBIBFAAIAAD4IAFAFIAQAAIAEgFIAAj4IBFAAIAAEBQAAAogiAMg");
	this.shape_7.setTransform(113.125,22.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape_8.setTransform(95.3,22.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAXCbIgpiHIgFAAIAACHIg8AAIAAk1IA8AAIArCHIADAAIAAiHIA9AAIAAE1g");
	this.shape_9.setTransform(77.25,22.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAVCbIgFg9IgfAAIgGA9IhAAAIAAg0IAnkBIBdAAIAnEBIAAA0gAALAeIgJhhIgDAAIgJBhIAVAAg");
	this.shape_10.setTransform(58.6,22.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgvCbQgigMAAgoIAAkBIBFAAIAAD4IAFAFIAQAAIAEgFIAAj4IBFAAIAAEBQAAAogiAMg");
	this.shape_11.setTransform(40.125,22.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAPC0IgegzIgiAAQgigMAAgnIAAjOQAAgnAigNIBjAAQAiANAAAnIAADOQAAAngiAMIgHAAIAZAhIAAASgAgOh3IAAC8IAFAEIAUAAIAEgEIAAi8IgEgFIgUAAg");
	this.shape_12.setTransform(21.45,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Bg
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AoxGbIlHAAIAAm+IgBAAIAAl3IFIAAIWrAAIAAG2Ij7AAIAAF/g");
	this.shape_13.setTransform(65.25,41.125);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.7,0,178,86.5);


(lib.g_txt_connect_to_excellence = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape.setTransform(176.5,66.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_1.setTransform(158.8,66.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_2.setTransform(139.9,66.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_3.setTransform(122.15,66.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_4.setTransform(106.5,66.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_5.setTransform(91.05,66.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_6.setTransform(74.7,66.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_7.setTransform(57,66.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAVCbIgThvIgDAAIgUBvIhAAAIAAg0IAhhnIghhmIAAg0IBAAAIAUBvIADAAIAThvIBBAAIAAA0IghBmIAhBnIAAA0g");
	this.shape_8.setTransform(38.35,66.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_9.setTransform(20.8,66.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAADNQAAAogiAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_10.setTransform(173.9,28.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgiCbIAAj0IgxAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape_11.setTransform(155.85,28.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape_12.setTransform(132.2,28.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_13.setTransform(114.15,28.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_14.setTransform(96.4,28.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_15.setTransform(78.7,28.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_16.setTransform(59.8,28.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAADNQAAAoghAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_17.setTransform(40.9,28.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_18.setTransform(22,28.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(1,1,1).p("AvTnaIenAAIAAO1I+nAAg");
	this.shape_19.setTransform(98,46.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-2,199,126);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo_H
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFAAIABgBIAAgTIgQggIAAAAIgEgBIAAgEIAWAAIAAAEIgGABIAAAAIAKAZIABAAIALgZIAAAAIgHgBIAAgEIASAAIAAAEIgDABIgBAAIgPAfIAAAUIAAABIAFAAIAAAEg");
	this.shape.setTransform(153.5955,36.2952,1.1861,1.1852);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIABAAIAAgzIgDAAQgGAAgCABQgCACgCAHIgEAAIAAgPIAvAAIAAAPIgEAAQgBgHgCgCQgCgBgHgBIgCAAIAAA0IAAAAIAFAAIAAAFg");
	this.shape_1.setTransform(146.3902,36.3249,1.1861,1.1852);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAGgBIAAAAIAAgyIAAgBIgGAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_2.setTransform(140.786,36.2656,1.1861,1.1852);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgKgDgFgCQgFgEgBgIQAAgHAFgFQAFgGALAAQAKAAAIAFIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANADQAUADAAAOQAAAHgFAFQgGAHgMAAQgNAAgHgGg");
	this.shape_3.setTransform(135.5673,36.2952,1.1861,1.1852);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIAAAAIAGABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQATABAAAQQAAANgMADIANAWIADABIADACIAAADgAgJAAIAHAAQAEAAADgDQACgEAAgGQABgMgKAAIgHAAg");
	this.shape_4.setTransform(128.3916,36.2656,1.1861,1.1852);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAFgBIABAAIAAgzIgBAAIgFgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAWIAGAAQAFAAACgBQABgBABgGIAEAAIAAAUIgEAAIAAABQgBgGgBgBQgCgCgFAAIgGAAIAAAZIAKAAQAHAAACgBQADgCACgJIAEAAIAAARg");
	this.shape_5.setTransform(121.0084,36.2952,1.1861,1.1852);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAfIgSg4IgBAAIgEgBIAAgEIAWAAIAAAEIgFABIgBAAIANAsIAAAAIAOgsIAAAAIgGgBIAAgEIASAAIAAAEIgFABIAAAAIgSA4g");
	this.shape_6.setTransform(113.5954,36.2952,1.1861,1.1852);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_7.setTransform(107.5762,36.2656,1.1861,1.1852);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPAfIgegvIgBAAIAAAqIABAAIAFABIAAAEIgSAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIARAAIAcAtIAAgnIgBgBIgFAAIAAgFIASAAIAAAFIgFAAIgBABIAAA3g");
	this.shape_8.setTransform(101.2604,36.2656,1.1861,1.1852);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAJIAAgiIAAAAIgFgBIAAgEIAWAAIAAAEIgFABIgBAAIAAAiQAAARANAAQAPAAAAgRIAAgiIgBAAIgFgBIAAgEIARAAIAAAEIgFABIAAAAIAAAiQAAAWgXAAQgWAAAAgWg");
	this.shape_9.setTransform(93.0172,36.2952,1.1861,1.1852);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIABAAIAFABIAAAEIgXAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAaAAIAAAAQATABAAARQAAAMgMADIANAWQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAIAEABIAAADgAgJAAIAHAAQAJAAAAgMQAAgNgJAAIgHAAg");
	this.shape_10.setTransform(167.6207,23.466,1.1861,1.1852);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAGgBIAAAAIAAgzIAAAAIgGgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAXIAGAAQAGAAABgCIACgHIAEAAIAAAUIgEAAQAAgFgCgBQgBgCgGAAIgGAAIAAAZIAKAAQAIAAACgBQACgCACgJIAEAAIAAARg");
	this.shape_11.setTransform(160.2078,23.4956,1.1861,1.1852);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgLgDgEgCQgFgEAAgIQAAgHADgFQAGgHALABQALgBAHAGIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANACQAUAEAAAOQAAAHgFAFQgGAIgMAAQgNAAgHgHg");
	this.shape_12.setTransform(153.5955,23.5252,1.1861,1.1852);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAHAfIAAgFIAGAAIAAAAIgEgLIgVAAIgEALIABAAIAFAAIAAAFIgSAAIAAgFIAFAAIAAAAIAUg4IAIAAIATA4IABAAIAEAAIAAAFgAgKAKIASAAIgJgcg");
	this.shape_13.setTransform(146.0936,23.5252,1.1861,1.1852);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgGAAIAAAWIAAAAIAFABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQAUABgBARQAAAMgMADIANAWIADACIAEABIAAADgAgJAAIAHAAQAKAAAAgMQAAgNgJAAIgIAAg");
	this.shape_14.setTransform(138.2953,23.466,1.1861,1.1852);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVAfIAAgFIAFAAIABAAIAAgzIgBgBIgFAAIAAgEIArAAIAAAOIgEAAQgCgGgCgCQgCgBgGgBIgKAAIAAAZIAFAAQAGAAABgBQACgBABgGIAEAAIAAAUIgEAAQgBgGgCAAQgBgCgFAAIgGAAIAAAXIAAAAIAEAAIAAAFg");
	this.shape_15.setTransform(130.9713,23.5252,1.1861,1.1852);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAPAfIgegwIAAArIAAAAIAFAAIAAAFIgSAAIAAgFIAGAAIAAAAIAAgzIAAgBIgGAAIAAgEIARAAIAcAtIAAgoIgBgBIgFAAIAAgEIASAAIAAAEIgFAAIgBABIAAA4g");
	this.shape_16.setTransform(120.5932,23.5252,1.1861,1.1852);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTAXQgEgIAAgPQAAgfAYABQAXAAAAAeQAAAfgYABQgNgBgGgIgAgJgSQgCAGAAAMQAAAMACAGQADAIAGAAQAIAAADgIQABgFAAgOQAAgNgCgEQgCgIgIAAQgGABgDAHg");
	this.shape_17.setTransform(112.8838,23.5252,1.1861,1.1852);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAfIAAgFIAFAAIAAAAIAAgsIAAAAIgOAnIgIAAIgPgnIgBAAIAAAsIABAAIAFAAIAAAFIgRAAIAAgFIAEAAIABAAIAAgzIgBgBIgEAAIAAgEIATAAIAOAnIAAAAIANgnIATAAIAAAEIgEAAIgBABIAAAzIABAAIAEAAIAAAFg");
	this.shape_18.setTransform(104.611,23.5252,1.1861,1.1852);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIAAAAIAAgzIAAgBIgFAAIAAgEIAVAAIAAAEIgFAAIAAABIAAAzIAAAAIAFAAIAAAFg");
	this.shape_19.setTransform(97.7318,23.5252,1.1861,1.1852);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAFAAQACARAOAAQAMAAAAgLQAAgIgLgCQgLgDgEgCQgGgEAAgIQAAgHAEgFQAGgHAKABQALgBAHAGIAAAOIgFAAQgDgPgKAAQgLAAAAAKQAAAIAOACQATAEAAAOQAAAHgEAFQgHAIgLAAQgNAAgIgHg");
	this.shape_20.setTransform(92.4538,23.5252,1.1861,1.1852);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABMA/QgIgFgFgIQgDgGgBgFIgBgVIgChYIAMABIAMgBIgCBSIABAVQABAGADAEQAEAFAJAEQAKAEALAAQAQAAAJgGQAFgDAEgEQADgFABgHIABgXIgBg+IgBgQIAKABIALgBIgBBPQAAAZgEALQgDAJgLAJQgPAJgZABQgbAAgNgKgAiWBIQgLgCgNgGQAEgLACgLQAIAIAHADQAKAFAMAAQAMAAAIgHQAIgGAAgLQAAgKgLgIIgTgKQgMgFgIgFQgOgJAAgTQAAgRALgLQAMgMAVABQAMAAAIACIAOAEIgEAIIgDALQgKgHgIgDIgOgCQgKAAgGAGQgGAFAAAJQAAAJAJAHQAGAFAVALQATAHAGAKQAFAIAAAKQAAAOgKAMQgNASgdAAgAg1BGIABgUIgBh4IA8ABIAQgBIgBAKIABAKIg1gCIAAAqIAZAAQAIAAAQgCIgBAKIAAAKQgNgCgNAAIgXAAIAAASQAAAdACARg");
	this.shape_21.setTransform(56.1899,28.3843,1.1861,1.1852);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A6192E").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_22.setTransform(40.0594,19.9994,1.1861,1.1852);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.8,40);


// stage content:
(lib.banner_300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(0.1,26.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(428));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("A3bGQIAAsfMAu3AAAIAAMfg");
	this.shape.setTransform(150,40);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(428));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_155 = new cjs.Graphics().p("AgETiMAAAgnDIAJAAMAAAAnDg");
	var mask_graphics_156 = new cjs.Graphics().p("AgHTiMAAAgnDIAQAAMAAAAnDg");
	var mask_graphics_157 = new cjs.Graphics().p("AgSTiMAAAgnDIAlAAMAAAAnDg");
	var mask_graphics_158 = new cjs.Graphics().p("AgkTiMAAAgnDIBJAAMAAAAnDg");
	var mask_graphics_159 = new cjs.Graphics().p("Ag9TiMAAAgnDIB7AAMAAAAnDg");
	var mask_graphics_160 = new cjs.Graphics().p("AhdTiMAAAgnDIC7AAMAAAAnDg");
	var mask_graphics_161 = new cjs.Graphics().p("AiETiMAAAgnDIEJAAMAAAAnDg");
	var mask_graphics_162 = new cjs.Graphics().p("AiyTiMAAAgnDIFlAAMAAAAnDg");
	var mask_graphics_163 = new cjs.Graphics().p("AjoTiMAAAgnDIHRAAMAAAAnDg");
	var mask_graphics_164 = new cjs.Graphics().p("AkkTiMAAAgnDIJJAAMAAAAnDg");
	var mask_graphics_165 = new cjs.Graphics().p("AlnTiMAAAgnDILQAAMAAAAnDg");
	var mask_graphics_166 = new cjs.Graphics().p("AmyTiMAAAgnDINlAAMAAAAnDg");
	var mask_graphics_167 = new cjs.Graphics().p("AoETiMAAAgnDIQJAAMAAAAnDg");
	var mask_graphics_168 = new cjs.Graphics().p("ApdTiMAAAgnDIS7AAMAAAAnDg");
	var mask_graphics_169 = new cjs.Graphics().p("Aq9TiMAAAgnDIV7AAMAAAAnDg");
	var mask_graphics_170 = new cjs.Graphics().p("AsiTiMAAAgnDIZFAAMAAAAnDg");
	var mask_graphics_171 = new cjs.Graphics().p("AuCTiMAAAgnDIcFAAMAAAAnDg");
	var mask_graphics_172 = new cjs.Graphics().p("AvbTiMAAAgnDIe3AAMAAAAnDg");
	var mask_graphics_173 = new cjs.Graphics().p("AwtTiMAAAgnDMAhbAAAMAAAAnDg");
	var mask_graphics_174 = new cjs.Graphics().p("Ax3TiMAAAgnDMAjvAAAMAAAAnDg");
	var mask_graphics_175 = new cjs.Graphics().p("Ay7TiMAAAgnDMAl3AAAMAAAAnDg");
	var mask_graphics_176 = new cjs.Graphics().p("Az3TiMAAAgnDMAnvAAAMAAAAnDg");
	var mask_graphics_177 = new cjs.Graphics().p("A0tTiMAAAgnDMApbAAAMAAAAnDg");
	var mask_graphics_178 = new cjs.Graphics().p("A1bTiMAAAgnDMAq3AAAMAAAAnDg");
	var mask_graphics_179 = new cjs.Graphics().p("A2CTiMAAAgnDMAsFAAAMAAAAnDg");
	var mask_graphics_180 = new cjs.Graphics().p("A2iTiMAAAgnDMAtFAAAMAAAAnDg");
	var mask_graphics_181 = new cjs.Graphics().p("A27TiMAAAgnDMAt3AAAMAAAAnDg");
	var mask_graphics_182 = new cjs.Graphics().p("A3NTiMAAAgnDMAubAAAMAAAAnDg");
	var mask_graphics_183 = new cjs.Graphics().p("A3XTiMAAAgnDMAuvAAAMAAAAnDg");
	var mask_graphics_184 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_395 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_396 = new cjs.Graphics().p("A3YTiMAAAgnDMAuxAAAMAAAAnDg");
	var mask_graphics_397 = new cjs.Graphics().p("A3PTiMAAAgnDMAufAAAMAAAAnDg");
	var mask_graphics_398 = new cjs.Graphics().p("A2/TiMAAAgnDMAt/AAAMAAAAnDg");
	var mask_graphics_399 = new cjs.Graphics().p("A2pTiMAAAgnDMAtTAAAMAAAAnDg");
	var mask_graphics_400 = new cjs.Graphics().p("A2NTiMAAAgnDMAsbAAAMAAAAnDg");
	var mask_graphics_401 = new cjs.Graphics().p("A1rTiMAAAgnDMArXAAAMAAAAnDg");
	var mask_graphics_402 = new cjs.Graphics().p("A1CTiMAAAgnDMAqFAAAMAAAAnDg");
	var mask_graphics_403 = new cjs.Graphics().p("A0UTiMAAAgnDMAopAAAMAAAAnDg");
	var mask_graphics_404 = new cjs.Graphics().p("AzfTiMAAAgnDMAm/AAAMAAAAnDg");
	var mask_graphics_405 = new cjs.Graphics().p("AykTiMAAAgnDMAlJAAAMAAAAnDg");
	var mask_graphics_406 = new cjs.Graphics().p("AxjTiMAAAgnDMAjHAAAMAAAAnDg");
	var mask_graphics_407 = new cjs.Graphics().p("AwbTiMAAAgnDMAg3AAAMAAAAnDg");
	var mask_graphics_408 = new cjs.Graphics().p("AvNTiMAAAgnDIebAAMAAAAnDg");
	var mask_graphics_409 = new cjs.Graphics().p("At5TiMAAAgnDIbzAAMAAAAnDg");
	var mask_graphics_410 = new cjs.Graphics().p("AsfTiMAAAgnDIY/AAMAAAAnDg");
	var mask_graphics_411 = new cjs.Graphics().p("ArATiMAAAgnDIWBAAMAAAAnDg");
	var mask_graphics_412 = new cjs.Graphics().p("ApmTiMAAAgnDITNAAMAAAAnDg");
	var mask_graphics_413 = new cjs.Graphics().p("AoSTiMAAAgnDIQlAAMAAAAnDg");
	var mask_graphics_414 = new cjs.Graphics().p("AnETiMAAAgnDIOJAAMAAAAnDg");
	var mask_graphics_415 = new cjs.Graphics().p("Al8TiMAAAgnDIL5AAMAAAAnDg");
	var mask_graphics_416 = new cjs.Graphics().p("Ak7TiMAAAgnDIJ3AAMAAAAnDg");
	var mask_graphics_417 = new cjs.Graphics().p("AkATiMAAAgnDIIBAAMAAAAnDg");
	var mask_graphics_418 = new cjs.Graphics().p("AjLTiMAAAgnDIGXAAMAAAAnDg");
	var mask_graphics_419 = new cjs.Graphics().p("AidTiMAAAgnDIE7AAMAAAAnDg");
	var mask_graphics_420 = new cjs.Graphics().p("Ah0TiMAAAgnDIDpAAMAAAAnDg");
	var mask_graphics_421 = new cjs.Graphics().p("AhSTiMAAAgnDIClAAMAAAAnDg");
	var mask_graphics_422 = new cjs.Graphics().p("Ag2TiMAAAgnDIBtAAMAAAAnDg");
	var mask_graphics_423 = new cjs.Graphics().p("AggTiMAAAgnDIBBAAMAAAAnDg");
	var mask_graphics_424 = new cjs.Graphics().p("AgQTiMAAAgnDIAiAAMAAAAnDg");
	var mask_graphics_425 = new cjs.Graphics().p("AgHTiMAAAgnDIAPAAMAAAAnDg");
	var mask_graphics_426 = new cjs.Graphics().p("AgETiMAAAgnDIAJAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(155).to({graphics:mask_graphics_155,x:300,y:125}).wait(1).to({graphics:mask_graphics_156,x:299.65,y:125}).wait(1).to({graphics:mask_graphics_157,x:298.575,y:125}).wait(1).to({graphics:mask_graphics_158,x:296.8,y:125}).wait(1).to({graphics:mask_graphics_159,x:294.3,y:125}).wait(1).to({graphics:mask_graphics_160,x:291.075,y:125}).wait(1).to({graphics:mask_graphics_161,x:287.15,y:125}).wait(1).to({graphics:mask_graphics_162,x:282.525,y:125}).wait(1).to({graphics:mask_graphics_163,x:277.15,y:125}).wait(1).to({graphics:mask_graphics_164,x:271.1,y:125}).wait(1).to({graphics:mask_graphics_165,x:264.35,y:125}).wait(1).to({graphics:mask_graphics_166,x:256.825,y:125}).wait(1).to({graphics:mask_graphics_167,x:248.65,y:125}).wait(1).to({graphics:mask_graphics_168,x:239.725,y:125}).wait(1).to({graphics:mask_graphics_169,x:230.075,y:125}).wait(1).to({graphics:mask_graphics_170,x:219.925,y:125}).wait(1).to({graphics:mask_graphics_171,x:210.275,y:125}).wait(1).to({graphics:mask_graphics_172,x:201.35,y:125}).wait(1).to({graphics:mask_graphics_173,x:193.175,y:125}).wait(1).to({graphics:mask_graphics_174,x:185.675,y:125}).wait(1).to({graphics:mask_graphics_175,x:178.9,y:125}).wait(1).to({graphics:mask_graphics_176,x:172.85,y:125}).wait(1).to({graphics:mask_graphics_177,x:167.475,y:125}).wait(1).to({graphics:mask_graphics_178,x:162.85,y:125}).wait(1).to({graphics:mask_graphics_179,x:158.925,y:125}).wait(1).to({graphics:mask_graphics_180,x:155.7,y:125}).wait(1).to({graphics:mask_graphics_181,x:153.2,y:125}).wait(1).to({graphics:mask_graphics_182,x:151.425,y:125}).wait(1).to({graphics:mask_graphics_183,x:150.35,y:125}).wait(1).to({graphics:mask_graphics_184,x:150,y:125}).wait(211).to({graphics:mask_graphics_395,x:150,y:125}).wait(1).to({graphics:mask_graphics_396,x:149.7,y:125}).wait(1).to({graphics:mask_graphics_397,x:148.75,y:125}).wait(1).to({graphics:mask_graphics_398,x:147.2,y:125}).wait(1).to({graphics:mask_graphics_399,x:144.975,y:125}).wait(1).to({graphics:mask_graphics_400,x:142.175,y:125}).wait(1).to({graphics:mask_graphics_401,x:138.725,y:125}).wait(1).to({graphics:mask_graphics_402,x:134.65,y:125}).wait(1).to({graphics:mask_graphics_403,x:129.95,y:125}).wait(1).to({graphics:mask_graphics_404,x:124.65,y:125}).wait(1).to({graphics:mask_graphics_405,x:118.675,y:125}).wait(1).to({graphics:mask_graphics_406,x:112.1,y:125}).wait(1).to({graphics:mask_graphics_407,x:104.9,y:125}).wait(1).to({graphics:mask_graphics_408,x:97.075,y:125}).wait(1).to({graphics:mask_graphics_409,x:88.625,y:125}).wait(1).to({graphics:mask_graphics_410,x:79.525,y:125}).wait(1).to({graphics:mask_graphics_411,x:69.975,y:125}).wait(1).to({graphics:mask_graphics_412,x:60.875,y:125}).wait(1).to({graphics:mask_graphics_413,x:52.425,y:125}).wait(1).to({graphics:mask_graphics_414,x:44.6,y:125}).wait(1).to({graphics:mask_graphics_415,x:37.4,y:125}).wait(1).to({graphics:mask_graphics_416,x:30.825,y:125}).wait(1).to({graphics:mask_graphics_417,x:24.85,y:125}).wait(1).to({graphics:mask_graphics_418,x:19.55,y:125}).wait(1).to({graphics:mask_graphics_419,x:14.85,y:125}).wait(1).to({graphics:mask_graphics_420,x:10.775,y:125}).wait(1).to({graphics:mask_graphics_421,x:7.325,y:125}).wait(1).to({graphics:mask_graphics_422,x:4.525,y:125}).wait(1).to({graphics:mask_graphics_423,x:2.3,y:125}).wait(1).to({graphics:mask_graphics_424,x:0.75,y:125}).wait(1).to({graphics:mask_graphics_425,x:-0.175,y:125}).wait(1).to({graphics:mask_graphics_426,x:-0.5,y:125}).wait(2));

	// Connect_to_Excellence_Nature
	this.instance_1 = new lib.g_txt_connect_to_excellence("single",1);
	this.instance_1.setTransform(144.95,153,1,1,0,0,0,98.5,61.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(273).to({_off:false},0).to({x:134.95,alpha:1},30,cjs.Ease.quadInOut).to({_off:true},124).wait(1));

	// g_txt_02_Nature
	this.instance_2 = new lib.g_txt02_Nature("synched",0);
	this.instance_2.setTransform(33.55,105.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(155).to({_off:false},0).wait(110).to({startPosition:0},0).to({x:28.55,alpha:0},30,cjs.Ease.quadInOut).to({_off:true},1).wait(132));

	// Red
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	this.shape_1.setTransform(305,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("Ag0TiMAAAgnDIBpAAMAAAAnDg");
	this.shape_2.setTransform(304.65,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("Ag/TiMAAAgnDIB/AAMAAAAnDg");
	this.shape_3.setTransform(303.525,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("AhQTiMAAAgnDIChAAMAAAAnDg");
	this.shape_4.setTransform(301.7,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("AhoTiMAAAgnDIDRAAMAAAAnDg");
	this.shape_5.setTransform(299.1,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("AiHTiMAAAgnDIEPAAMAAAAnDg");
	this.shape_6.setTransform(295.775,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("AitTiMAAAgnDIFbAAMAAAAnDg");
	this.shape_7.setTransform(291.725,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("AjaTiMAAAgnDIG1AAMAAAAnDg");
	this.shape_8.setTransform(286.95,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("AkOTiMAAAgnDIIdAAMAAAAnDg");
	this.shape_9.setTransform(281.425,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("AlITiMAAAgnDIKRAAMAAAAnDg");
	this.shape_10.setTransform(275.125,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("AmKTiMAAAgnDIMVAAMAAAAnDg");
	this.shape_11.setTransform(268.125,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("AnSTiMAAAgnDIOlAAMAAAAnDg");
	this.shape_12.setTransform(260.375,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("AoiTiMAAAgnDIRFAAMAAAAnDg");
	this.shape_13.setTransform(251.925,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("Ap4TiMAAAgnDITxAAMAAAAnDg");
	this.shape_14.setTransform(242.725,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("ArVTiMAAAgnDIWrAAMAAAAnDg");
	this.shape_15.setTransform(232.75,125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("As3TiMAAAgnDIZvAAMAAAAnDg");
	this.shape_16.setTransform(222.25,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("AuUTiMAAAgnDIcpAAMAAAAnDg");
	this.shape_17.setTransform(212.275,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("AvqTiMAAAgnDIfVAAMAAAAnDg");
	this.shape_18.setTransform(203.075,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("Aw6TiMAAAgnDMAh1AAAMAAAAnDg");
	this.shape_19.setTransform(194.625,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("AyCTiMAAAgnDMAkFAAAMAAAAnDg");
	this.shape_20.setTransform(186.875,125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("AzETiMAAAgnDMAmJAAAMAAAAnDg");
	this.shape_21.setTransform(179.875,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("Az+TiMAAAgnDMAn9AAAMAAAAnDg");
	this.shape_22.setTransform(173.575,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("A0yTiMAAAgnDMAplAAAMAAAAnDg");
	this.shape_23.setTransform(168.05,125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CC0633").s().p("A1fTiMAAAgnDMAq/AAAMAAAAnDg");
	this.shape_24.setTransform(163.275,125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CC0633").s().p("A2FTiMAAAgnDMAsLAAAMAAAAnDg");
	this.shape_25.setTransform(159.225,125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CC0633").s().p("A2kTiMAAAgnDMAtJAAAMAAAAnDg");
	this.shape_26.setTransform(155.9,125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CC0633").s().p("A28TiMAAAgnDMAt5AAAMAAAAnDg");
	this.shape_27.setTransform(153.3,125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CC0633").s().p("A3NTiMAAAgnDMAubAAAMAAAAnDg");
	this.shape_28.setTransform(151.475,125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CC0633").s().p("A3XTiMAAAgnDMAuvAAAMAAAAnDg");
	this.shape_29.setTransform(150.35,125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CC0633").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_30.setTransform(150,125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CC0633").s().p("A3YTiMAAAgnDMAuxAAAMAAAAnDg");
	this.shape_31.setTransform(149.7,125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#CC0633").s().p("A3PTiMAAAgnDMAufAAAMAAAAnDg");
	this.shape_32.setTransform(148.7,125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CC0633").s().p("A3ATiMAAAgnDMAuBAAAMAAAAnDg");
	this.shape_33.setTransform(147.1,125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#CC0633").s().p("A2rTiMAAAgnDMAtXAAAMAAAAnDg");
	this.shape_34.setTransform(144.825,125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CC0633").s().p("A2QTiMAAAgnDMAsgAAAMAAAAnDg");
	this.shape_35.setTransform(141.95,125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#CC0633").s().p("A1uTiMAAAgnDMArdAAAMAAAAnDg");
	this.shape_36.setTransform(138.375,125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#CC0633").s().p("A1HTiMAAAgnDMAqPAAAMAAAAnDg");
	this.shape_37.setTransform(134.2,125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CC0633").s().p("A0aTiMAAAgnDMAo1AAAMAAAAnDg");
	this.shape_38.setTransform(129.35,125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CC0633").s().p("AznTiMAAAgnDMAnPAAAMAAAAnDg");
	this.shape_39.setTransform(123.875,125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#CC0633").s().p("AytTiMAAAgnDMAlbAAAMAAAAnDg");
	this.shape_40.setTransform(117.725,125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#CC0633").s().p("AxuTiMAAAgnDMAjdAAAMAAAAnDg");
	this.shape_41.setTransform(110.975,125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#CC0633").s().p("AwoTiMAAAgnDMAhRAAAMAAAAnDg");
	this.shape_42.setTransform(103.55,125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CC0633").s().p("AvdTiMAAAgnDIe7AAMAAAAnDg");
	this.shape_43.setTransform(95.5,125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#CC0633").s().p("AuMTiMAAAgnDIcZAAMAAAAnDg");
	this.shape_44.setTransform(86.775,125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#CC0633").s().p("As0TiMAAAgnDIZpAAMAAAAnDg");
	this.shape_45.setTransform(77.4,125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#CC0633").s().p("ArYTiMAAAgnDIWxAAMAAAAnDg");
	this.shape_46.setTransform(67.6,125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#CC0633").s().p("AqATiMAAAgnDIUBAAMAAAAnDg");
	this.shape_47.setTransform(58.225,125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#CC0633").s().p("AovTiMAAAgnDIRfAAMAAAAnDg");
	this.shape_48.setTransform(49.5,125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#CC0633").s().p("AnkTiMAAAgnDIPJAAMAAAAnDg");
	this.shape_49.setTransform(41.45,125);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#CC0633").s().p("AmeTiMAAAgnDIM9AAMAAAAnDg");
	this.shape_50.setTransform(34.025,125);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#CC0633").s().p("AlfTiMAAAgnDIK/AAMAAAAnDg");
	this.shape_51.setTransform(27.275,125);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#CC0633").s().p("AklTiMAAAgnDIJLAAMAAAAnDg");
	this.shape_52.setTransform(21.125,125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#CC0633").s().p("AjyTiMAAAgnDIHlAAMAAAAnDg");
	this.shape_53.setTransform(15.65,125);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#CC0633").s().p("AjFTiMAAAgnDIGLAAMAAAAnDg");
	this.shape_54.setTransform(10.8,125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#CC0633").s().p("AieTiMAAAgnDIE9AAMAAAAnDg");
	this.shape_55.setTransform(6.625,125);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#CC0633").s().p("Ah9TiMAAAgnDID6AAMAAAAnDg");
	this.shape_56.setTransform(3.05,125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#CC0633").s().p("AhhTiMAAAgnDIDDAAMAAAAnDg");
	this.shape_57.setTransform(0.175,125);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#CC0633").s().p("AhMTiMAAAgnDICZAAMAAAAnDg");
	this.shape_58.setTransform(-2.1,125);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#CC0633").s().p("Ag9TiMAAAgnDIB7AAMAAAAnDg");
	this.shape_59.setTransform(-3.7,125);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1,p:{x:305}}]},155).to({state:[{t:this.shape_2,p:{x:304.65}}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},211).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_2,p:{x:-4.675}}]},1).to({state:[{t:this.shape_1,p:{x:-5}}]},1).to({state:[]},1).wait(1));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	mask_1.setTransform(150,125);

	// g_txt_01_Nature
	this.instance_3 = new lib.g_txt01_Nature("synched",0);
	this.instance_3.setTransform(-215.15,97.25);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(43).to({_off:false},0).to({x:23.5},28,cjs.Ease.quadInOut).to({_off:true},114).wait(243));

	// Photo_for_Nature
	this.instance_4 = new lib.Photo_nature();
	this.instance_4.setTransform(0,80,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(428));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149,125,151.5,125);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Photo_nature.jpg?1762449365730", id:"Photo_nature"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;