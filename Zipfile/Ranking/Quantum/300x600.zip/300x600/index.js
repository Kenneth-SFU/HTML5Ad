(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Photo = function() {
	this.initialize(img.Photo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,600);


(lib.g_txt02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.text = new cjs.Text("Learn how we're \nbuilding a better future, one breakthrough at a time.", "20px 'Lava FNI'", "#FFFFFF");
	this.text.lineHeight = 24;
	this.text.lineWidth = 251;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,255,109.6);


(lib.g_txt01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape.setTransform(187.1,60.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_1.setTransform(169.05,60.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAWCbIgGg9IgfAAIgGA9IhAAAIAAg0IAnkBIBdAAIAnEBIAAA0gAALAeIgJhhIgDAAIgJBhIAVAAg");
	this.shape_2.setTransform(150.4,60.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhTCbIAAk1ICFAAQAiAMAAAoIAABjQAAAmgiAMIhAAAIAABsgAgOgIIAZAAIAEgEIAAhSIgEgEIgZAAg");
	this.shape_3.setTransform(132.15,60.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAyCbIAAiwIgCAAIgWBEIgyAAIgWhEIgCAAIAACwIhBAAIAAk1IBLAAIAlBsIAEAAIAkhsIBLAAIAAE1g");
	this.shape_4.setTransform(110.25,60.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgvCbIAAhBIAOAAIAAizIgOAAIAAhBIBfAAIAABBIgNAAIAACzIANAAIAABBg");
	this.shape_5.setTransform(92,60.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_6.setTransform(72.35,60.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAVCbIgEg9IggAAIgGA9IhAAAIAAg0IAnkBIBdAAIAnEBIAAA0gAALAeIgJhhIgDAAIgJBhIAVAAg");
	this.shape_7.setTransform(55.1,60.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_8.setTransform(37.55,60.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAcCbIgnh5IgHAAIAAB5IhFAAIAAk1ICGAAQAhAMAAAoIAABCQAAAkgdAMIAlBjIAAAsgAgSgVIAZAAIAEgEIAAhFIgEgEIgZAAg");
	this.shape_9.setTransform(20.35,60.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAcCbIgmh5IgIAAIAAB5IhFAAIAAk1ICFAAQAiAMAAAoIAABCQAAAkgdAMIAlBjIAAAsgAgSgVIAZAAIAEgEIAAhFIgEgEIgZAAg");
	this.shape_10.setTransform(197.25,22.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAADNQAAAogiAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_11.setTransform(177.95,22.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AhGCbIAAk1ICNAAIAABBIhIAAIAAA8IBEAAIAAA/IhEAAIAAB5g");
	this.shape_12.setTransform(160.35,22.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAxCbIAAiwIgBAAIgWBEIgyAAIgWhEIgDAAIAACwIhAAAIAAk1IBLAAIAlBsIAEAAIAkhsIBLAAIAAE1g");
	this.shape_13.setTransform(133.3,22.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgvCbQgigMAAgoIAAkBIBFAAIAAD4IAFAFIAQAAIAEgFIAAj4IBFAAIAAEBQAAAogiAMg");
	this.shape_14.setTransform(111.625,22.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape_15.setTransform(93.8,22.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAYCbIgqiHIgEAAIAACHIg9AAIAAk1IA9AAIApCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_16.setTransform(75.75,22.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAVCbIgEg9IghAAIgEA9IhBAAIAAg0IAnkBIBdAAIAnEBIAAA0gAALAeIgJhhIgDAAIgJBhIAVAAg");
	this.shape_17.setTransform(57.1,22.425);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgvCbQgigMAAgoIAAkBIBFAAIAAD4IAFAFIAQAAIAEgFIAAj4IBFAAIAAEBQAAAogiAMg");
	this.shape_18.setTransform(38.625,22.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAPC0IgegzIgiAAQgigMAAgnIAAjOQAAgnAigNIBkAAQAhANAAAnIAADOQAAAnghAMIgIAAIAaAhIAAASgAgOh3IAAC8IAEAEIAVAAIAEgEIAAi8IgEgFIgVAAg");
	this.shape_19.setTransform(19.95,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Bg
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AyiGbIABm+IgCAAIAAl3MAlGAAAIAAG7IhnAAIAAF6g");
	this.shape_20.setTransform(93.5,41.125);

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.2,0,240.1,86.5);


(lib.g_txt_connect_to_excellence = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAgAsIAAgGIAIgBQAFgCAAgHIAAgmQAAgKgEgFQgEgFgKABQgHgBgMAEIABALIAAArQAAAHAFACIAIABIAAAGIgpAAIAAgGIAIgBQAFgCAAgHIAAgmQAAgKgEgFQgEgFgKABQgHgBgLAEIAAA2QAAAHAFACIAIABIAAAGIgqAAIAAgGIAIgBQAFgCAAgHIAAg3QAAgDgCgCQgBgCgEAAIgIABIAAgGQAMgFAKAAQAJAAAAALIAAADQAOgNAPgBQAPAAAFAOQAPgOAQAAQAXAAAAAdIAAArQAAAHAFACIAIABIAAAGg");
	this.shape.setTransform(174.975,101.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgiAQIAAgsQAAgEgCgBQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAAuQAAALAEAEQAEAFAKAAQAGAAAMgEIAAg4IgBgFQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAA8QAAAHAEADQADACAIgBIAAAFQgHADgHAAQgQAAgCgMQgOANgPAAQgXAAAAgeg");
	this.shape_1.setTransform(161.775,101.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgNAlIAAg6IgQAAIAAgJIAQAAIAAgRIANgKIACABIAAAaIAaAAIAAAJIgaAAIAAAwQABALADAEQAEAEAKAAIAKgBIAAAIQgIAFgLAAQgXAAgBgVg");
	this.shape_2.setTransform(153.2,100.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAHAsIAAgGIAHgBQAGgCgBgHIAAgmQAAgKgDgFQgEgFgKABQgHgBgMAEIAAA2QAAAHAFACIAIABIAAAGIgqAAIAAgGIAIgBQAFgCAAgHIAAg3QAAgDgBgCQgCgCgEAAIgIABIAAgGQANgFAJAAQAJAAAAALIAAADQAPgNAOgBQAYAAAAAdIAAArQAAAHAFACIAHABIAAAGg");
	this.shape_3.setTransform(144.75,101.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMApQgDgDAAgHQgFAHgGADQgHAEgHAAQgKAAgGgGQgHgGAAgJQAAgTAagFIAWgGIAAgEQAAgMgFgEQgDgFgKAAQgMAAgPAEIAAgIQAQgJAUAAQAZAAAAAdIAAApQAAALANAAIACAAIAAAFQgHADgJAAQgJAAgDgEgAgDAFQgKACgEADQgFAEAAAFQAAANAPAAQAHAAAJgFIAAgZg");
	this.shape_4.setTransform(135.2,101.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiAQIAAgsQAAgEgCgBQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAAuQAAALAEAEQAEAFAKAAQAGAAAMgEIAAg4IgBgFQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAA8QAAAHAEADQADACAIgBIAAAFQgHADgHAAQgQAAgCgMQgOANgPAAQgXAAAAgeg");
	this.shape_5.setTransform(125.175,101.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAABAIAAgHIALgBQAFgBAAgIIAAghQgNAOgMAAQgOAAgKgMQgLgNAAgSQAAgWANgNQANgNATAAQAMAAAJAEIAIgCIACAAIAABsQAAAIAFABIAIABIAAAHgAgcgVQAAAiAcAAQAGABAKgGIAAg2QgLgHgJABQgYAAAAAfg");
	this.shape_6.setTransform(115.275,103.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AggBWIA0isIANAAIg1Csg");
	this.shape_7.setTransform(106.175,101.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AALApQgDgDAAgHQgEAHgGADQgHAEgIAAQgJAAgGgGQgHgGAAgJQAAgTAbgFIAUgGIAAgEQABgMgEgEQgFgFgJAAQgMAAgPAEIAAgIQAQgJAUAAQAZAAAAAdIAAApQAAALAMAAIADAAIAAAFQgHADgIAAQgKAAgEgEgAgCAFQgLACgEADQgFAEAAAFQAAANAOAAQAIAAAIgFIAAgZg");
	this.shape_8.setTransform(98.15,101.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZAiQgKgLAAgTQAAgVAMgOQAMgOATAAQALAAAIAFQAJAEAAAHQAAAEgDADQgCADgEAAQgEAAgHgIQgGgHgJAAQgJAAgGAIQgGAIAAAQQAAAiAcAAQAMAAAOgFIAAAJQgNAKgTAAQgRAAgKgMg");
	this.shape_9.setTransform(89.225,101.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNAAQAAgLANAAQAOAAAAALQAAAMgOAAQgNAAAAgMg");
	this.shape_10.setTransform(82.375,104.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgiAQIAAgsQAAgEgCgBQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAAuQAAALAEAEQAEAFAKAAQAGAAAMgEIAAg4IgBgFQgBgCgEAAIgIABIAAgHQAMgEAKAAQAJAAAAALIAAA8QAAAHAEADQADACAIgBIAAAFQgHADgHAAQgQAAgCgMQgOANgPAAQgXAAAAgeg");
	this.shape_11.setTransform(74.625,101.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggBEIAAgGIAIgBQAFgCAAgHIAAg8IgOAAIAAgJIAOAAIAAgBQAAgWAKgNQAJgOATAAQAPAAAAAIQAAAHgHAAIgHgCIgJgBQgJAAgCAHQgDAFAAAQIAAAKIAUAAIAAAJIgUAAIAAA8QAAAHAEACIAIABIAAAGg");
	this.shape_12.setTransform(67.325,99.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdAoIgBgYIAFAAQADAKAHAFQAHAGAHgBQASAAgBgMQAAgKgOgFIgJgDQgTgGgBgRQAAgMAJgIQAJgHAMgBQANABAMAGIABAUIgGABQgGgLgDgDQgFgFgHAAQgOAAAAANQAAAKALADIALAFQAVAGAAAQQAAANgJAIQgKAIgNgBQgNABgPgGg");
	this.shape_13.setTransform(59.4,101.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgNAlIAAg6IgPAAIAAgJIAPAAIAAgRIANgKIACABIAAAaIAaAAIAAAJIgaAAIAAAwQAAALAFAEQADAEAKAAIAJgBIAAAIQgHAFgLAAQgYAAAAgVg");
	this.shape_14.setTransform(47.55,100.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgTA/IAAgGIAIgBQAFgCAAgHIAAg3QAAgEgCgBQgBgCgEAAIgIABIAAgHQAMgEAJAAQAJAAAAALIAAA9QAAAHAFACIAIABIAAAGgAgIgqQgEgDAAgGQAAgFAEgDQADgDAFAAQAEAAADADQADADAAAFQAAAGgDADQgDADgEAAQgFAAgDgDg");
	this.shape_15.setTransform(41.775,99.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdAoIgBgYIAFAAQADAKAHAFQAHAGAHgBQASAAgBgMQAAgKgOgFIgJgDQgTgGgBgRQAAgMAJgIQAJgHAMgBQANABAMAGIABAUIgGABQgGgLgDgDQgFgFgHAAQgOAAAAANQAAAKALADIALAFQAVAGAAAQQAAANgJAIQgKAIgNgBQgNABgPgGg");
	this.shape_16.setTransform(35.1,101.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTA/IAAgGIAIgBQAFgCAAgHIAAg3QAAgEgCgBQgBgCgEAAIgIABIAAgHQAMgEAJAAQAJAAAAALIAAA9QAAAHAFACIAIABIAAAGgAgIgqQgEgDAAgGQAAgFAEgDQADgDAFAAQAEAAADADQADADAAAFQAAAGgDADQgDADgEAAQgFAAgDgDg");
	this.shape_17.setTransform(28.525,99.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgEBAIgnhtQgEgJgMgBIAAgHIAyAAIAAAHQgQABAAAIIAAADIAaBOIAghNIABgFQAAgHgQgBIAAgHIAqAAIAAAFQgMADgEAMIgrBqg");
	this.shape_18.setTransform(19.75,99.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_19.setTransform(176.5,68.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_20.setTransform(158.8,68.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_21.setTransform(139.9,68.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_22.setTransform(122.15,68.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_23.setTransform(106.5,68.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AhFCbIAAk1IBFAAIAAD0IBGAAIAABBg");
	this.shape_24.setTransform(91.05,68.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_25.setTransform(74.7,68.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_26.setTransform(57,68.175);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAVCbIgThvIgDAAIgUBvIhAAAIAAg0IAhhnIghhmIAAg0IBAAAIAUBvIADAAIAThvIBBAAIAAA0IghBmIAhBnIAAA0g");
	this.shape_27.setTransform(38.35,68.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_28.setTransform(20.8,68.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAADNQAAAogiAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_29.setTransform(173.9,30.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgiCbIAAj0IgxAAIAAhBICnAAIAABBIgxAAIAAD0g");
	this.shape_30.setTransform(155.85,30.175);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AghCbIAAj0IgyAAIAAhBICnAAIAABBIgyAAIAAD0g");
	this.shape_31.setTransform(132.2,30.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBjAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAogiAMg");
	this.shape_32.setTransform(114.15,30.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AhHCbIAAk1ICNAAIAABBIhIAAIAAA4IBEAAIAAA/IhEAAIAAA8IBKAAIAABBg");
	this.shape_33.setTransform(96.4,30.175);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_34.setTransform(78.7,30.175);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAYCbIgqiHIgFAAIAACHIg8AAIAAk1IA8AAIAqCHIAFAAIAAiHIA8AAIAAE1g");
	this.shape_35.setTransform(59.8,30.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAADNQAAAoghAMgAgOheIAAC8IAFAFIAUAAIAEgFIAAi8IgEgEIgUAAg");
	this.shape_36.setTransform(40.9,30.175);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgxCbQgigMAAgoIAAjNQAAgoAigMIBkAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgUAAIgFAEIAAC8IAFAFIAUAAIAEgFIAAhBIBFAAIAABKQAAAoghAMg");
	this.shape_37.setTransform(22,30.175);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1,1,1).p("AvYpmIexAAIAATNI+xAAg");
	this.shape_38.setTransform(98.5,61.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,199,125);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo_H
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFAAIABgBIAAgTIgQggIAAAAIgEgBIAAgEIAWAAIAAAEIgGABIAAAAIAKAZIABAAIALgZIAAAAIgHgBIAAgEIASAAIAAAEIgDABIgBAAIgPAfIAAAUIAAABIAFAAIAAAEg");
	this.shape.setTransform(153.5896,36.2948,1.186,1.1851);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIABAAIAAgzIgDAAQgGAAgCABQgCACgCAHIgEAAIAAgPIAvAAIAAAPIgEAAQgBgHgCgCQgCgBgHgBIgCAAIAAA0IAAAAIAFAAIAAAFg");
	this.shape_1.setTransform(146.3845,36.3244,1.186,1.1851);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAGgBIAAAAIAAgyIAAgBIgGAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_2.setTransform(140.7806,36.2651,1.186,1.1851);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgKgDgFgCQgFgEgBgIQAAgHAFgFQAFgGALAAQAKAAAIAFIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANADQAUADAAAOQAAAHgFAFQgGAHgMAAQgNAAgHgGg");
	this.shape_3.setTransform(135.5621,36.2948,1.186,1.1851);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIAAAAIAGABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQATABAAAQQAAANgMADIANAWIADABIADACIAAADgAgJAAIAHAAQAEAAADgDQACgEAAgGQABgMgKAAIgHAAg");
	this.shape_4.setTransform(128.3867,36.2651,1.186,1.1851);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAFgBIABAAIAAgzIgBAAIgFgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAWIAGAAQAFAAACgBQABgBABgGIAEAAIAAAUIgEAAIAAABQgBgGgBgBQgCgCgFAAIgGAAIAAAZIAKAAQAHAAACgBQADgCACgJIAEAAIAAARg");
	this.shape_5.setTransform(121.0037,36.2948,1.186,1.1851);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEAfIgSg4IgBAAIgEgBIAAgEIAWAAIAAAEIgFABIgBAAIANAsIAAAAIAOgsIAAAAIgGgBIAAgEIASAAIAAAEIgFABIAAAAIgSA4g");
	this.shape_6.setTransform(113.5911,36.2948,1.186,1.1851);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKAfIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAVAAIAAAFIgFAAIAAABIAAAyIAAAAIAFABIAAAEg");
	this.shape_7.setTransform(107.572,36.2651,1.186,1.1851);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPAfIgegvIgBAAIAAAqIABAAIAFABIAAAEIgSAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIARAAIAcAtIAAgnIgBgBIgFAAIAAgFIASAAIAAAFIgFAAIgBABIAAA3g");
	this.shape_8.setTransform(101.2565,36.2651,1.186,1.1851);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAJIAAgiIAAAAIgFgBIAAgEIAWAAIAAAEIgFABIgBAAIAAAiQAAARANAAQAPAAAAgRIAAgiIgBAAIgFgBIAAgEIARAAIAAAEIgFABIAAAAIAAAiQAAAWgXAAQgWAAAAgWg");
	this.shape_9.setTransform(93.0136,36.2948,1.186,1.1851);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgHAAIAAAWIABAAIAFABIAAAEIgXAAIAAgEIAFgBIABAAIAAgyIgBgBIgFAAIAAgFIAaAAIAAAAQATABAAARQAAAMgMADIANAWQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAIAEABIAAADgAgJAAIAHAAQAJAAAAgMQAAgNgJAAIgHAAg");
	this.shape_10.setTransform(167.6143,23.4657,1.186,1.1851);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgWAfIAAgEIAGgBIAAAAIAAgzIAAAAIgGgBIAAgEIAsAAIAAAPIgEAAQgCgHgCgCQgCgBgHAAIgKAAIAAAXIAGAAQAGAAABgCIACgHIAEAAIAAAUIgEAAQAAgFgCgBQgBgCgGAAIgGAAIAAAZIAKAAQAIAAACgBQACgCACgJIAEAAIAAARg");
	this.shape_11.setTransform(160.2016,23.4953,1.186,1.1851);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAEAAQADARAOAAQAMAAAAgLQAAgIgMgCQgLgDgEgCQgFgEAAgIQAAgHADgFQAGgHALABQALgBAHAGIAAAOIgEAAQgEgPgLAAQgKAAAAAKQAAAIANACQAUAEAAAOQAAAHgFAFQgGAIgMAAQgNAAgHgHg");
	this.shape_12.setTransform(153.5896,23.5249,1.186,1.1851);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAHAfIAAgFIAGAAIAAAAIgEgLIgVAAIgEALIABAAIAFAAIAAAFIgSAAIAAgFIAFAAIAAAAIAUg4IAIAAIATA4IABAAIAEAAIAAAFgAgKAKIASAAIgJgcg");
	this.shape_13.setTransform(146.088,23.5249,1.186,1.1851);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAfIgNgbIgGAAIAAAWIAAAAIAFABIAAAEIgXAAIAAgEIAGgBIABAAIAAgyIgBgBIgGAAIAAgFIAaAAIAAAAQAUABgBARQAAAMgMADIANAWIADACIAEABIAAADgAgJAAIAHAAQAKAAAAgMQAAgNgJAAIgIAAg");
	this.shape_14.setTransform(138.2899,23.4657,1.186,1.1851);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVAfIAAgFIAFAAIABAAIAAgzIgBgBIgFAAIAAgEIArAAIAAAOIgEAAQgCgGgCgCQgCgBgGgBIgKAAIAAAZIAFAAQAGAAABgBQACgBABgGIAEAAIAAAUIgEAAQgBgGgCAAQgBgCgFAAIgGAAIAAAXIAAAAIAEAAIAAAFg");
	this.shape_15.setTransform(130.9663,23.5249,1.186,1.1851);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAPAfIgegwIAAArIAAAAIAFAAIAAAFIgSAAIAAgFIAGAAIAAAAIAAgzIAAgBIgGAAIAAgEIARAAIAcAtIAAgoIgBgBIgFAAIAAgEIASAAIAAAEIgFAAIgBABIAAA4g");
	this.shape_16.setTransform(120.5886,23.5249,1.186,1.1851);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTAXQgEgIAAgPQAAgfAYABQAXAAAAAeQAAAfgYABQgNgBgGgIgAgJgSQgCAGAAAMQAAAMACAGQADAIAGAAQAIAAADgIQABgFAAgOQAAgNgCgEQgCgIgIAAQgGABgDAHg");
	this.shape_17.setTransform(112.8794,23.5249,1.186,1.1851);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAfIAAgFIAFAAIAAAAIAAgsIAAAAIgOAnIgIAAIgPgnIgBAAIAAAsIABAAIAFAAIAAAFIgRAAIAAgFIAEAAIABAAIAAgzIgBgBIgEAAIAAgEIATAAIAOAnIAAAAIANgnIATAAIAAAEIgEAAIgBABIAAAzIABAAIAEAAIAAAFg");
	this.shape_18.setTransform(104.607,23.5249,1.186,1.1851);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAfIAAgFIAFAAIAAAAIAAgzIAAgBIgFAAIAAgEIAVAAIAAAEIgFAAIAAABIAAAzIAAAAIAFAAIAAAFg");
	this.shape_19.setTransform(97.728,23.5249,1.186,1.1851);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAZIAAgQIAFAAQACARAOAAQAMAAAAgLQAAgIgLgCQgLgDgEgCQgGgEAAgIQAAgHAEgFQAGgHAKABQALgBAHAGIAAAOIgFAAQgDgPgKAAQgLAAAAAKQAAAIAOACQATAEAAAOQAAAHgEAFQgHAIgLAAQgNAAgIgHg");
	this.shape_20.setTransform(92.4503,23.5249,1.186,1.1851);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABMA/QgIgFgFgIQgDgGgBgFIgBgVIgChYIAMABIAMgBIgCBSIABAVQABAGADAEQAEAFAJAEQAKAEALAAQAQAAAJgGQAFgDAEgEQADgFABgHIABgXIgBg+IgBgQIAKABIALgBIgBBPQAAAZgEALQgDAJgLAJQgPAJgZABQgbAAgNgKgAiWBIQgLgCgNgGQAEgLACgLQAIAIAHADQAKAFAMAAQAMAAAIgHQAIgGAAgLQAAgKgLgIIgTgKQgMgFgIgFQgOgJAAgTQAAgRALgLQAMgMAVABQAMAAAIACIAOAEIgEAIIgDALQgKgHgIgDIgOgCQgKAAgGAGQgGAFAAAJQAAAJAJAHQAGAFAVALQATAHAGAKQAFAIAAAKQAAAOgKAMQgNASgdAAgAg1BGIABgUIgBh4IA8ABIAQgBIgBAKIABAKIg1gCIAAAqIAZAAQAIAAAQgCIgBAKIAAAKQgNgCgNAAIgXAAIAAASQAAAdACARg");
	this.shape_21.setTransform(56.1877,28.384,1.186,1.1851);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A6192E").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_22.setTransform(40.0578,19.9992,1.186,1.1851);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.8,40);


// stage content:
(lib.banner_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {loop:28};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [386];
	// timeline functions:
	this.frame_386 = function() {
		var _this = this;
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('loop');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(386).call(this.frame_386).wait(14));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_92 = new cjs.Graphics().p("EAXVAu4MAAAhdvIAKAAMAAABdvg");
	var mask_graphics_93 = new cjs.Graphics().p("EgAHAu4MAAAhdvIAQAAMAAABdvg");
	var mask_graphics_94 = new cjs.Graphics().p("EgASAu4MAAAhdvIAlAAMAAABdvg");
	var mask_graphics_95 = new cjs.Graphics().p("EgAkAu4MAAAhdvIBJAAMAAABdvg");
	var mask_graphics_96 = new cjs.Graphics().p("EgA9Au4MAAAhdvIB7AAMAAABdvg");
	var mask_graphics_97 = new cjs.Graphics().p("EgBdAu4MAAAhdvIC7AAMAAABdvg");
	var mask_graphics_98 = new cjs.Graphics().p("EgCEAu4MAAAhdvIEJAAMAAABdvg");
	var mask_graphics_99 = new cjs.Graphics().p("EgCyAu4MAAAhdvIFlAAMAAABdvg");
	var mask_graphics_100 = new cjs.Graphics().p("EgDoAu4MAAAhdvIHRAAMAAABdvg");
	var mask_graphics_101 = new cjs.Graphics().p("EgEkAu4MAAAhdvIJJAAMAAABdvg");
	var mask_graphics_102 = new cjs.Graphics().p("EgFnAu4MAAAhdvILQAAMAAABdvg");
	var mask_graphics_103 = new cjs.Graphics().p("EgGyAu4MAAAhdvINlAAMAAABdvg");
	var mask_graphics_104 = new cjs.Graphics().p("EgIEAu4MAAAhdvIQJAAMAAABdvg");
	var mask_graphics_105 = new cjs.Graphics().p("EgJdAu4MAAAhdvIS7AAMAAABdvg");
	var mask_graphics_106 = new cjs.Graphics().p("EgK9Au4MAAAhdvIV7AAMAAABdvg");
	var mask_graphics_107 = new cjs.Graphics().p("EgMiAu4MAAAhdvIZFAAMAAABdvg");
	var mask_graphics_108 = new cjs.Graphics().p("EgOCAu4MAAAhdvIcFAAMAAABdvg");
	var mask_graphics_109 = new cjs.Graphics().p("EgPbAu4MAAAhdvIe3AAMAAABdvg");
	var mask_graphics_110 = new cjs.Graphics().p("EgQtAu4MAAAhdvMAhbAAAMAAABdvg");
	var mask_graphics_111 = new cjs.Graphics().p("EgR3Au4MAAAhdvMAjvAAAMAAABdvg");
	var mask_graphics_112 = new cjs.Graphics().p("EgS7Au4MAAAhdvMAl3AAAMAAABdvg");
	var mask_graphics_113 = new cjs.Graphics().p("EgT3Au4MAAAhdvMAnvAAAMAAABdvg");
	var mask_graphics_114 = new cjs.Graphics().p("EgUtAu4MAAAhdvMApbAAAMAAABdvg");
	var mask_graphics_115 = new cjs.Graphics().p("EgVbAu4MAAAhdvMAq3AAAMAAABdvg");
	var mask_graphics_116 = new cjs.Graphics().p("EgWCAu4MAAAhdvMAsFAAAMAAABdvg");
	var mask_graphics_117 = new cjs.Graphics().p("EgWiAu4MAAAhdvMAtFAAAMAAABdvg");
	var mask_graphics_118 = new cjs.Graphics().p("EgW7Au4MAAAhdvMAt3AAAMAAABdvg");
	var mask_graphics_119 = new cjs.Graphics().p("EgXNAu4MAAAhdvMAubAAAMAAABdvg");
	var mask_graphics_120 = new cjs.Graphics().p("EgXXAu4MAAAhdvMAuvAAAMAAABdvg");
	var mask_graphics_121 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(92).to({graphics:mask_graphics_92,x:150.25,y:299.9992}).wait(1).to({graphics:mask_graphics_93,x:299.65,y:300}).wait(1).to({graphics:mask_graphics_94,x:298.575,y:300}).wait(1).to({graphics:mask_graphics_95,x:296.8,y:300}).wait(1).to({graphics:mask_graphics_96,x:294.3,y:300}).wait(1).to({graphics:mask_graphics_97,x:291.075,y:300}).wait(1).to({graphics:mask_graphics_98,x:287.15,y:300}).wait(1).to({graphics:mask_graphics_99,x:282.525,y:300}).wait(1).to({graphics:mask_graphics_100,x:277.15,y:300}).wait(1).to({graphics:mask_graphics_101,x:271.1,y:300}).wait(1).to({graphics:mask_graphics_102,x:264.35,y:300}).wait(1).to({graphics:mask_graphics_103,x:256.825,y:300}).wait(1).to({graphics:mask_graphics_104,x:248.65,y:300}).wait(1).to({graphics:mask_graphics_105,x:239.725,y:300}).wait(1).to({graphics:mask_graphics_106,x:230.075,y:300}).wait(1).to({graphics:mask_graphics_107,x:219.925,y:300}).wait(1).to({graphics:mask_graphics_108,x:210.275,y:300}).wait(1).to({graphics:mask_graphics_109,x:201.35,y:300}).wait(1).to({graphics:mask_graphics_110,x:193.175,y:300}).wait(1).to({graphics:mask_graphics_111,x:185.675,y:300}).wait(1).to({graphics:mask_graphics_112,x:178.9,y:300}).wait(1).to({graphics:mask_graphics_113,x:172.85,y:300}).wait(1).to({graphics:mask_graphics_114,x:167.475,y:300}).wait(1).to({graphics:mask_graphics_115,x:162.85,y:300}).wait(1).to({graphics:mask_graphics_116,x:158.925,y:300}).wait(1).to({graphics:mask_graphics_117,x:155.7,y:300}).wait(1).to({graphics:mask_graphics_118,x:153.2,y:300}).wait(1).to({graphics:mask_graphics_119,x:151.425,y:300}).wait(1).to({graphics:mask_graphics_120,x:150.35,y:300}).wait(1).to({graphics:mask_graphics_121,x:150,y:300}).wait(219).to({graphics:null,x:0,y:0}).wait(60));

	// Connect_to_Excellence
	this.instance = new lib.g_txt_connect_to_excellence("synched",0);
	this.instance.setTransform(144.95,478,1,1,0,0,0,98.5,61.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(230).to({_off:false},0).to({x:134.95,alpha:1},30,cjs.Ease.quadInOut).wait(80).to({startPosition:0},0).to({x:124.95,alpha:0},31,cjs.Ease.quadInOut).to({_off:true},1).wait(28));

	// g_txt_02
	this.instance_1 = new lib.g_txt02("synched",0);
	this.instance_1.setTransform(33.55,430.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(92).to({_off:false},0).to({alpha:1},29,cjs.Ease.quadInOut).wait(101).to({startPosition:0},0).to({x:28.55,alpha:0},30,cjs.Ease.quadInOut).to({_off:true},1).wait(147));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EgXbAu4MAAAgu4MAu3AAAMAAAAu4g");
	mask_1.setTransform(149.9977,299.9996);

	// g_txt_01
	this.instance_2 = new lib.g_txt01("synched",0);
	this.instance_2.setTransform(-213.15,427.25);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:23.5},28,cjs.Ease.quadInOut).wait(64).to({startPosition:0},0).to({x:-213.15},29,cjs.Ease.quadInOut).to({_off:true},1).wait(235).to({_off:false},0).to({x:23.5},28,cjs.Ease.quadInOut).wait(15));

	// Photo
	this.instance_3 = new lib.Photo();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(400));

	// Logo
	this.instance_4 = new lib.g_SFULogo("synched",0);
	this.instance_4.setTransform(0.1,336.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(400));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(400));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,150,300);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Photo.jpg?1762206680696", id:"Photo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;