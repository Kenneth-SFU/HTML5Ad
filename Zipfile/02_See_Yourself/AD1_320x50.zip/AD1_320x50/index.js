(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,201,50]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Pic1 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD123 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AKOAZQAAgZAMgMQAIgJAQAAQAQAAAJAJQAJAKAAASIAAAHIg2AAIAAACQAAAfAYAAQANAAALgKIAFAFQgFAHgIAEQgKAEgJABQglAAAAgqgALEAPQAAgcgTAAQgSAAgBAcIAmAAIAAAAgAI+AYQAAgXALgLQAKgLASAAQAQAAAKAGIAAAVIgGAAQgHgUgPABQgVgBABAiQgBAVAGAJQAFAJAMAAQAIgBAGgFQAGgHABgKIAGAAIAAAUQgNALgPAAQgmAAAAgrgAGEAZQAAgZAMgMQAJgJAPAAQAQAAAKAJQAJAKAAASIAAAHIg2AAIAAACQgBAfAZAAQAMAAALgKIAGAFQgFAHgJAEQgJAEgKABQglAAAAgqgAG6APQAAgcgTAAQgRAAgBAcIAlAAIAAAAgADRAZQAAgZAMgMQAJgJAPAAQAQAAAKAJQAJAKgBASIAAAHIg1AAIAAACQgBAfAZAAQANAAAKgKIAGAFQgFAHgJAEQgJAEgKABQglAAAAgqgAEHAPQABgcgUAAQgRAAgBAcIAlAAIAAAAgACBAYQAAgXALgLQAKgLATAAQAQAAAKAGIAAAVIgGAAQgIgUgPABQgUgBAAAiQAAAVAGAJQAFAJAMAAQAHgBAGgFQAGgHACgKIAGAAIAAAUQgOALgPAAQgmAAAAgrgAglAZQAAgZALgMQAKgJAPAAQAPAAAJAJQAJAKAAASIAAAHIg1AAIAAACQAAAfAXAAQANAAALgKIAFAFQgEAHgJAEQgJAEgJABQglAAAAgqgAAQAPQAAgcgSAAQgSAAgBAcIAlAAIAAAAgAjlAZQAAgZAMgMQAJgJAPAAQARAAAIAJQAKAKgBASIAAAHIg2AAIAAACQABAfAYAAQAMAAAMgKIAEAFQgEAHgJAEQgJAEgKABQglAAAAgqgAivAPQABgcgUAAQgSAAgBAcIAmAAIAAAAgAmSAWQAAgTAIgLQALgNATAAQAkgBAAAsQAAAVgHALQgJANgWAAQgkgBAAgsgAl+gBQgDAHAAARQAAAjAUABQAOAAAEgOQADgHAAgTQAAghgVABQgMAAgFAMgAniAYQAAgXALgLQAKgLATAAQAQAAAKAGIAAAVIgGAAQgIgUgPABQgUgBAAAiQAAAVAGAJQAFAJAMAAQAHgBAGgFQAGgHACgKIAGAAIAAAUQgOALgPAAQgmAAAAgrgAowA4IAAgWIAGAAQABALAIAHQAGAHAKAAQAJAAAFgGQAEgEAAgGQAAgNgRgDQgSgDgHgFQgGgFAAgMQgBgIAHgGQAIgJAQAAQASgBAKAIIAAAUIgFAAQgEgIgHgHQgFgFgIAAQgGAAgFAFQgEAEAAAEQAAAHAFACQAEAEAMACQARADAGAHQAGAGAAALQAAAIgGAHQgJALgTAAQgSAAgNgLgAIMBBIAAgHIALAAIABgCIAAgtQAAgKgCgDQgEgIgKAAQgKAAgHAIQgGAHgBALIAAAoIACACIAJAAIAAAHIglAAIAAgHIAKAAIACgCIAAg7QAAgGgDAAIgJgBIAAgHIAYgEIACAAIAAAOIAAAAQAJgOATAAQAbAAAAAZIAAA0IABACIAKAAIAAAHgAFTBBIAAgHIAKAAIACgCIAAhoQgBgFgCgBIgJgBIAAgHIAYgDIACAAIAAB5IACACIAJAAIAAAHgAEjBBIAAgHIAKAAIACgCIAAhoQAAgFgDgBIgJgBIAAgHIAZgDIABAAIAAB5IACACIAJAAIAAAHgABaBBIAAgHIAJAAIABgCIgSgcIgUAcIABACIAJAAIAAAHIggAAIAAgHIAJgBIACgBIAYgiIgYghIgCgBIgHgBIAAgIIAkAAIAAAIIgIABIgCABIAQAXIARgXIgBgBIgJgBIAAgIIAhAAIAAAIIgJABIgDABIgVAdIAaAmIACABIAIABIAAAHgAiTBBIAAgHIALAAIACgCIAAg7QAAgGgDAAIgJgBIAAgHIAXgEIACAAIgBATIABAAQAJgUAUABIAJABIgEAOQgFgCgGAAQgKAAgGAIQgGAIAAAPIAAAhIACACIAJAAIAAAHgAkbBBIgchMIgBgBIgIgBIAAgIIAkAAIAAAIIgKABIgBABIAVA9IAAAAIAVg9IgBgBIgLgBIAAgIIAfAAIAAAIIgIABIAAABIgbBMgApjBBIAAgHIALAAIABgCIAAg7QAAgGgCAAIgJgCIAAgGIAYgFIACAAIAABOIABACIAKAAIAAAHgArTBBIAAgHIAMAAIABgCIAAhmIgBgCIgMAAIAAgIIAyAAQAcAAALASQAKAPAAAdQAAAdgKAOQgMAQgcAAgAq3A6IAUAAQAjgBAAgxIAAgHQAAgxgjABIgUAAgApWgoQgDgEAAgDQAAgFADgDQADgCAEAAQAEAAADACQADADAAAFQAAADgDAEQgDACgEAAQgEAAgDgCg");
	this.shape.setTransform(75.1,11.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.7,5.2,144.8,13.3);


(lib.g_txt02AD1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AVEBIIAAg5IgYg+IAAgYIAeAAIAJAyIACAAIAJgyIAeAAIAAAYIgYA+IAAA5gATxBIIAAhxIgXAAIAAgeIBOAAIAAAeIgXAAIAABxgASoBIIAAgeIAGAAIAAhTIgGAAIAAgeIAsAAIAAAeIgGAAIAABTIAGAAIAAAegARgBIQgPgFAAgTIAAgcIAgAAIAAAYIACACIAKAAIACgCIAAgWIgCgDIghgPQgGgCgDgFQgCgFAAgIIAAgfQAAgTAPgFIAwAAQAPAFAAATIAAAbIggAAIAAgXIgCgCIgKAAIgCACIAAAVIADADIAgANQAGADADAFQACAEAAAJIAAAhQAAATgPAFgAQwBIIgSg4IgDAAIAAA4IghAAIAAiPIA/AAQAQAFAAATIAAAfQAAAQgOAGIARAuIAAAUgAQbgJIALAAIACgCIAAggIgCgCIgLAAgAOuBIIAAiPIBCAAIAAAeIgjAAIAAAaIAhAAIAAAdIghAAIAAAcIAjAAIAAAegANoBIIgSh3IAAgYIAdAAIAJBmIACAAIAJhmIAfAAIAAAYIgSB3gAMiBIIAAgeIAGAAIAAhTIgGAAIAAgeIAsAAIAAAeIgHAAIAABTIAHAAIAAAegAL8BIIgUg/IgDAAIAAA/IgcAAIAAiPIAcAAIAVA/IACAAIAAg/IAcAAIAACPgAKDBIQgPgFAAgTIAAh3IAfAAIAABzIACACIAIAAIADgCIAAhzIAfAAIAAB3QAAATgPAFgAIJBIIAAiPIBBAAIAAAeIgiAAIAAAaIAhAAIAAAdIghAAIAAAcIAjAAIAAAegAHCBIIgSh3IAAgYIAeAAIAJBmIADAAIAJhmIAeAAIAAAYIgSB3gAF8BIIAAgeIAHAAIAAhTIgHAAIAAgeIAsAAIAAAeIgGAAIAABTIAGAAIAAAegAE1BIQgPgFAAgTIAAgcIAfAAIAAAYIACACIAKAAIADgCIAAgWIgDgDIgggPQgHgCgCgFQgCgFAAgIIAAgfQAAgTAPgFIAvAAQAPAFAAATIAAAbIgfAAIAAgXIgDgCIgKAAIgCACIAAAVIADADIAgANQAHADADAFQABAEAAAJIAAAhQAAATgPAFgAEABIIgUg/IgBAAIAAA/IgcAAIAAiPIAcAAIATA/IACAAIAAg/IAdAAIAACPgACBBIIAAiPIBDAAIAAAeIgiAAIAAAaIAfAAIAAAdIgfAAIAAAcIAjAAIAAAegABYBIIAAg4IgPAAIAAA4IgfAAIAAiPIAfAAIAAA6IAPAAIAAg6IAfAAIAACPgAgiBIIAAiPIBAAAIAAAeIggAAIAAAaIAeAAIAAAdIgeAAIAAAcIAhAAIAAAegAhEBIIgTg4IgDAAIAAA4IggAAIAAiPIA+AAQAQAFAAATIAAAfQAAAQgOAGIASAuIAAAUgAhagJIAMAAIACgCIAAggIgCgCIgMAAgAjQBIIAAiPIA/AAQAPAFAAATIAAAuQAAARgPAGIgfAAIAAAygAiwgDIAMAAIACgCIAAgmIgCgCIgMAAgAj4BIIAAhRIgBAAIgKAfIgYAAIgKgfIgBAAIAABRIgeAAIAAiPIAjAAIARAyIACAAIARgyIAjAAIAACPgAmMBIQgQgFAAgTIAAhfQAAgTAQgFIAuAAQAQAFAAATIAABfQAAATgQAFgAl8grIAABXIACACIAKAAIACgCIAAhXIgCgCIgKAAgAnlBIQgPgFAAgTIAAhfQAAgTAPgFIAvAAQAQAFAAATIAAAjIggAAIAAgfIgCgCIgKAAIgCACIAABXIACACIAKAAIACgCIAAgfIAgAAIAAAjQAAATgQAFgAo4BIIgUg/IgCAAIAAA/IgcAAIAAiPIAcAAIAUA/IACAAIAAg/IAcAAIAACPgAqQBIIgCgcIgPAAIgDAcIgeAAIAAgYIASh3IAsAAIASB3IAAAYgAqVAOIgEgsIgCAAIgEAsIAKAAgAr2BIIAAgeIAGAAIAAhTIgGAAIAAgeIAsAAIAAAeIgGAAIAABTIAGAAIAAAegAtOBIIAAiPIA/AAQAPAFAAATIAABfQAAATgPAFgAsuAuIAMAAIACgCIAAhXIgCgCIgMAAgAt0BIIgDgcIgOAAIgDAcIgeAAIAAgYIASh3IAsAAIASB3IAAAYgAt5AOIgEgsIgCAAIgEAsIAKAAgAvKBIIgUg/IgCAAIAAA/IgcAAIAAiPIAcAAIAUA/IACAAIAAg/IAcAAIAACPgAwiBIIgCgcIgQAAIgCAcIgeAAIAAgYIASh3IAsAAIASB3IAAAYgAwnAOIgEgsIgCAAIgEAsIAKAAgAyaBIQgQgFAAgTIAAhfQAAgTAQgFIAuAAQAQAFAAATIAAAjIggAAIAAgfIgCgCIgKAAIgCACIAABXIACACIAKAAIACgCIAAgfIAgAAIAAAjQAAATgQAFgA0ZBIIAAgeIASAAIAAhTIgQAAIAAgeIAwAAIAABxIAQAAIAAAegA1XBIIAHgoIgNAAIgGAoIgWAAIAHgoIgJAAIAAgYIAMAAIAEgRIgKAAIAAgYIANAAIAHgmIAWAAIgGAmIAMAAIAGgmIAWAAIgHAmIAJAAIAAAYIgMAAIgDARIAJAAIAAAYIgOAAIgGAogA1YAIIALAAIADgRIgMAAg");
	this.shape.setTransform(142.6,10.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AxIBoImGAAIAAjPIGGAAMAoXAAAIAADPg");
	this.shape_1.setTransform(137.65,10.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Small_Text
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA6AuIAAAAIgBgBIAAgJIABgBIABAAIAGgBIAEgCIACgFIAAgBIgQgxIAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIANAAIABABIAIAgIABAAIAIggIACgBIAMAAIABAAIAAABIgRAzQgDAIgDADQgCAEgFACQgFABgIAAgAG4AuIgBgBIABgLIABgBIAHABQAGAAADgDQAEgDAAgGIAAgBIgBAAQgEAFgHAAQgGAAgGgEQgFgCgDgIQgBgEAAgIQAAgHACgEQACgGAFgEQAFgDAGgBQAIABAEAEIABAAIAAgDIAAgBIABAAIAMAAIABAAIAAAuQAAANgIAFQgHAGgMAAgAG/gLQgCABgBADQgCAEAAADIABAJIAEAEQACACADAAQADAAACgCIADgEIABgJIAAgEIgBgDQgBgDgCgBQgCgCgDAAQgDAAgCACgAIXAkQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIADgXQAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBAAAAIALAAQAAAAAAABQAAAAAAAAQABAAAAAAQAAABAAAAIgHAYIgBAAgAL2AYQgGgFgCgGQgCgEAAgEQAAAAAAgBQAAAAABAAQAAAAAAAAQAAgBAAAAIAMAAQAAAAABABQAAAAAAAAQAAAAAAAAQAAABAAAAIABAFQABACACACIAFABQAGAAACgFQABgCAAgFQAAgDgBgEQgDgEgFAAIgCAAIgDACIgBAAIgBAAIgGgIIAAgCIAQgOIAAgBIgXAAIgBAAIgBgBIAAgKIABAAIABgBIApAAIABABIABAAIAAALIgBACIgNAMIAAAAIAAABQAJACADAIQACAFAAAEQAAAGgBAEQgDAHgFAEQgGADgIAAQgHAAgGgDgAKDAVQgHgFAAgMIAAgYQAAgLAHgGQAGgGALgBQALABAHAGQAGAGAAALIAAAYQAAAMgGAFQgHAHgLgBQgLABgGgHgAKNgcQgDADAAAEIAAAbQAAAEADACQADAEAEAAQAFAAACgEQADgCAAgEIAAgbQAAgEgDgDQgCgDgFAAQgEAAgDADgADAAYQgFgFAAgHQAAgHAFgFQAGgDAKAAIAKAAIAAgBIAAgCQAAgDgCgBQgCgCgEgBIgFACIgDADIgBAAIgMgBQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAgEADgDQADgEAFgCQAFgBAGgBQAGAAAGACQAFADADADQACAFAAAEIAAAiIgBABIgMAAIgBgBIAAgFIAAABQgFAFgJAAQgIAAgEgDgADLAGQgCACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABABQACABADAAQAEAAADgCQADgDAAgDIAAgEIAAgBIgHAAQgFAAgDACgAiJAYQgGgFgDgHQgCgFAAgHQAAgFACgEQACgIAGgDQAGgFAIAAQAKAAAGAGQAGAGABAJQABAEgBAEIgBABIgfAAIAAABIABAEQACAFAIABQAHgBAEgFIAAAAIABAAIAHAHIABABIgBABQgDAEgFACQgFACgGAAQgJAAgGgDgAiFgHIAAADIAAABIARAAQABAAAAgBIgBgDQgBgDgCgBQgCgCgDAAQgHABgCAFgAlIAZQgGgEgDgFQgEgFAAgIIAAgtIABAAIABgBIALAAIABABIAAAtQAAAGAEADQADADAFAAQAGAAADgDQADgDAAgGIAAgtIABgBIAMAAIABABIAAAAIAAAtQAAAIgDAFQgDAFgGAEQgGACgIAAQgHAAgGgCgAoYAYQgFgFAAgHQAAgHAGgFQAFgDAKAAIAKAAIABgBIAAgCQAAgDgCgBQgCgCgEgBIgFACIgDADIgBAAIgMgBQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQABgEADgDQADgEAFgCQAEgBAGgBQAHAAAFACQAFADADADQADAFAAAEIAAAiIgBABIgMAAIgBgBIAAgFIgBABQgEAFgJAAQgIAAgFgDgAoMAGQgDACAAADQAAABAAAAQAAABABAAQAAABAAAAQABABAAABQACABADAAQAFAAADgCQADgDAAgDIAAgEIgBgBIgHAAQgEAAgDACgApHAYQgGgFgDgHQgCgFAAgHQAAgFACgEQACgIAGgDQAGgFAIAAQAKAAAGAGQAGAGABAJQABAEgBAEIgBABIgfAAIAAABIABAEQACAFAIABQAHgBAEgFIAAAAIABAAIAHAHIABABIgBABQgDAEgFACQgFACgGAAQgJAAgGgDgApDgHIAAADIAAABIARAAQABAAAAgBIgBgDQgBgDgCgBQgCgCgDAAQgHABgCAFgAqVAYQgGgFgDgHQgBgEAAgIQAAgFABgFQADgHAGgEQAGgDAIgBQAIAAAGAFQAGADACAHIAAADIgBABIgLACIgBgBIgBgCQAAgCgDgCQgCgCgEAAQgDAAgCACQgCABgBADIgBAHIABAJQABADACABQACACADAAQAEAAACgCQACgBABgDIAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAABAAIALACIABABIAAADQgCAGgHAFQgGADgHAAQgIAAgGgDgArQAYQgFgFAAgHQAAgHAFgFQAGgDAKAAIAKAAIAAgBIAAgCQAAgDgCgBQgCgCgEgBIgFACIgDADIgBAAIgMgBQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAgEADgDQADgEAFgCQAFgBAGgBQAGAAAGACQAFADADADQACAFAAAEIAAAiIgBABIgMAAIgBgBIAAgFIAAABQgFAFgJAAQgIAAgEgDgArFAGQgCACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABABQACABADAAQAEAAADgCQADgDAAgDIAAgEIAAgBIgHAAQgFAAgDACgAHuAaQgFgCgDgEQgDgEAAgEIAAgBIABgBIAAAAIAMAAIAAAAIABABQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQADABADABIAGgBQAAgBABAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAAAgBAAIgGgCIgHgDQgHgCgDgDQgEgDAAgFQAAgIAGgEQAFgFAKAAQAGAAAFACQAFACADAEQACAEAAAFIAAAAIgBABIgLAAIgBgBIAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAQgCgCgEAAIgGABQAAABgBAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQABABAAAAIAHACIADAAIADACQAHABAEADQAEADAAAGQAAAIgGAEQgGAEgKAAQgGAAgFgBgAAdAYQgEgCAAgJIAAgZIAAgBIgGAAIgBAAIAAgLIABAAIAGAAIAAgBIAAgMIABAAIALAAIABAAIABABIAAALIAAABIAKAAIABAAIAAALIgBAAIgKAAIAAABIAAAUQAAAEABABQAAAAABABQAAAAABAAQAAAAABAAQABABAAAAIAEAAIABAAIAAALIgBABIgGAAQgJAAgEgDgAgtAaQgFgCgDgEQgDgEAAgEIAAgBIABgBIAAAAIAMAAIAAAAIABABQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQADABADABIAGgBQAAgBABAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAAAgBAAIgGgCIgHgDQgHgCgDgDQgEgDAAgFQAAgIAGgEQAFgFAKAAQAGAAAFACQAFACADAEQACAEAAAFIAAAAIgBABIgLAAIgBgBIAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAQgCgCgEAAIgGABQAAABgBAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQABABAAAAIAHACIADAAIADACQAHABAEADQAEADAAAGQAAAIgGAEQgGAEgKAAQgGAAgFgBgAmSAaQgFgCgDgEQgDgEAAgEIAAgBIABgBIAAAAIAMAAIAAAAIABABQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQADABADABIAGgBQAAgBABAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAAAgBAAIgGgCIgHgDQgHgCgDgDQgEgDAAgFQAAgIAGgEQAFgFAKAAQAGAAAFACQAFACADAEQACAEAAAFIAAAAIgBABIgLAAIgBgBIAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAAAQgCgCgEAAIgGABQAAABgBAAQAAABAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAHACIADAAIADACQAHABAEADQAEADAAAGQAAAIgGAEQgGAEgKAAQgGAAgFgBgAK2AbIgBgBIAAgKIABgBIAWgXQAJgKAAgFQAAgDgCgDQgDgCgEAAQgEAAgCACQgDADAAADIAAADIAAABIgOAAIAAgBIAAgFQAAgFADgFQADgEAGgCQAFgCAGgBQAHAAAFADQAGADADAEQACAFAAAFQAAAFgCAEQgCAFgEAEIgTAUIAAAAIAAABIAcAAIABABIAAAKIgBAAIgBABgAJFAbIgBgBIAAgKIABgBIAWgXQAJgKAAgFQAAgDgCgDQgDgCgEAAQgEAAgCACQgDADAAADIAAADIAAABIgOAAIAAgBIAAgFQAAgFADgFQADgEAGgCQAFgCAGgBQAHAAAFADQAGADADAEQACAFAAAFQAAAFgCAEQgCAFgEAEIgTAUIAAAAIAAABIAcAAIABABIAAAKIgBAAIgBABgAGXAbIgBgBIgBAAIAAgeQAAgEgCgCQgCgDgEAAQgDAAgDADQgCACAAAEIAAAeIAAAAIgBABIgMAAIgBgBIAAAAIAAgxIAAgBIABAAIAMAAIABAAIAAABIAAAEIABAAQAEgFAIgBQAIABAFAEQAFAFAAAIIAAAhIgBAAIgBABgAFfAbIgBgBIAAAAIAAgxIAAgBIABAAIAMAAIABAAIAAAyIgBABgAFJAbIgBgBIgKgYIgBAAIgGAIIAAAQIgBAAIgBABIgLAAIgBgBIgBAAIAAhEIABAAIABgBIALAAIABABIABAAIAAAiIAAAAIAOgPIABgBIAOAAIABABIgBAAIgMAQIgBABIAPAfIABABQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABgBAAgAESAbIgBgBIgBAAIAAgeQAAgEgCgCQgCgDgEAAQgDAAgDADQgCACAAAEIAAAeIAAAAIgBABIgMAAIgBgBIAAAAIAAgxIAAgBIABAAIAMAAIABAAIAAABIAAAEIABAAQAEgFAIgBQAIABAFAEQAFAFAAAIIAAAhIgBAAIgBABgACoAbIgCgBIgMgbIgBAAIgJAAIgBAAIAAAbIgBABIgLAAIgBgBIgBAAIAAhEIABAAIABgBIAcAAQAHABAEACQAFADADAEQADAGAAAFQAAAIgEAEQgDAFgGACIgBABIAOAbIAAABIgBABgACPgeIAAARIABAAIANAAQAEAAADgCQADgDAAgEQAAgEgDgCQgDgDgEAAIgNAAIgBABgAgCAbIgBgBIgBAAIAAgxIABgBIABAAIAKAAIABAAIAAAyIgBABgAhbAbIgBgBIAAAAIAAgxIAAgBIABAAIAMAAIABAAIAAABIAAAFIABAAQAEgHAHAAQADABACABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgCAMQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAgBAAIgDgBIgCAAQgEAAgCACQgDADAAAEIAAAbIAAAAIgBABgAi4AbIgCgBIgQgxIAAAAIABgBIANAAIACABIAIAeIABAAIAIgeIABgBIANAAIABAAIAAABIgQAxIgBABgAjeAbIgBgBIgBAAIAAgxIABgBIABAAIALAAIABAAIAAAyIgBABgAj3AbIgBgBIAAAAIAAgeQAAgEgCgCQgDgDgDAAQgEAAgCADQgCACAAAEIAAAeIgBAAIgBABIgLAAIgBgBIgBAAIAAgxIABgBIABAAIALAAIABAAIABABIAAAEIAAAAQAEgFAIgBQAIABAFAEQAFAFAAAIIAAAhIAAAAIgBABgAnGAbIgBgBIAAAAIAAgeQAAgEgCgCQgDgDgDAAQgEAAgCADQgCACAAAEIAAAeIgBAAIgBABIgLAAIgBgBIgBAAIAAgxIABgBIABAAIALAAIABAAIABABIAAAEIAAAAQAEgFAIgBQAIABAFAEQAFAFAAAIIAAAhIAAAAIgBABgApnAbIgBgBIgBAAIAAhEIABAAIABgBIALAAIABABIABAAIAABEIgBAAIgBABgArrAbIgBgBIAAgsIgBAAIgKARIgCABIgFAAIgCgBIgKgRIgBAAIAAABIAAArIgBABIgMAAIgBgBIAAAAIAAhEIAAAAIABgBIAMAAIABABIAPAYIABAAIAPgYIABgBIAMAAIABABIAAAAIAABEIAAAAIgBABgAmzgUQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAIAGgVIABgBIAMAAIABABIAAABIgJAUQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAgAFfggQgCgCAAgDQAAgEACgDQADgBADAAQAEAAACABQACADAAAEQAAADgCACQgDADgDAAQgDAAgDgDgAgCggQgCgCAAgDQAAgEACgDQACgBADAAQADAAACABQACADAAAEQAAADgCACQgCADgDAAQgDAAgCgDgAjeggQgCgCAAgDQAAgEACgDQACgBAEAAQADAAACABQACADAAAEQAAADgCACQgCADgDAAQgEAAgCgDg");
	this.shape_2.setTransform(207.575,29.65);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.1,0.5,298.1,33.8);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(51.8777,26.2994,1.0947,1.0963);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(37.0174,18.5429,1.0947,1.0963);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,74,37.1);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("AAlBuIAAiSIiSAAIAAhJIDbAAIAADbg");
	this.shape.setTransform(11,11);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22,22);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgQAoQgHgEgEgHQgDgGAAgJIAAg3IAAgBIABAAIAOAAIABAAIABABIAAA3QAAAHADADQAEAEAGAAQAGAAAEgEQAFgDAAgHIAAg3IAAgBIABAAIAOAAIABAAIABABIAAA3QAAAJgFAGQgDAHgHAEQgIADgJAAQgIAAgIgDg");
	this.shape.setTransform(115.35,12.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgbArIgBgBIAAgBIAAhRIAAgBIABgBIA3AAIABABIAAABIAAAMIAAABIgBAAIgmAAIgBABIAAATIABAAIAZAAIABABIAAABIAAALIAAABIgBAAIgZAAIgBABIAAAhIgBABIgBABg");
	this.shape_1.setTransform(108.4,12.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgQApQgHgDgEgGQgEgGAAgIIAAgCIABgBIABgBIAOAAIABABIAAABIAAABQAAAFAEAEQAFADAHAAQAGAAADgDQAEgDAAgEQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgDgEgBIgJgEIgOgGQgGgCgEgFQgEgFAAgHQAAgIAEgFQAEgGAHgDQAGgDAJAAQAIAAAIAEQAHADAEAGQAEAGAAAIIAAABIAAABIgBABIgOAAIgBgBIgBgBIAAgBQAAgFgEgDQgEgEgHAAQgFAAgEADQgDACAAAEQAAADACACIAGAEIAKAFIAOAFQAFACAEAEQAEAFAAAIQAAALgJAHQgIAHgPAAQgIAAgIgDg");
	this.shape_2.setTransform(101.075,12.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgQAoQgHgEgEgHQgEgHAAgJIAAgaQAAgIAEgHQAEgHAHgEQAIgEAIAAQAKAAAHAEQAHAEAEAHQAEAHAAAIIAAAaQAAAJgEAHQgEAHgHAEQgHAEgKAAQgIAAgIgEgAgKgYQgEAFAAAGIAAAaQAAAIAEAEQAEAEAGAAQAHAAAEgEQAEgEAAgIIAAgaQAAgGgEgFQgEgEgHAAQgGAAgEAEg");
	this.shape_3.setTransform(91.275,12.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgHArIgBgBIAAgBIAAhDIgBgBIgVAAIgBAAIAAgBIAAgMIAAgBIABgBIA9AAIABABIAAABIAAAMIAAABIgBAAIgWAAIgBABIAABDIAAABIgBABg");
	this.shape_4.setTransform(83.975,12.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgHArIgBgBIAAgBIAAhDIgBgBIgVAAIgBAAIAAgBIAAgMIAAgBIABgBIA9AAIABABIAAABIAAAMIAAABIgBAAIgWAAIgBABIAABDIAAABIgBABg");
	this.shape_5.setTransform(74.475,12.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgQAoQgHgEgEgGQgEgHAAgJIAAgbQAAgJAEgHQAEgGAHgEQAIgEAIAAQAKAAAHAEQAHADAEAHQAEAGAAAJQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgOABIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAgGgEgEQgEgEgHAAQgFAAgEAEQgEAEAAAGIAAAdQAAAGAEAEQAEAEAFAAQAHAAAEgEQAEgEAAgGQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAIAOABIABAAIABABQAAAJgEAGQgEAHgHADQgHAEgKAAQgIAAgIgEg");
	this.shape_6.setTransform(67.225,12.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgbArIgBgBIgBgBIAAhRIABgBIABgBIA3AAIACABIAAABIAAAMIAAABIgCAAIgmAAIgBABIAAATIABAAIAZAAIAAABIABABIAAALIgBABIAAAAIgZAAIgBABIAAATIABABIAmAAIACAAIAAABIAAAMIAAABIgCABg");
	this.shape_7.setTransform(60.1,12.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AASArIgCgBIgfgzIAAgBIAAABIAAAyIgBABIgBABIgNAAIgBgBIgBgBIAAhRIABgBIABgBIANAAIACABIAfAzIAAABIAAgBIAAgyIABgBIAAgBIAPAAIABABIAAABIAABRIAAABIgBABg");
	this.shape_8.setTransform(52.35,12.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AASArIgCgBIgfgzIAAgBIAAABIAAAyIgBABIgBABIgNAAIgBgBIgBgBIAAhRIABgBIABgBIANAAIACABIAfAzIAAABIAAgBIAAgyIAAgBIABgBIAPAAIABABIAAABIAABRIAAABIgBABg");
	this.shape_9.setTransform(44.25,12.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgQAoQgHgEgEgHQgEgHAAgJIAAgaQAAgIAEgHQAEgHAHgEQAIgEAIAAQAKAAAHAEQAHAEAEAHQAEAHAAAIIAAAaQAAAJgEAHQgEAHgHAEQgHAEgKAAQgIAAgIgEgAgKgYQgEAFAAAGIAAAaQAAAIAEAEQAEAEAGAAQAHAAAEgEQAEgEAAgIIAAgaQAAgGgEgFQgEgEgHAAQgGAAgEAEg");
	this.shape_10.setTransform(36.425,12.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgQAoQgHgEgEgGQgEgHAAgJIAAgbQAAgJAEgHQAEgGAHgEQAIgEAIAAQAKAAAHAEQAHADAEAHQAEAGAAAJQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgOABIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAgGgEgEQgEgEgHAAQgFAAgEAEQgEAEAAAGIAAAdQAAAGAEAEQAEAEAFAAQAHAAAEgEQAEgEAAgGQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAIAOABIABAAIABABQAAAJgEAGQgEAHgHADQgHAEgKAAQgIAAgIgEg");
	this.shape_11.setTransform(28.975,12.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgvBDIBChDIhChCIAOgPIBRBRIhRBRg");
	this.shape_12.setTransform(14,12.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgvBDIBChDIhChCIAOgPIBRBRIhRBRg");
	this.shape_13.setTransform(14,12.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ACvAoQgHgEgFgHQgEgHAAgJIAAgaQAAgIAEgHQAFgHAHgEQAHgEAJAAQAKAAAHAEQAHAEAFAHQADAHAAAIIAAAaQAAAJgDAHQgFAHgHAEQgHAEgKAAQgJAAgHgEgAC0gYQgDAFAAAGIAAAaQAAAIADAEQAFAEAGAAQAHAAAEgEQAEgEAAgIIAAgaQAAgGgEgFQgEgEgHAAQgGAAgFAEgAl1AoQgHgEgEgHQgEgHAAgJIAAgaQAAgIAEgHQAEgHAHgEQAIgEAJAAQAKAAAGAEQAIAEAEAHQAEAHAAAIIAAAaQAAAJgEAHQgEAHgIAEQgGAEgKAAQgJAAgIgEgAlvgYQgEAFAAAGIAAAaQAAAIAEAEQAEAEAHAAQAGAAAFgEQAEgEAAgIIAAgaQAAgGgEgFQgFgEgGAAQgHAAgEAEgAGfAoQgHgEgEgHQgDgGAAgJIAAg3IAAAAIABgBIAOAAIABABIABAAIAAA3QAAAHADADQAEAFAHAAQAGAAAEgFQAFgDAAgHIAAg3IAAAAIABgBIAOAAIABABIABAAIAAA3QAAAJgFAGQgDAHgIAEQgHAEgJAAQgJAAgIgEgAEQAoQgGgCgFgHQgDgFAAgIIAAgDIAAgBIABAAIAOAAIABAAIAAADQAAAFAEAEQAFADAIAAQAGgBAEgCQADgDAAgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAgBQgCgCgEgBIgKgFIgOgFQgGgCgEgFQgDgGAAgGQAAgIADgGQAEgFAHgDQAHgDAIAAQAKAAAHADQAHADAEAGQAFAHAAAIIAAABIgBABIgBAAIgOAAIgBAAIAAgBIAAgBQgBgFgEgDQgEgEgIAAQgFAAgEADQgCACAAAEQAAADACACIAFAEIAMAEIANAGQAFACAEAEQAEAFAAAIQAAALgIAHQgJAHgPAAQgJgBgIgDgAhBAoQgHgEgEgHQgEgHAAgIIAAgcQAAgIAEgHQAEgHAHgDQAIgEAJAAQAJAAAIADQAGAEAFAGQADAHAAAIQAAABAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgPABQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQAAgGgDgEQgEgEgHAAQgGAAgEAEQgFAEAAAGIAAAcQAAAHAFAEQAEADAGABQAHgBAEgDQADgEAAgHQAAAAABAAQAAAAAAgBQAAAAAAAAQABAAAAAAIAPABIAAABQAAAJgDAGQgFAGgGAEQgIAEgJAAQgJAAgIgEgAnAAoQgHgEgEgHQgDgHAAgIIAAgcQAAgIADgHQAEgHAHgDQAIgEAJAAQAKAAAHADQAHAEAEAGQAEAHAAAIQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgPABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAgGgEgEQgEgEgHAAQgGAAgEAEQgEAEAAAGIAAAcQAAAHAEAEQAEADAGABQAHgBAEgDQAEgEAAgHQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAABAAIAPABIAAABQAAAJgEAGQgEAGgHAEQgHAEgKAAQgJAAgIgEgAFOAqIgBAAIAAgBIAAhSIAAAAIABgBIA5AAIABABIAAAAIAAAMIAAACIgBAAIgoAAIgBABIAAATIABAAIAaAAIABABIAAAAIAAALIAAABIgBABIgaAAIgBABIAAAhIgBABIAAAAgABuAqIgBAAIAAgBIAAhDIgBgBIgUAAIgBAAIgBgCIAAgMIABAAIABgBIA9AAIABABIABAAIAAAMIgBACIgBAAIgWAAIgBABIAABDIAAABIgBAAgAAQAqIgBAAIgBgBIAAhDIAAgBIgVAAIgBAAIAAgCIAAgMIAAAAIABgBIA9AAIABABIAAAAIAAAMIAAACIgBAAIgWAAIAAABIAABDIgBABIgBAAgAiTAqIgBAAIgBgBIAAhSIABAAIABgBIA4AAIABABIAAAOIgBAAIgoAAIgBABIAAATIABAAIAaAAIABABIABAAIAAALIgBABIgBABIgaAAIgBABIAAATIABABIAoAAIABAAIAAAOIgBAAgAizAqIgCgBIgggyIAAgBIAAAzIgBABIgBAAIgNAAIgBAAIgBgBIAAhSIABAAIABgBIANAAIACABIAgAzIAAABIAAg0IAAAAIABgBIAPAAIABABIAABTIgBAAgAkEAqIgCgBIgggyIAAgBIAAAzIgBABIgBAAIgNAAIgBAAIgBgBIAAhSIABAAIABgBIANAAIACABIAgAzIAAABIAAg0IAAAAIABgBIAPAAIABABIAABTIgBAAg");
	this.shape_14.setTransform(72.15,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ap6B4IAAjvIT1AAIAADvg");
	this.shape_15.setTransform(63.475,12);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJ7B4Iz1AAIAAjvIT1AAg");
	this.shape_16.setTransform(63.475,12);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ap6CMIAAkXIT1AAIAAEXg");
	this.shape_17.setTransform(63.475,11.9905,1,0.8556);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,129,26);


(lib.gpic1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(295.05,0,1,1,180,0,0,22,22);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(124,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D00025").s().p("ApSD6IAAnzISlAAIAAHzg");
	this.shape.setTransform(59.5,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Photo
	this.instance_2 = new lib.Pic1();
	this.instance_2.setTransform(119,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,50);


// stage content:
(lib.banner_320x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_58 = new cjs.Graphics().p("AgxD6IAAnzIBjAAIAAHzg");
	var mask_graphics_59 = new cjs.Graphics().p("Ai1D6IAAnzIFrAAIAAHzg");
	var mask_graphics_60 = new cjs.Graphics().p("AkzD6IAAnzIJnAAIAAHzg");
	var mask_graphics_61 = new cjs.Graphics().p("AmrD6IAAnzINXAAIAAHzg");
	var mask_graphics_62 = new cjs.Graphics().p("AodD6IAAnzIQ7AAIAAHzg");
	var mask_graphics_63 = new cjs.Graphics().p("AqJD6IAAnzIUTAAIAAHzg");
	var mask_graphics_64 = new cjs.Graphics().p("ArwD6IAAnzIXhAAIAAHzg");
	var mask_graphics_65 = new cjs.Graphics().p("AtRD6IAAnzIajAAIAAHzg");
	var mask_graphics_66 = new cjs.Graphics().p("AusD6IAAnzIdZAAIAAHzg");
	var mask_graphics_67 = new cjs.Graphics().p("AwBD6IAAnzMAgDAAAIAAHzg");
	var mask_graphics_68 = new cjs.Graphics().p("AxQD6IAAnzMAihAAAIAAHzg");
	var mask_graphics_69 = new cjs.Graphics().p("AyZD6IAAnzMAkzAAAIAAHzg");
	var mask_graphics_70 = new cjs.Graphics().p("AzdD6IAAnzMAm6AAAIAAHzg");
	var mask_graphics_71 = new cjs.Graphics().p("A0aD6IAAnzMAo1AAAIAAHzg");
	var mask_graphics_72 = new cjs.Graphics().p("A1SD6IAAnzMAqlAAAIAAHzg");
	var mask_graphics_73 = new cjs.Graphics().p("A2DD6IAAnzMAsIAAAIAAHzg");
	var mask_graphics_74 = new cjs.Graphics().p("A2wD6IAAnzMAtgAAAIAAHzg");
	var mask_graphics_75 = new cjs.Graphics().p("A3WD6IAAnzMAusAAAIAAHzg");
	var mask_graphics_76 = new cjs.Graphics().p("A32D6IAAnzMAvtAAAIAAHzg");
	var mask_graphics_77 = new cjs.Graphics().p("A4QD6IAAnzMAwhAAAIAAHzg");
	var mask_graphics_78 = new cjs.Graphics().p("A4kD6IAAnzMAxJAAAIAAHzg");
	var mask_graphics_79 = new cjs.Graphics().p("A4zD6IAAnzMAxoAAAIAAHzg");
	var mask_graphics_80 = new cjs.Graphics().p("A48D6IAAnzMAx5AAAIAAHzg");
	var mask_graphics_81 = new cjs.Graphics().p("A4/D6IAAnzMAx/AAAIAAHzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_graphics_58,x:325,y:25}).wait(1).to({graphics:mask_graphics_59,x:310.975,y:25}).wait(1).to({graphics:mask_graphics_60,x:297.55,y:25}).wait(1).to({graphics:mask_graphics_61,x:284.75,y:25}).wait(1).to({graphics:mask_graphics_62,x:272.575,y:25}).wait(1).to({graphics:mask_graphics_63,x:261.05,y:25}).wait(1).to({graphics:mask_graphics_64,x:250.125,y:25}).wait(1).to({graphics:mask_graphics_65,x:239.85,y:25}).wait(1).to({graphics:mask_graphics_66,x:230.175,y:25}).wait(1).to({graphics:mask_graphics_67,x:221.125,y:25}).wait(1).to({graphics:mask_graphics_68,x:212.725,y:25}).wait(1).to({graphics:mask_graphics_69,x:204.9,y:25}).wait(1).to({graphics:mask_graphics_70,x:197.75,y:25}).wait(1).to({graphics:mask_graphics_71,x:191.2,y:25}).wait(1).to({graphics:mask_graphics_72,x:185.275,y:25}).wait(1).to({graphics:mask_graphics_73,x:179.95,y:25}).wait(1).to({graphics:mask_graphics_74,x:175.3,y:25}).wait(1).to({graphics:mask_graphics_75,x:171.25,y:25}).wait(1).to({graphics:mask_graphics_76,x:167.775,y:25}).wait(1).to({graphics:mask_graphics_77,x:165,y:25}).wait(1).to({graphics:mask_graphics_78,x:162.8,y:25}).wait(1).to({graphics:mask_graphics_79,x:161.25,y:25}).wait(1).to({graphics:mask_graphics_80,x:160.3,y:25}).wait(1).to({graphics:mask_graphics_81,x:160,y:25}).wait(270));

	// Btn
	this.instance = new lib.btn_CTA();
	this.instance.setTransform(224.05,38.5,1,1,0,0,0,83,25.5);
	this.instance.alpha = 0;
	this.instance._off = true;
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(255).to({_off:false},0).to({x:234.05,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD123
	this.instance_1 = new lib.g_txt03AD123("synched",0);
	this.instance_1.setTransform(131.25,12.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(185).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(25).to({startPosition:0},0).to({alpha:0},25,cjs.Ease.get(1)).to({_off:true},2).wait(86));

	// text_02__Ad01
	this.instance_2 = new lib.g_txt02AD1("synched",0);
	this.instance_2.setTransform(-286.4,9.55);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(58).to({_off:false},0).to({x:11.1,y:9.5},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-286.4,y:9.55},21,cjs.Ease.get(1)).to({_off:true},1).wait(167));

	// Logo
	this.instance_3 = new lib.g_SFULogo("synched",0);
	this.instance_3.setTransform(18.85,0.1,1,1,0,0,0,0.1,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(162).to({_off:false},0).to({alpha:1},21).wait(168));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AgxD6IAAnzIBjAAIAAHzg");
	this.shape.setTransform(325,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("Ai1D6IAAnzIFrAAIAAHzg");
	this.shape_1.setTransform(310.975,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AkzD6IAAnzIJnAAIAAHzg");
	this.shape_2.setTransform(297.55,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("AmrD6IAAnzINXAAIAAHzg");
	this.shape_3.setTransform(284.75,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("AodD6IAAnzIQ7AAIAAHzg");
	this.shape_4.setTransform(272.575,25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("AqJD6IAAnzIUTAAIAAHzg");
	this.shape_5.setTransform(261.05,25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("ArwD6IAAnzIXhAAIAAHzg");
	this.shape_6.setTransform(250.125,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("AtRD6IAAnzIajAAIAAHzg");
	this.shape_7.setTransform(239.85,25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("AusD6IAAnzIdZAAIAAHzg");
	this.shape_8.setTransform(230.175,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("AwBD6IAAnzMAgDAAAIAAHzg");
	this.shape_9.setTransform(221.125,25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("AxQD6IAAnzMAihAAAIAAHzg");
	this.shape_10.setTransform(212.725,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("AyZD6IAAnzMAkzAAAIAAHzg");
	this.shape_11.setTransform(204.9,25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("AzdD6IAAnzMAm6AAAIAAHzg");
	this.shape_12.setTransform(197.75,25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("A0aD6IAAnzMAo1AAAIAAHzg");
	this.shape_13.setTransform(191.2,25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("A1SD6IAAnzMAqlAAAIAAHzg");
	this.shape_14.setTransform(185.275,25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("A2DD6IAAnzMAsIAAAIAAHzg");
	this.shape_15.setTransform(179.95,25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("A2wD6IAAnzMAtgAAAIAAHzg");
	this.shape_16.setTransform(175.3,25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("A3WD6IAAnzMAusAAAIAAHzg");
	this.shape_17.setTransform(171.25,25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("A32D6IAAnzMAvtAAAIAAHzg");
	this.shape_18.setTransform(167.775,25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("A4QD6IAAnzMAwhAAAIAAHzg");
	this.shape_19.setTransform(165,25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("A4kD6IAAnzMAxJAAAIAAHzg");
	this.shape_20.setTransform(162.8,25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("A4zD6IAAnzMAxoAAAIAAHzg");
	this.shape_21.setTransform(161.25,25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("A48D6IAAnzMAx5AAAIAAHzg");
	this.shape_22.setTransform(160.3,25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_23.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},58).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(270));

	// Logo
	this.instance_4 = new lib.g_SFULogo("synched",0);
	this.instance_4.setTransform(18.85,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},162).wait(189));

	// Red
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D00025").s().p("ApSD6IAAnzISlAAIAAHzg");
	this.shape_24.setTransform(59.5,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_24).to({_off:true},83).wait(268));

	// Photo_AD1
	this.instance_5 = new lib.gpic1("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,324,54);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},22,cjs.Ease.get(1)).to({_off:true},61).wait(268));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 22,cjs.Ease.get(1)).wait(268));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:22, x:-2, y:-2, w:324, h:54});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:324, h:54});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(160,25,170,25);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 320,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;