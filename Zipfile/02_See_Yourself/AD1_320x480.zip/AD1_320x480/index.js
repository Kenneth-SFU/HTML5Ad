(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,320,480]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Pic1 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD123 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhXAAIAAADQAAAzAnAAQAVAAASgQIAIAHQgHAMgQAIQgOAGgQABQg7AAAAhFgAAggMQAAguggAAQgcAAgBAuIA9AAIAAAAg");
	this.shape.setTransform(233,21.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1ACQAAgjARgUQARgSAdAAQAZAAAQALIAAAiIgJAAQgMghgZAAQgfAAAAA5QAAAgAJAPQAJAOARAAQANAAAJgKQAKgKADgRIAKAAIAAAiQgWAQgaAAQg7AAAAhGg");
	this.shape_1.setTransform(219.8,21.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBHIAAgMIARAAIACgDIAAhHQAAgSgEgGQgFgNgTAAQgPAAgKANQgKAMAAASIAABBIACADIAPAAIAAAMIg8AAIAAgMIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAngIIADAAIgCAZIABAAQAPgYAeAAQAsAAAAArIAABTIACADIAPAAIAAAMg");
	this.shape_2.setTransform(204.975,21.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAPAQQAOAQAAAeIAAALIhWAAIAAADQAAAzAnAAQAUAAASgQIAIAHQgIAMgOAIQgPAGgRABQg6AAAAhFgAAfgMQAAgugfAAQgcAAgBAuIA8AAIAAAAg");
	this.shape_3.setTransform(189.85,21.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBrIAAgNIARAAIACgDIAAipQAAgIgFgBIgOgCIAAgKIAmgHIAEAAIAADFIACADIAPAAIAAANg");
	this.shape_4.setTransform(179.125,17.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBrIAAgNIARAAIACgDIAAipQAAgIgFgBIgOgCIAAgKIAmgHIAEAAIAADFIACADIAPAAIAAANg");
	this.shape_5.setTransform(171.375,17.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhXAAIAAADQABAzAnAAQAUAAASgQIAIAHQgHAMgQAIQgOAGgQABQg7AAAAhFgAAggMQAAgugfAAQgdAAgBAuIA9AAIAAAAg");
	this.shape_6.setTransform(160.65,21.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag1ACQAAgjARgUQAQgSAeAAQAZAAARALIAAAiIgKAAQgMghgZAAQgfAAAAA5QAAAgAJAPQAJAOARAAQANAAAJgKQAKgKADgRIAKAAIAAAiQgWAQgZAAQg8AAAAhGg");
	this.shape_7.setTransform(147.45,21.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAKBHIAAgNIAPgBIACgCIgdgsIggAsIACACIAPABIAAANIg0AAIAAgNIAOgBIADgCIAog3Igog2IgCgCIgNgBIAAgNIA6AAIAAANIgNAAIgCADIAZAnIAcgnIgCgDIgOAAIAAgNIA0AAIAAANIgPABIgDACIgkAxIArA8IADACIANABIAAANg");
	this.shape_8.setTransform(134.5,21.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhXAAIAAADQAAAzAoAAQAUAAASgQIAIAHQgHAMgQAIQgOAGgRABQg6AAAAhFgAAfgMQAAgugeAAQgdAAgBAuIA8AAIAAAAg");
	this.shape_9.setTransform(120.35,21.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgzBHIAAgMIARAAIAEgDIAAhhQAAgIgFgBIgPgDIAAgKIAngIIADAAIgCAgIABAAQAOgfAfAAQAIAAAIACIgGAXQgIgDgKAAQgQAAgKAOQgIAOAAAWIAAA2IABADIAPAAIAAAMg");
	this.shape_10.setTransform(101.975,21.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAPAQQAOAQAAAeIAAALIhWAAIAAADQAAAzAmAAQAVAAASgQIAIAHQgIAMgOAIQgPAGgRABQg6AAAAhFgAAggMQgBgugfAAQgcAAgBAuIA9AAIAAAAg");
	this.shape_11.setTransform(89.15,21.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgJBHIgth9IgCgCIgNgBIAAgNIA7AAIAAANIgQAAIgCADIAgBjIACAAIAghjIgCgDIgQAAIAAgNIAyAAIAAANIgNABIgCACIgsB9g");
	this.shape_12.setTransform(75.65,21.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag8AAQABgdAOgUQAQgWAfAAQA7AAgBBHQAAAigMARQgPAVghAAQg7AAgBhIgAgbgnQgFAOgBAaQAAA6AiAAQAVABAHgWQAFgNgBgdQABg2giAAQgTAAgIATg");
	this.shape_13.setTransform(61.4,21.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag1ACQAAgjARgUQARgSAcAAQAaAAARALIAAAiIgKAAQgMghgYAAQghAAAAA5QAAAgAKAPQAIAOASAAQANAAAKgKQAJgKADgRIAKAAIAAAiQgWAQgZAAQg8AAAAhGg");
	this.shape_14.setTransform(47.85,21.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag0A4IAAglIAKAAQACASAMAMQAMAKAOAAQAPAAAIgIQAHgHgBgLQAAgUgbgFQgdgFgKgGQgMgJAAgTQAAgPALgLQAOgOAZAAQAcAAAQALIAAAjIgJAAQgFgQgLgJQgKgJgKAAQgMAAgGAHQgHAGAAAJQAAALAHAFQAIAFARADQAcAEALAMQAJAJgBARQAAAPgJALQgPARgeAAQgcAAgWgQg");
	this.shape_15.setTransform(34.9,21.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdBlIAAgNIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAmgIIAEAAIAAB/IACADIAPAAIAAANgAgJhIQgFgFAAgHQAAgGAFgFQAEgFAGAAQAHAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgHAAQgGAAgEgFg");
	this.shape_16.setTransform(24.475,18.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhPBjIAAgMIASgBIACgDIAAilIgCgDIgSgBIAAgMIBPAAQAtAAAUAcQAPAYAAAwQAAAvgQAXQgUAbgtAAgAgiBWIAgAAQA3AAAAhQIAAgLQAAhQg3AAIggAAg");
	this.shape_17.setTransform(11.175,18.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,7.3,235.5,21.599999999999998);


(lib.g_txt02AD1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AF+IXIAAh6Ig0iIIAAg0IBBAAIATBqIAFAAIAThqIBAAAIAAA0IgzCIIAAB6gADLIXIAAj1IgxAAIAAhBICoAAIAABBIgxAAIAAD1gAAvIXIAAhBIANAAIAAi0IgNAAIAAhBIBeAAIAABBIgMAAIAAC0IAMAAIAABBgAhpIXQgigMAAgoIAAg9IBFAAIAAA0IAEAFIAWAAIAEgFIAAgvIgEgGIhGggQgQgGgFgMQgEgJAAgUIAAhBQAAgoAigMIBlAAQAgAMAAAoIAAA5IhEAAIAAgxIgEgEIgWAAIgEAEIAAAtIAFAHIBFAcQAPAGAEANQAFAJAAAUIAABGQAAAoggAMgAjRIXIgnh5IgIAAIAAB5IhFAAIAAk2ICGAAQAiAMAAAoIAABCQAAAlgdAMIAlBjIAAAsgAkAFmIAaAAIAEgEIAAhFIgEgEIgaAAgAnqIXIAAk2ICOAAIAABBIhKAAIAAA4IBFAAIAABAIhFAAIAAA8IBMAAIAABBgAqAIXIgnkCIAAg0IBAAAIAUDeIAEAAIAUjeIBAAAIAAA0IgnECgAsXIXIAAhBIANAAIAAi0IgNAAIAAhBIBfAAIAABBIgNAAIAAC0IANAAIAABBgAtpIXIgqiHIgFAAIAACHIg8AAIAAk2IA8AAIAsCHIADAAIAAiHIA9AAIAAE2gAxqIXQgjgMABgoIAAkCIBFAAIAAD5IAEAFIARAAIAEgFIAAj5IBFAAIAAECQAAAogiAMgAQECbIAAk1ICOAAIAABBIhJAAIAAA4IBFAAIAAA/IhFAAIAAA8IBLAAIAABBgANuCbIgmkBIAAg0IBAAAIATDdIAEAAIAUjdIBBAAIAAA0IgoEBgALXCbIAAhBIAOAAIAAizIgOAAIAAhBIBgAAIAABBIgOAAIAACzIAOAAIAABBgAI+CbQghgMAAgoIAAg9IBFAAIAAA0IAEAFIAWAAIAEgFIAAgvIgEgGIhHggQgPgGgFgLQgEgJAAgUIAAhBQAAgoAhgMIBlAAQAiAMAAAoIAAA5IhFAAIAAgxIgEgEIgWAAIgEAEIAAAtIAGAHIBEAcQAQAGAFAMQAEAJAAAUIAABGQAAAogiAMgAHOCbIgriHIgFAAIAACHIg8AAIAAk1IA8AAIArCHIAFAAIAAiHIA8AAIAAE1gAC8CbIAAk1ICOAAIAABBIhJAAIAAA4IBGAAIAAA/IhGAAIAAA8IBLAAIAABBgABiCbIAAh5IgeAAIAAB5IhEAAIAAk1IBEAAIAAB9IAeAAIAAh9IBFAAIAAE1gAilCbIAAk1ICOAAIAABBIhJAAIAAA4IBFAAIAAA/IhFAAIAAA8IBLAAIAABBgAjtCbIgnh5IgIAAIAAB5IhFAAIAAk1ICHAAQAhAMAAAoIAABCQAAAkgdAMIAlBjIAAAsgAkcgVIAaAAIAEgEIAAhFIgEgEIgaAAgAoZCbIAAk1ICGAAQAhAMAAAoIAABjQAAAmghAMIhCAAIAABsgAnVgIIAaAAIAFgEIAAhSIgFgEIgaAAgApvCbIAAiwIgCAAIgWBEIgzAAIgWhEIgCAAIAACwIhAAAIAAk1IBLAAIAkBsIAFAAIAlhsIBKAAIAAE1gAutCbQgjgMABgoIAAjNQgBgoAjgMIBkAAQAiAMAAAoIAADNQAAAogiAMgAuKheIAAC8IAEAFIAVAAIAFgFIAAi8IgFgEIgVAAgAxqCbQgjgMABgoIAAjNQgBgoAjgMIBkAAQAiAMAAAoIAABLIhFAAIAAhDIgFgEIgVAAIgEAEIAAC8IAEAFIAVAAIAFgFIAAhBIBFAAIAABKQAAAogiAMgAJtjgIgriHIgEAAIAACHIg9AAIAAk2IA9AAIArCHIAEAAIAAiHIA8AAIAAE2gAGwjgIgEg9IgiAAIgEA9IhBAAIAAg0IAnkCIBeAAIAnECIAAA0gAGmldIgJhiIgEAAIgJBiIAWAAgADVjgIAAhBIANAAIAAi0IgNAAIAAhBIBfAAIAABBIgNAAIAAC0IANAAIAABBgAAYjgIAAk2ICGAAQAiAMAAAoIAADOQAAAogiAMgABdkYIAaAAIAEgFIAAi9IgEgEIgaAAgAg4jgIgFg9IghAAIgFA9IhBAAIAAg0IAnkCIBfAAIAlECIAAA0gAhCldIgJhiIgFAAIgJBiIAXAAgAjxjgIgriHIgEAAIAACHIg8AAIAAk2IA8AAIArCHIAEAAIAAiHIA8AAIAAE2gAmtjgIgGg9IghAAIgEA9IhBAAIAAg0IAnkCIBeAAIAnECIAAA0gAm4ldIgJhiIgEAAIgJBiIAWAAgAqwjgQgigMAAgoIAAjOQAAgoAigMIBkAAQAiAMAAAoIAABLIhFAAIAAhDIgEgEIgWAAIgEAEIAAC9IAEAFIAWAAIAEgFIAAhBIBFAAIAABKQAAAogiAMgAvAjgIAAhBIAnAAIAAi0IgjAAIAAhBIBoAAIAAD1IAiAAIAABBgAxFjgIAOhWIgaAAIgOBWIgvAAIAOhWIgTAAIAAg0IAbAAIAHgnIgVAAIAAgzIAeAAIANhSIAwAAIgPBSIAaAAIAPhSIAvAAIgOBSIASAAIAAAzIgbAAIgGAnIAUAAIAAA0IgdAAIgOBWgAxJlqIAaAAIAHgnIgaAAg");
	this.shape.setTransform(119.6,84.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A0+JeIABs6IgBAAIAAmBMAiZAAAIAAGAIHkAAIAAHCIqAAAIAAF5g");
	this.shape_1.setTransform(110.325,83.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Small_Text
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABKA7IAAAAIAAgNIAAgBIABgBIAJgBQACAAACgCIADgHIAAgBIgVg+IAAgBQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAIAQAAIACABIALApIABAAIAAAAIALgpIABgBIAQAAIABABIAAABIgWBBIgGAOQgEAFgGACQgGACgLAAgAIyA6QAAAAgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgOQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAABAAIAIABQAIAAAFgEQAEgDAAgIIAAgBIAAABQgGAFgJAAQgIAAgHgEQgHgEgDgJQgCgGAAgJQAAgJACgHQADgHAGgFQAHgFAIAAQAKAAAGAGIAAAAIAAgDIABgBIABgBIAPAAIABABIAAABIAAA5QAAARgJAHQgKAHgPAAgAI6gOQgCACgCADQgBAEgBAGQABAHABADQABADADACQADACADAAQAFAAACgCQADgCABgDIABgLIAAgFIgBgEQgBgDgDgCQgDgCgEAAQgDAAgDACgAKqAuQAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIAFgeQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIANAAQABAAAAAAQAAAAAAAAQABAAAAABQAAAAgBAAIgIAeQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAgAM0AbQgIgIAAgNIAAghQAAgNAIgIQAIgIAOAAQAOAAAIAIQAIAIAAANIAAAhQAAANgIAIQgIAIgOAAQgOAAgIgIgANBglQgDAEAAAGIAAAiQAAAGADADQAEAEAFAAQAGAAADgEQADgDAAgGIAAgiQAAgGgDgEQgDgDgGAAQgFAAgEADgAPGAeQgHgFgDgIIgDgLQAAAAABAAQAAgBAAAAQAAAAAAAAQABAAAAAAIAPAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIABAGQABAEADACQADABADAAQAIAAACgGQACgEAAgFQAAgFgCgEQgDgGgHAAIgDABIgDADIgBAAIgCgBIgHgKIAAgBIAAgCIAUgRIAAgBIAAAAIgeAAIgBgBIAAgBIAAgMIAAgBIABgBIA1AAIACABIAAAPIgBACIgRAPIAAABIABAAQAKACAGALQACAGAAAHQAAAHgCAFQgEAJgGAEQgIAFgJAAQgKAAgIgFgAJ2AgQgHgCgDgFQgDgEAAgFIAAgCIAAgBIABAAIAOAAIABAAIABABIAAABQgBACAEACQADACAFAAQAEAAADgBQACgCAAgDQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAgBAAIgHgDIgKgDQgIgCgFgEQgFgDAAgIQAAgKAIgFQAHgGAMAAQAIAAAHADQAGADADAEQADAFAAAGIAAABIgQAAIgBgBQAAgDgCgCQgDgCgFAAQgEAAgDACQgDABABADQAAABAAAAQAAABAAAAQAAABABAAQAAAAABABIAJADIADAAIAEACQAJACAFADQAFAFAAAIQAAAJgHAFQgIAGgMAAQgJAAgGgDgAD1AeQgGgFAAgJQgBgKAIgGQAGgEANAAIANAAIABgBIAAgCQAAgFgDgCQgCgCgGAAQgEAAgCABQgBAAAAABQgBAAAAABQgBAAAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgQgCIgBgBQAAgFAFgFQADgEAHgCQAFgDAIAAQAIAAAHADQAHADADAFQAEAFAAAGIAAAqIgBABIgBABIgOAAIgCgBIAAgBIAAgEIgBAAIAAAAQgGAHgLAAQgKAAgGgFgAEEAIQgDACAAAEQAAADACACQADACAEAAQAFAAAEgDQAEgCAAgFIAAgFIgBAAIgJAAQgGAAgDACgAg5AgQgHgCgDgFQgEgEAAgFIAAgCIAAgBIACAAIANAAIABAAIABABIAAABQAAACAEACQADACAEAAQAEAAADgBQADgCAAgDQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAgBAAIgHgDIgKgDQgIgCgFgEQgEgDgBgIQAAgKAIgFQAIgGALAAQAIAAAHADQAGADADAEQADAFAAAGIAAABIgPAAIgBgBQAAgDgDgCQgDgCgFAAQgDAAgDACQgDABAAADQAAABAAAAQAAABABAAQAAABAAAAQABAAABABIAJADIADAAIADACQAKACAEADQAGAFAAAIQAAAJgHAFQgIAGgNAAQgJAAgFgDgAiuAeQgJgFgCgJQgEgGAAgKQAAgHADgFQADgJAHgGQAHgFALAAQAMAAAIAHQAHAIACAMQABAFAAAFQgBABAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIgoAAIAAAAIACAFQADAHAKAAQAIAAAFgGIABgBIABABIAKAKIAAABQgFAFgGADQgHADgIAAQgLAAgHgFgAipgJIgBAEIAAABIAXAAQAAAAAAgBIAAgDQgBgEgEgCQgDgCgDAAQgJAAgCAHgAmiAfQgIgEgEgHQgEgHgBgJIAAg5IABgBIABgBIAPAAIABABIAAABIAAA5QABAHAEAEQAEAEAHAAQAHAAAEgEQADgEAAgHIAAg5IABgBIABgBIAPAAIABABIAAABIAAA5QAAAJgDAHQgEAHgIAEQgIAEgJAAQgKAAgHgEgAoBAgQgHgCgDgFQgEgEABgFIAAgCIAAgBIABAAIAOAAIABAAIABABIAAABQgBACAEACQADACAFAAQAEAAADgBQACgCAAgDQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAgBAAIgHgDIgKgDQgIgCgFgEQgFgDAAgIQAAgKAIgFQAHgGAMAAQAIAAAGADQAHADADAEQADAFAAAGIAAABIgQAAIgBgBQAAgDgCgCQgEgCgEAAQgEAAgDACQgDABABADQAAABAAAAQAAABAAAAQAAABABAAQAAAAABABIAJADIADAAIAEACQAJACAFADQAFAFABAIQgBAJgHAFQgIAGgMAAQgJAAgGgDgAqsAeQgHgFABgJQAAgKAGgGQAIgEAMAAIANAAIABgBIAAgCQAAgFgCgCQgDgCgFAAQgEAAgDABQgBAAAAABQgBAAAAABQgBAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgPgCIgCgBQAAgFAEgFQAFgEAFgCQAHgDAHAAQAJAAAGADQAGADAEAFQAEAFAAAGIAAAqIgBABIAAABIgQAAIgBgBIAAgBIAAgEIAAAAIgBAAQgGAHgLAAQgKAAgGgFgAqdAIQgDACAAAEQAAADACACQADACAEAAQAFAAAEgDQAEgCAAgFIAAgFIgBAAIgJAAQgFAAgEACgAroAeQgIgFgDgJQgDgGAAgKQAAgHACgFQADgJAHgGQAIgFAKAAQAMAAAJAHQAHAIACAMQAAAFAAAFQAAABAAAAQAAAAAAAAQgBABAAAAQAAAAAAAAIgoAAIgBAAIACAFQADAHALAAQAHAAAFgGIABgBIABABIALAKIgBABQgFAFgGADQgHADgHAAQgLAAgIgFgArjgJIgBAEIABABIAWAAQABAAAAgBIgBgDQgBgEgDgCQgDgCgEAAQgIAAgDAHgAtMAeQgIgFgDgJQgCgHAAgIQAAgIACgGQADgJAHgFQAIgFAKAAQALAAAHAFQAIAFADAIIABAFIAAAAIgBABIgPADIgCgCIAAgCQgCgDgDgCQgCgCgFAAQgDAAgDACQgEACgBADQgBAEAAAGQAAAGABAEQABAEAEACQADACADAAQAFAAACgCQADgCACgEIAAgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAABAAIAOACIACACIgBAEQgDAIgIAFQgIAFgKAAQgKAAgHgFgAuYAeQgGgFAAgJQAAgKAHgGQAHgEAMAAIAOAAIABgBIAAgCQgBgFgCgCQgDgCgFAAQgEAAgDABQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgPgCIgBgBQAAgFAEgFQAEgEAGgCQAGgDAIAAQAIAAAGADQAHADADAFQAFAFAAAGIAAAqIgBABIgBABIgPAAIgBgBIAAgBIAAgEIgBAAIAAAAQgGAHgLAAQgKAAgHgFgAuIAIQgDACgBAEQABADACACQACACAEAAQAFAAAEgDQAFgCAAgFIAAgFIgBAAIgJAAQgGAAgDACgAAmAfQgFgEgBgKIAAghIAAAAIgIAAIgBgBIAAgBIAAgLIAAgBIABgBIAIAAIAAAAIAAgQIABgBIABAAIAPAAIABAAIAAABIAAAQIABAAIALAAIACABIABABIAAALIgBABIgCABIgLAAIgBAAIAAAaQAAAFABACQACACAEAAIAFAAIABABIAAAMQAAABAAAAQAAAAAAAAQgBABAAAAQAAAAgBAAIgIAAQgKAAgFgDgAN2AiIgBgBIgBgBIAAgMIABgBIAcgeQAMgNAAgGQAAgEgDgDQgDgDgFAAQgGAAgDADQgDADAAAEIAAAEIAAABIgCAAIgOAAIgCAAIAAgBIAAgGQAAgHAEgGQAEgFAGgDQAHgDAJAAQAJAAAGAEQAHADAEAGQADAGAAAHQAAAFgCAGIgJAMIgYAZIAAAAIAjAAIABABIAAABIAAAMIAAABIgBABgALnAiIgCgBIAAgBIAAgMIABgBIAcgeQAMgNgBgGQABgEgEgDQgDgDgFAAQgGAAgDADQgCADAAAEIAAAEIgBABIgBAAIgPAAIgBAAIgBgBIAAgGQABgHADgGQAEgFAHgDQAGgDAJAAQAJAAAHAEQAGADAEAGQAEAGgBAHQABAFgDAGIgIAMIgZAZIAAAAIAjAAIABABIABABIAAAMIgBABIgBABgAIHAiIgBgBIAAgBIAAglQAAgFgDgDQgDgDgFAAQgEAAgDADQgDADAAAFIAAAlIgBABIgBABIgPAAIgBgBIAAgBIAAg9IAAgBIABgBIAPAAIABABIABABIAAAEIAAABIABAAQAEgIALAAQAKAAAGAGQAHAHAAAKIAAApIgBABIgBABgAHAAiIgBgBIgBgBIAAg9IABgBIABgBIAPAAIABABIABABIAAA9IgBABIgBABgAGkAiIgBgBIgNgeIgBgBIAAABIgIAKIgBABIAAASIAAABIgBABIgPAAIgBgBIgBgBIAAhVIABgBIABgBIAPAAIABABIAAABIAAArIABAAIABAAIAQgUIADgBIARAAQAAAAAAAAQAAAAABAAQAAABAAAAQAAAAAAAAIAAABIgQAVIgBABIATAnIAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAgAFdAiIgBgBIAAgBIAAglQAAgFgDgDQgDgDgEAAQgFAAgDADQgDADAAAFIAAAlIAAABIgBABIgPAAIgBgBIgBgBIAAg9IABgBIABgBIAPAAIABABIAAABIAAAEIABABIAAAAQAFgIALAAQAJAAAHAGQAGAHAAAKIAAApIgBABIAAABgADWAiIgCgBIgQgjIgBAAIgLAAIAAAAIAAAiIgBABIgBABIgPAAIgBgBIAAhXIABgBIAkAAQAJAAAGAEQAGADADAGQADAGAAAIQAAAJgEAGQgEAGgIADIgBABIASAjIAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAgAC4gmIAAAVIAAABIARAAQAFAAAEgDQACgDAAgFQAAgGgCgDQgEgDgFAAIgRAAIAAABgAgDAiIgBgBIAAgBIAAg9IAAgBIABgBIAOAAIABABIABABIAAA9IgBABIgBABgAh0AiIgBgBIgBgBIAAg9IABgBIABgBIAPAAIABABIAAABIAAAFIABAAIAAAAQAGgIAJAAQAEAAADACIABACIgEAPQAAAAAAAAQAAABAAAAQAAAAAAAAQgBgBAAAAIgEAAIgEAAQgEAAgDADQgDADgBAFIAAAiIAAABIgBABgAjrAiIgCgBIgTg+IgBgBQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAABAAIAQAAIACABIAKAmIAAAAIABAAIAKgmIADgBIAPAAIACABIAAABIgVA+QAAAAAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAgAkbAiIgBgBIgBgBIAAg9IABgBIABgBIAOAAIACABIAAABIAAA9IAAABIgCABgAk7AiIgBgBIAAgBIAAglQAAgFgDgDQgDgDgFAAQgEAAgDADQgDADAAAFIAAAlIAAABIgBABIgPAAIgBgBIgBgBIAAg9IABgBIABgBIAPAAIABABIAAABIAAAEIABABIAAAAQAFgIALAAQAJAAAHAGQAGAHAAAKIAAApIgBABIgBABgApDAiIgBgBIgBgBIAAglQAAgFgDgDQgCgDgFAAQgFAAgDADQgDADAAAFIAAAlIgBABIgBABIgOAAIgCgBIAAgBIAAg9IAAgBIACgBIAOAAIABABIABABIAAAEIAAABIABAAQAFgIAKAAQAKAAAHAGQAGAHAAAKIAAApIAAABIgBABgAsSAiIgBgBIAAgBIAAhVIAAgBIABgBIAPAAIABABIABABIAABVIgBABIgBABgAu5AiIgBgBIgBgBIAAg3IAAgBIgBABIgNAVIgCABIgHAAIgCgBIgNgVIgBAAIAAA3IAAABIgCABIgPAAIgBgBIAAhXIABgBIAPAAQAAAAABAAQAAAAAAABQAAAAABAAQAAAAAAABIATAdIABAAIATgdIACgCIAPAAIABABIAAABIAABVIAAABIgBABgAorgaQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIAHgaIACgCIAPAAIABABIAAABIgKAaIgCABgAHAgpQgCgDAAgEQAAgFACgDQADgCAFAAQAEAAADACQADADAAAFQAAAEgDADQgDADgEAAQgFAAgDgDgAgDgpQgCgDAAgEQAAgFACgDQADgCAEAAQAFAAACACQADADAAAFQAAAEgDADQgDADgEAAQgEAAgDgDgAkbgpQgDgDAAgEQAAgFADgDQADgCAFAAQAEAAACACQAEADAAAFQAAAEgEADQgDADgDAAQgFAAgDgDg");
	this.shape_2.setTransform(106.1,178.875);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24,23.3,268.7,161.5);


(lib.g_txt01AD1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ASIDVIAAmpIDDAAIAABZIhkAAIAABSIBeAAIAABYIheAAIAACmgAO0DVIAAmpIBfAAIAAFQIBhAAIAABZgALRDVIAAmpIDDAAIAABZIhkAAIAABNIBeAAIAABYIheAAIAABSIBnAAIAABZgAH/DVQgugRAAg2IAAhUIBfAAIAABIIAFAGIAeAAIAGgGIAAhBIgFgJIhigrQgUgJgHgPQgGgNAAgbIAAhaQAAg1AugSICKAAQAuASAAA1IAABPIheAAIAAhCIgGgHIgeAAIgFAHIAAA9IAHAKIBfAmQAUAJAHAPQAGANAAAbIAABhQAAA2guARgAFxDVIg2imIgLAAIAACmIheAAIAAmpIC4AAQAuASAAA1IAABbQAAAygnARIAyCIIAAA8gAEwgcIAkAAIAGgHIAAhdIgGgHIgkAAgAADDVQgugRAAg2IAAliIBeAAIAAFWIAGAGIAXAAIAGgGIAAlWIBfAAIAAFiQAAA2guARgAkADVQgugRAAg2IAAkbQAAg1AugSICKAAQAuASAAA1IAAEbQAAA2guARgAjQiAIAAECIAGAGIAeAAIAGgGIAAkCIgGgHIgeAAgAnrDVIAAioIhGi5IAAhIIBYAAIAbCTIAGAAIAaiTIBZAAIAABIIhHC5IAACogAtnDVIAAmpIDDAAIAABZIhlAAIAABNIBfAAIAABYIhfAAIAABSIBoAAIAABZgAxKDVIAAmpIDDAAIAABZIhlAAIAABNIBfAAIAABYIhfAAIAABSIBoAAIAABZgA0cDVQgugRAAg2IAAhUIBeAAIAABIIAGAGIAdAAIAGgGIAAhBIgFgJIhhgrQgVgJgHgPQgFgNAAgbIAAhaQAAg1AugSICKAAQAuASAAA1IAABPIhfAAIAAhCIgGgHIgdAAIgGAHIAAA9IAIAKIBfAmQAUAJAHAPQAGANAAAbIAABhQAAA2guARg");
	this.shape.setTransform(138.725,27.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,6.7,271.1,42.5);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(56.0499,28.3575,1.1828,1.1827);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(39.9927,19.9899,1.1828,1.1827);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,40);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("ABYEEIAAlbIlbAAIAAisIIHAAIAAIHg");
	this.shape.setTransform(26,26);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,52,52);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgXA6QgKgGgHgKQgFgJAAgNIAAhQIABgBIABgBIAVAAIABABIABABIAABRQAAAJAGAFQAGAHAIgBQAKABAFgHQAGgFAAgJIAAhRIAAgBIACgBIAVAAIACABIAAABIAABQQAAANgGAJQgFALgLAFQgKAFgOAAQgNAAgKgFg");
	this.shape.setTransform(168.5,21.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIACAAIAAACIAAARIAAACIgCAAIg5AAIgBABIAAAcIABABIAlAAIABAAIACACIAAAQIgCABIgBABIglAAIgBABIAAAxIAAACIgCAAg");
	this.shape_1.setTransform(158.35,21.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgXA7QgLgEgGgJQgFgIAAgMIAAgDIAAgCIACgBIAUAAIACABIAAACIAAACQAAAHAHAFQAGAFALAAQAJAAAFgEQAEgEAAgGQAAgEgDgDQgCgDgFgCIgPgGQgMgEgIgFQgIgDgGgHQgGgIAAgKQAAgLAGgIQAFgIAKgFQAKgEANAAQAMAAALAFQALAFAGAIQAFAJAAALIAAADIAAACIgCAAIgUAAIgCAAIAAgCIAAgBQAAgIgGgFQgHgFgJAAQgJAAgEADQgFAEAAAGQAAAFADADQACADAGACIAQAHIAUAIQAHACAGAHQAFAHAAAMQAAAQgMAKQgMAKgVAAQgNAAgLgFg");
	this.shape_2.setTransform(147.675,21.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_3.setTransform(133.325,21.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIAAACIgCAAg");
	this.shape_4.setTransform(122.6,21.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIgBACIgBAAg");
	this.shape_5.setTransform(108.65,21.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgXA6QgLgFgGgKQgFgKAAgNIAAgoQAAgNAFgJQAGgKALgFQALgGAMAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgFAKQgHAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_6.setTransform(98.1,21.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIABAAIABACIAAARIgBACIgBAAIg5AAIgBABIAAAcIABABIAlAAIABAAIABACIAAAQIgBABIgBABIglAAIgBABIAAAdIABABIA5AAIABAAIABACIAAARIgBACIgBAAg");
	this.shape_7.setTransform(87.725,21.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_8.setTransform(76.425,21.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAgBAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_9.setTransform(64.625,21.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_10.setTransform(53.175,21.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgXA6QgLgFgFgKQgGgKAAgNIAAgoQAAgNAGgJQAFgKALgFQALgGAMAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgGAKQgGAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_11.setTransform(42.3,21.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_12.setTransform(20.475,20.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_13.setTransform(20.475,20.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AD/A6QgLgGgGgJQgFgLgBgOIAAgkQABgNAFgLQAGgKALgGQALgFANAAQAOAAALAFQALAGAFAKQAGALAAANIAAAkQAAAOgGALQgFAJgLAGQgLAGgOAAQgNAAgLgGgAEIgjQgHAGAAALIAAAlQAAALAHAGQAFAHAKAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgKABgFAGgAoiA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFAOAAQAOAAAKAFQALAGAGAKQAFALABANIAAAkQgBAOgFALQgGAJgLAGQgKAGgOAAQgOAAgLgGgAoZgjQgGAGAAALIAAAlQAAALAGAGQAGAHAKAAQAJAAAGgHQAHgGgBgLIAAglQABgLgHgGQgGgGgJgBQgKABgGAGgAJfA6QgKgGgHgJQgFgJAAgOIAAhQIABgBIABAAIAVAAIABAAIABABIAABRQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJIAAhRIAAgBIACAAIAVAAIACAAIAAABIAABQQAAAOgGAJQgFAKgLAFQgKAFgOAAQgOAAgKgFgAGPA7QgLgFgGgIQgGgJAAgLIAAgEIABgBIACgBIAUAAIABABIABABIAAADQAAAHAHAFQAGAFAMAAQAJAAAEgEQAFgEAAgGQAAgEgDgDQgDgDgEgCIgQgHQgMgDgIgFQgJgDgFgHQgGgIAAgKQAAgMAFgHQAGgJAKgEQAKgEAMAAQAOAAAKAFQAMAFAFAIQAGAJAAALIAAADIAAACIgCAAIgVAAIgBAAIAAgCIAAgCQAAgHgHgFQgGgGgLAAQgIABgEADQgFADAAAHQAAAFADADQACACAGADIAQAHIAVAIQAHACAFAHQAGAHAAALQAAARgMAKQgNAKgUgBQgOAAgLgEgAhgA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgFAKQgHAJgKAFQgKAGgOgBQgNAAgLgFgAqOA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgGAKQgGAJgKAFQgKAGgOgBQgNAAgLgFgAHpA+IgCAAIAAgCIAAh4IAAgBIACAAIBRAAIACAAIAAABIAAASIAAABIgCABIg5AAIgCABIAAAcIACABIAmAAIABAAIABACIAAAQIgBABIgBABIgmAAIgCAAIAAAyIAAACIgCAAgAChA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBaAAIACAAIAAABIAAASIAAABIgCABIggAAIgBABIAABjIgBACIgBAAgAAVA+IgBAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBZAAIACAAIAAABIAAASIAAABIgCABIgfAAIgBABIAABjIgBACIgCAAgAjZA+IgCAAIAAgCIAAh4IAAgBIACAAIBTAAIABAAIABABIAAASIgBABIgBABIg7AAIgBABIAAAcIABABIAmAAIABAAIACACIAAAQIgCABIgBABIgmAAIgBAAIAAAdIABABIA7AAIABABIABACIAAARIgBACIgBAAgAkHA+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBAAIgthMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIAAAAIAAhLIABgBIABAAIAWAAIABAAIABABIAAB4IgBACIgBAAgAl9A+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAAAIguhMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIABAAIAAhLIAAgBIABAAIAVAAIACAAIABABIAAB4IgBACIgCAAg");
	this.shape_14.setTransform(105.4,21.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AueDNIAAmZIc9AAIAAGZg");
	this.shape_15.setTransform(92.725,20.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AOfDNI89AAIAAmZIc9AAg");
	this.shape_16.setTransform(92.725,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,187.5,43);


(lib.gpic1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(295,82.45,1,1,180,0,0,26,26);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(43,290.05,1,1,0,0,0,26,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Photo
	this.instance_2 = new lib.Pic1();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,321,480);


// stage content:
(lib.banner_320x480 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("EgAxAlgMAAAhK/IBjAAMAAABK/g");
	var mask_graphics_80 = new cjs.Graphics().p("EgC1AlgMAAAhK/IFrAAMAAABK/g");
	var mask_graphics_81 = new cjs.Graphics().p("EgEzAlgMAAAhK/IJnAAMAAABK/g");
	var mask_graphics_82 = new cjs.Graphics().p("EgGrAlgMAAAhK/INXAAMAAABK/g");
	var mask_graphics_83 = new cjs.Graphics().p("EgIdAlgMAAAhK/IQ7AAMAAABK/g");
	var mask_graphics_84 = new cjs.Graphics().p("EgKJAlgMAAAhK/IUTAAMAAABK/g");
	var mask_graphics_85 = new cjs.Graphics().p("EgLwAlgMAAAhK/IXhAAMAAABK/g");
	var mask_graphics_86 = new cjs.Graphics().p("EgNRAlgMAAAhK/IajAAMAAABK/g");
	var mask_graphics_87 = new cjs.Graphics().p("EgOsAlgMAAAhK/IdZAAMAAABK/g");
	var mask_graphics_88 = new cjs.Graphics().p("EgQBAlgMAAAhK/MAgDAAAMAAABK/g");
	var mask_graphics_89 = new cjs.Graphics().p("EgRQAlgMAAAhK/MAihAAAMAAABK/g");
	var mask_graphics_90 = new cjs.Graphics().p("EgSZAlgMAAAhK/MAkzAAAMAAABK/g");
	var mask_graphics_91 = new cjs.Graphics().p("EgTdAlgMAAAhK/MAm6AAAMAAABK/g");
	var mask_graphics_92 = new cjs.Graphics().p("EgUaAlgMAAAhK/MAo1AAAMAAABK/g");
	var mask_graphics_93 = new cjs.Graphics().p("EgVSAlgMAAAhK/MAqlAAAMAAABK/g");
	var mask_graphics_94 = new cjs.Graphics().p("EgWDAlgMAAAhK/MAsIAAAMAAABK/g");
	var mask_graphics_95 = new cjs.Graphics().p("EgWwAlgMAAAhK/MAtgAAAMAAABK/g");
	var mask_graphics_96 = new cjs.Graphics().p("EgXWAlgMAAAhK/MAusAAAMAAABK/g");
	var mask_graphics_97 = new cjs.Graphics().p("EgX2AlgMAAAhK/MAvtAAAMAAABK/g");
	var mask_graphics_98 = new cjs.Graphics().p("EgYQAlgMAAAhK/MAwhAAAMAAABK/g");
	var mask_graphics_99 = new cjs.Graphics().p("EgYkAlgMAAAhK/MAxJAAAMAAABK/g");
	var mask_graphics_100 = new cjs.Graphics().p("EgYzAlgMAAAhK/MAxoAAAMAAABK/g");
	var mask_graphics_101 = new cjs.Graphics().p("EgY8AlgMAAAhK/MAx5AAAMAAABK/g");
	var mask_graphics_102 = new cjs.Graphics().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:325,y:240}).wait(1).to({graphics:mask_graphics_80,x:310.975,y:240}).wait(1).to({graphics:mask_graphics_81,x:297.55,y:240}).wait(1).to({graphics:mask_graphics_82,x:284.75,y:240}).wait(1).to({graphics:mask_graphics_83,x:272.575,y:240}).wait(1).to({graphics:mask_graphics_84,x:261.05,y:240}).wait(1).to({graphics:mask_graphics_85,x:250.125,y:240}).wait(1).to({graphics:mask_graphics_86,x:239.85,y:240}).wait(1).to({graphics:mask_graphics_87,x:230.175,y:240}).wait(1).to({graphics:mask_graphics_88,x:221.125,y:240}).wait(1).to({graphics:mask_graphics_89,x:212.725,y:240}).wait(1).to({graphics:mask_graphics_90,x:204.9,y:240}).wait(1).to({graphics:mask_graphics_91,x:197.75,y:240}).wait(1).to({graphics:mask_graphics_92,x:191.2,y:240}).wait(1).to({graphics:mask_graphics_93,x:185.275,y:240}).wait(1).to({graphics:mask_graphics_94,x:179.95,y:240}).wait(1).to({graphics:mask_graphics_95,x:175.3,y:240}).wait(1).to({graphics:mask_graphics_96,x:171.25,y:240}).wait(1).to({graphics:mask_graphics_97,x:167.775,y:240}).wait(1).to({graphics:mask_graphics_98,x:165,y:240}).wait(1).to({graphics:mask_graphics_99,x:162.8,y:240}).wait(1).to({graphics:mask_graphics_100,x:161.25,y:240}).wait(1).to({graphics:mask_graphics_101,x:160.3,y:240}).wait(1).to({graphics:mask_graphics_102,x:160,y:240}).wait(252));

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(0.1,108.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(275));

	// Btn
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(97.5,281.3,1,1,0,0,0,83,25.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:118.5,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD123
	this.instance_2 = new lib.g_txt03AD123("synched",0);
	this.instance_2.setTransform(32.05,200.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(116));

	// text_02__Ad01
	this.instance_3 = new lib.g_txt02AD1("synched",0);
	this.instance_3.setTransform(-313.45,198.5,1,1,0,0,0,-66.5,28);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({x:-42.5},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-313.45},21,cjs.Ease.get(1)).to({_off:true},3).wait(147));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("EgAxAlgMAAAhK/IBjAAMAAABK/g");
	this.shape.setTransform(325,240);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("EgC1AlgMAAAhK/IFrAAMAAABK/g");
	this.shape_1.setTransform(310.975,240);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("EgEzAlgMAAAhK/IJnAAMAAABK/g");
	this.shape_2.setTransform(297.55,240);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("EgGrAlgMAAAhK/INXAAMAAABK/g");
	this.shape_3.setTransform(284.75,240);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("EgIdAlgMAAAhK/IQ7AAMAAABK/g");
	this.shape_4.setTransform(272.575,240);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("EgKJAlgMAAAhK/IUTAAMAAABK/g");
	this.shape_5.setTransform(261.05,240);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("EgLwAlgMAAAhK/IXhAAMAAABK/g");
	this.shape_6.setTransform(250.125,240);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("EgNRAlgMAAAhK/IajAAMAAABK/g");
	this.shape_7.setTransform(239.85,240);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("EgOsAlgMAAAhK/IdZAAMAAABK/g");
	this.shape_8.setTransform(230.175,240);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("EgQBAlgMAAAhK/MAgDAAAMAAABK/g");
	this.shape_9.setTransform(221.125,240);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("EgRQAlgMAAAhK/MAihAAAMAAABK/g");
	this.shape_10.setTransform(212.725,240);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("EgSZAlgMAAAhK/MAkzAAAMAAABK/g");
	this.shape_11.setTransform(204.9,240);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("EgTdAlgMAAAhK/MAm6AAAMAAABK/g");
	this.shape_12.setTransform(197.75,240);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("EgUaAlgMAAAhK/MAo1AAAMAAABK/g");
	this.shape_13.setTransform(191.2,240);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("EgVSAlgMAAAhK/MAqlAAAMAAABK/g");
	this.shape_14.setTransform(185.275,240);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("EgWDAlgMAAAhK/MAsIAAAMAAABK/g");
	this.shape_15.setTransform(179.95,240);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("EgWwAlgMAAAhK/MAtgAAAMAAABK/g");
	this.shape_16.setTransform(175.3,240);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("EgXWAlgMAAAhK/MAusAAAMAAABK/g");
	this.shape_17.setTransform(171.25,240);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("EgX2AlgMAAAhK/MAvtAAAMAAABK/g");
	this.shape_18.setTransform(167.775,240);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("EgYQAlgMAAAhK/MAwhAAAMAAABK/g");
	this.shape_19.setTransform(165,240);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("EgYkAlgMAAAhK/MAxJAAAMAAABK/g");
	this.shape_20.setTransform(162.8,240);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("EgYzAlgMAAAhK/MAxoAAAMAAABK/g");
	this.shape_21.setTransform(161.25,240);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("EgY8AlgMAAAhK/MAx5AAAMAAABK/g");
	this.shape_22.setTransform(160.3,240);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape_23.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},79).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(252));

	// Text_01___AD1
	this.instance_4 = new lib.g_txt01AD1("single",0);
	this.instance_4.setTransform(-342.2,386.75,1,1,0,0,0,-66.5,28);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({_off:false},0).to({x:-69.45},21,cjs.Ease.get(1)).to({_off:true},72).wait(250));

	// Photo_AD1
	this.instance_5 = new lib.gpic1("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,325,484);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},86).wait(250));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(250));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:18, x:-2, y:-2, w:325, h:484});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:325, h:484});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-112.5,240,442.5,240);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 320,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;