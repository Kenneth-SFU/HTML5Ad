(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,300,250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Pic2 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD123 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("APuAlQAAglASgTQANgPAYAAQAZAAANAPQAOAPABAbIAAAMIhTAAIAAADQAAAwAmAAQASAAASgQIAHAHQgHAMgOAHQgOAGgQAAQg3AAAAhBgARBAWQAAgsgdAAQgcAAgBAsIA6AAIAAAAgANzAkQAAgiAQgSQAQgSAdAAQAYAAAPALIAAAfIgJAAQgLgegXAAQggAAAAA1QAAAfAJAOQAJANARAAQANAAAIgJQAJgJADgQIAKAAIAAAgQgWAPgXAAQg6AAAAhCgAJWAlQgBglATgTQAOgPAXAAQAZAAANAPQAPAPAAAbIAAAMIhUAAIAAADQAAAwAnAAQASAAASgQIAHAHQgHAMgOAHQgNAGgQAAQg4AAAAhBgAKpAWQAAgsgdAAQgcAAgBAsIA6AAIAAAAgAFCAlQAAglASgTQAOgPAXAAQAZAAAOAPQAOAPAAAbIAAAMIhTAAIAAADQAAAwAmAAQATAAARgQIAIAHQgIAMgOAHQgNAGgQAAQg4AAAAhBgAGVAWQAAgsgdAAQgbAAgBAsIA5AAIAAAAgADIAkQAAgiAQgSQAPgSAdAAQAYAAAPALIAAAfIgJAAQgKgegYAAQgfAAAAA1QAAAfAJAOQAIANARAAQANAAAJgJQAIgJAEgQIAJAAIAAAgQgVAPgXAAQg6AAAAhCgAg6AlQAAglASgTQAOgPAXAAQAZAAANAPQAOAPAAAbIAAAMIhSAAIAAADQAAAwAlAAQATAAARgQIAHAHQgGAMgPAHQgNAGgPAAQg4AAAAhBgAAZAWQAAgsgcAAQgcAAgCAsIA6AAIAAAAgAlhAlQAAglASgTQAOgPAXAAQAZAAAOAPQAOAPAAAbIAAAMIhTAAIAAADQAAAwAmAAQATAAARgQIAIAHQgIAMgOAHQgNAGgQAAQg4AAAAhBgAkOAWQAAgsgcAAQgcAAgBAsIA5AAIAAAAgArlAkQAAgiAQgSQAQgSAcAAQAYAAAQALIAAAfIgJAAQgMgegXAAQgfAAAAA1QAAAfAJAOQAIANARAAQANAAAJgJQAJgJACgQIAKAAIAAAgQgVAPgYAAQg5AAAAhCgAtfBXIAAgjIAKAAQACARAMALQAKAKAOAAQAPAAAHgIQAHgHAAgKQAAgTgbgFQgcgEgJgHQgMgIAAgSQAAgOAKgKQANgOAZAAQAbAAAPAMIAAAfIgJAAQgDgOgLgJQgKgIgLAAQgLAAgGAHQgFAGAAAIQAAAJAGAFQAGAEASADQAbAFAKAMQAIAIAAARQAAANgJALQgOAQgdAAQgaAAgWgPgAprAiQAAgdANgSQAPgVAfAAQA3AAAABDQAAAhgMAQQgOAUggAAQg4AAAAhEgApMgDQgFAMgBAZQAAA4AhAAQATAAAIgVQADgMAAgcQAAgygeAAQgUAAgHASgAMnBkIAAgLIARgBIACgDIAAhEQgBgQgDgGQgFgLgSAAQgPAAgKAMQgKALAAAQIAAA+IACADIAPABIAAALIg5AAIAAgLIAQgBIACgDIAAhbQAAgHgEgBIgNgDIAAgJIAkgIIADAAIgBAXIABAAQANgXAeAAQApAAAAAoIAABPIACADIAOABIAAALgAIJBkIAAgLIARgBIABgDIAAigQAAgHgDgBIgOgDIAAgJIAlgGIADAAIAAC6IACADIAPABIAAALgAHBBkIAAgLIAQgBIABgDIAAigQAAgHgDgBIgOgDIAAgJIAlgGIADAAIAAC6IACADIAPABIAAALgACLBkIAAgMIANAAIACgDIgdgpIgdApIACADIAOAAIAAAMIgyAAIAAgMIAOgBIADgCIAlgzIglg0IgDgCIgLgBIAAgMIA2AAIAAAMIgNABIgBACIAZAkIAagkIgCgCIgNgBIAAgMIAxAAIAAAMIgOABIgDACIgiAuIApA5IADACIAMABIAAAMgAjiBkIAAgLIAPgBIADgDIAAhbQABgHgGgBIgNgDIAAgJIAlgIIACAAIgBAdIABAAQAOgdAdAAQAIAAAHACIgFAXQgIgEgKAAQgPAAgJANQgJANAAAVIAAAzIACADIAOABIAAALgAm0BkIgrh2IgCgCIgMgBIAAgMIA3AAIAAAMIgPABIgCACIAgBdIABAAIAghdIgCgCIgQgBIAAgMIAvAAIAAAMIgLABIgDACIgpB2gAurBkIAAgLIAPgBIADgDIAAhbQAAgIgFgBIgNgCIAAgKIAlgHIADAAIAAB3IACADIAPABIAAALgAxZBkIAAgLIARgBIADgDIAAicIgDgDIgRgBIAAgMIBMAAQArAAATAcQAOAWAAAtQAAAtgPAWQgTAZgrAAgAwuBYIAfAAQA0AAAAhMIAAgLQAAhLg0AAIgfAAgAuYg/QgFgFAAgGQAAgGAFgFQAEgEAGAAQAGAAAFAEQAEAFAAAGQAAAGgEAFQgFAEgGAAQgGAAgEgEg");
	this.shape.setTransform(114.45,17.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,7,222.70000000000002,20.4);


(lib.g_txt02AD2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABrIXIgnh5IgIAAIAAB5IhEAAIAAk2ICGAAQAhAMAAAoIAABCQAAAlgdAMIAlBjIAAAsgAA8FmIAaAAIAEgEIAAhFIgEgEIgaAAgAhZIXIgFg9IghAAIgFA9IhAAAIAAg0IAnkCIBeAAIAnECIAAA0gAhjGaIgJhiIgEAAIgJBiIAWAAgAlmIXIAAk2ICOAAIAABBIhJAAIAAA4IBFAAIAABAIhFAAIAAA8IBLAAIAABBgAnvIXIAAh6IgziIIAAg0IBAAAIAUBqIAEAAIAThqIBBAAIAAA0Ig0CIIAAB6gAq5IXIAAh5IgeAAIAAB5IhFAAIAAk2IBFAAIAAB9IAeAAIAAh9IBFAAIAAE2gAu3IXQgigMAAgoIAAjOQAAgoAigMIBlAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgVAAIgFAEIAAC9IAFAFIAVAAIAEgFIAAhBIBFAAIAABKQAAAoghAMgAwqIXIgFg9IghAAIgFA9IhAAAIAAg0IAnkCIBeAAIAnECIAAA0gAw0GaIgJhiIgEAAIgJBiIAWAAgA03IXIAAk2ICOAAIAABBIhJAAIAAA4IBFAAIAABAIhFAAIAAA8IBLAAIAABBgASQCbIAAk1ICGAAQAiAMAAAoIAABjQAAAmgiAMIhBAAIAABsgATVgIIAaAAIAEgEIAAhSIgEgEIgaAAgAP1CbQgigMAAgoIAAjNQAAgoAigMIBkAAQAiAMAAAoIAADNQAAAogiAMgAQYheIAAC8IAEAFIAWAAIAEgFIAAi8IgEgEIgWAAgALMCbQgigMAAgoIAAjNQAAgoAigMIBlAAQAhAMAAAoIAADNQAAAoghAMgALvheIAAC8IAFAFIAVAAIAEgFIAAi8IgEgEIgVAAgAIPCbQgigMAAgoIAAjNQAAgoAigMIBlAAQAhAMAAAoIAABLIhFAAIAAhDIgEgEIgVAAIgFAEIAAC8IAFAFIAVAAIAEgFIAAhBIBFAAIAABKQAAAoghAMgAFbCbIgriHIgEAAIAACHIg8AAIAAk1IA8AAIArCHIAEAAIAAiHIA9AAIAAE1gAB8CbIAAhBIANAAIAAizIgNAAIAAhBIBfAAIAABBIgNAAIAACzIANAAIAABBgAiBCbIAAk1ICGAAQAhAMAAAoIAADNQAAAoghAMgAg8BjIAaAAIAEgFIAAi8IgEgEIgaAAgAkmCbIAAk1ICOAAIAABBIhJAAIAAA4IBFAAIAAA/IhFAAIAAA8IBLAAIAABBgAnBCbIAAk1IBFAAIAAD0IBHAAIAABBgApbCbIAAk1IBFAAIAAD0IBHAAIAABBgAr2CbQgigMAAgoIAAjNQAAgoAigMIBkAAQAiAMAAAoIAADNQAAAogiAMgArTheIAAC8IAEAFIAWAAIAEgFIAAi8IgEgEIgWAAgAtgCbIgoh5IgHAAIAAB5IhFAAIAAk1ICGAAQAiAMAAAoIAABCQAAAkgdAMIAlBjIAAAsgAuPgVIAaAAIAEgEIAAhFIgEgEIgaAAgAwmCbIgriHIgEAAIAACHIg8AAIAAk1IA8AAIArCHIAEAAIAAiHIA9AAIAAE1gA03CbIAAk1ICOAAIAABBIhJAAIAAA4IBFAAIAAA/IhFAAIAAA8IBLAAIAABBgANnAvIAAgyIBXAAIAAAygAx8itIARgzIgPAAIAAg9IBBAAIAAA9IgVAzgANbjgQgigMAAgoIAAg9IBFAAIAAA0IAEAFIAWAAIAEgFIAAgvIgEgGIhGggQgPgGgFgMQgFgJAAgUIAAhBQAAgoAigMIBlAAQAhAMAAAoIAAA5IhFAAIAAgxIgEgEIgWAAIgEAEIAAAtIAGAHIBFAcQAPAGAFANQAEAJAAAUIAABGQAAAoghAMgAK4jgIAAj1IgxAAIAAhBICoAAIAABBIgyAAIAAD1gAI+jgIgriHIgEAAIAACHIg9AAIAAk2IA9AAIArCHIAEAAIAAiHIA8AAIAAE2gAEtjgIAAk2ICOAAIAABBIhJAAIAAA4IBFAAIAABAIhFAAIAAA8IBLAAIAABBgABwjgIAAk2ICGAAQAiAMAAAoIAADOQAAAogiAMgAC1kYIAaAAIAEgFIAAi9IgEgEIgaAAgAgmjgQgigMAAgoIAAkCIBFAAIAAD5IAEAFIARAAIAEgFIAAj5IBFAAIAAECQAAAogiAMgAjLjgIAAj1IgxAAIAAhBICoAAIAABBIgyAAIAAD1gAmNjgQghgMAAgoIAAg9IBFAAIAAA0IAEAFIAWAAIAEgFIAAgvIgEgGIhHggQgPgGgFgMQgEgJAAgUIAAhBQAAgoAhgMIBlAAQAiAMAAAoIAAA5IhFAAIAAgxIgEgEIgWAAIgEAEIAAAtIAFAHIBFAcQAPAGAFANQAFAJAAAUIAABGQAAAogiAMgAqIjgQgigMAAgoIAAjOQAAgoAigMIBlAAQAhAMAAAoIAADOQAAAoghAMgAplnaIAAC9IAFAFIAVAAIAEgFIAAi9IgEgEIgVAAgAtFjgQgigMAAgoIAAjOQAAgoAigMIBlAAQAhAMAAAoIAADOQAAAoghAMgAsinaIAAC9IAFAFIAVAAIAEgFIAAi9IgEgEIgVAAgAwCjgQgigMAAgoIAAg6QAAghAYgOQgYgPAAghIAAg1QAAgoAigMIBlAAQAhAMAAAoIAAA1QAAAhgXAPQAXAOAAAhIAAA6QAAAoghAMgAvflfIAABCIAFAFIAVAAIAEgFIAAhCIgEgEIgVAAgAvfnaIAAA/IAFAEIAVAAIAEgEIAAg/IgEgEIgVAAgA0VjgQgigMAAgoIAAg6QAAghAYgOQgYgPAAghIAAg1QAAgoAigMIBlAAQAhAMAAAoIAAA1QAAAhgXAPQAXAOAAAhIAAA6QAAAoghAMgAzylfIAABCIAFAFIAVAAIAEgFIAAhCIgEgEIgVAAgAzynaIAAA/IAFAEIAVAAIAEgEIAAg/IgEgEIgVAAg");
	this.shape.setTransform(136.625,84.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A3mJeIABs6IgBAAIAAmBMAp6AAAIAAGAIFTAAIAAHCIyOAAIAAF5g");
	this.shape_1.setTransform(127.075,83.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24,23.3,302.2,121.10000000000001);


(lib.g_txt01AD2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIGF7IAAlSICbAAIAABGIhQAAIAABCIBMAAIAABHIhMAAIAACDgAFdF7IAAlSIBLAAIAAEMIBOAAIAABGgACoF7IAAlSICcAAIAABGIhQAAIAAA9IBLAAIAABHIhLAAIAABCIBSAAIAABGgAABF7QgkgNAAgrIAAhDIBKAAIAAA5IAFAFIAYAAIAEgFIAAgzIgEgHIhMgjQgRgHgFgNQgFgKAAgVIAAhIQAAgrAkgNIBuAAQAlANAAArIAAA/IhMAAIAAg1IgEgFIgYAAIgFAFIAAAxIAGAIIBMAeQAQAHAGANQAFAKAAAWIAABNQAAArglANgAhwF7IgriDIgIAAIAACDIhLAAIAAlSICTAAQAkANAAArIAABIQAAApgfAOIAoBsIAAAvgAijC6IAcAAIAFgEIAAhLIgFgFIgcAAgAmTF7QglgNAAgrIAAkaIBLAAIAAEQIAFAFIATAAIAEgFIAAkQIBLAAIAAEaQAAArgkANgApiF7QglgNAAgrIAAjiQAAgrAlgNIBuAAQAlANAAArIAADiQAAArglANgAo7BrIAADOIAEAFIAYAAIAFgFIAAjOIgFgFIgYAAgAsdF7IAAiFIg4iUIAAg5IBGAAIAVB0IAFAAIAVh0IBHAAIAAA5Ig5CUIAACFgAK5goIAAlSICbAAIAABGIhQAAIAAA9IBMAAIAABHIhMAAIAABCIBSAAIAABGgAIPgoQglgNAAgrIAAjiQAAgrAlgNIBuAAQAlANAAArIAAA5IhLAAIAAgvIgFgFIgYAAIgEAFIAADOIAEAFIAYAAIAFgFIAAg9IgTAAIAAhGIBeAAIAACNQAAArglANgAGRgoIgviTIgEAAIAACTIhCAAIAAlSIBCAAIAvCUIAEAAIAAiUIBCAAIAAFSgABngoIAAlSICcAAIAABGIhQAAIAAA9IBLAAIAABHIhLAAIAABCIBSAAIAABGgAhBgoIAAlSIBLAAIAAEMIBNAAIAABGgAjqgoIAAlSIBMAAIAAEMIBNAAIAABGgAlDgoIgFhCIgkAAIgGBCIhGAAIAAg5IArkZIBmAAIArEZIAAA5gAlOiwIgKhrIgFAAIgJBrIAYAAgAoWgoIAAiDIghAAIAACDIhLAAIAAlSIBLAAIAACIIAhAAIAAiIIBLAAIAAFSgAssgoQglgNAAgrIAAjiQAAgrAlgNIBuAAQAlANAAArIAABSIhLAAIAAhIIgFgFIgYAAIgEAFIAADOIAEAFIAYAAIAFgFIAAhHIBLAAIAABRQAAArglANg");
	this.shape.setTransform(88.125,43.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.7,5.8,170.9,75.8);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(56.0483,28.3567,1.1828,1.1827);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(39.9916,19.9893,1.1828,1.1827);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,40);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("ABAC+IAAj9Ij9AAIAAh+IF7AAIAAF7g");
	this.shape.setTransform(19,19);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38,38);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgXA6QgKgGgHgKQgFgJAAgNIAAhQIABgBIABgBIAVAAIABABIABABIAABRQAAAJAGAFQAGAHAIgBQAKABAFgHQAGgFAAgJIAAhRIAAgBIACgBIAVAAIACABIAAABIAABQQAAANgGAJQgFALgLAFQgKAFgOAAQgNAAgKgFg");
	this.shape.setTransform(168.5,21.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIACAAIAAACIAAARIAAACIgCAAIg5AAIgBABIAAAcIABABIAlAAIABAAIACACIAAAQIgCABIgBABIglAAIgBABIAAAxIAAACIgCAAg");
	this.shape_1.setTransform(158.35,21.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgXA7QgLgEgGgJQgFgIAAgMIAAgDIAAgCIACgBIAUAAIACABIAAACIAAACQAAAHAHAFQAGAFALAAQAJAAAFgEQAEgEAAgGQAAgEgDgDQgCgDgFgCIgPgGQgMgEgIgFQgIgDgGgHQgGgIAAgKQAAgLAGgIQAFgIAKgFQAKgEANAAQAMAAALAFQALAFAGAIQAFAJAAALIAAADIAAACIgCAAIgUAAIgCAAIAAgCIAAgBQAAgIgGgFQgHgFgJAAQgJAAgEADQgFAEAAAGQAAAFADADQACADAGACIAQAHIAUAIQAHACAGAHQAFAHAAAMQAAAQgMAKQgMAKgVAAQgNAAgLgFg");
	this.shape_2.setTransform(147.675,21.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_3.setTransform(133.325,21.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIAAACIgCAAg");
	this.shape_4.setTransform(122.6,21.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIgBACIgBAAg");
	this.shape_5.setTransform(108.65,21.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgXA6QgLgFgGgKQgFgKAAgNIAAgoQAAgNAFgJQAGgKALgFQALgGAMAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgFAKQgHAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_6.setTransform(98.1,21.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIABAAIABACIAAARIgBACIgBAAIg5AAIgBABIAAAcIABABIAlAAIABAAIABACIAAAQIgBABIgBABIglAAIgBABIAAAdIABABIA5AAIABAAIABACIAAARIgBACIgBAAg");
	this.shape_7.setTransform(87.725,21.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_8.setTransform(76.425,21.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAgBAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_9.setTransform(64.625,21.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_10.setTransform(53.175,21.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgXA6QgLgFgFgKQgGgKAAgNIAAgoQAAgNAGgJQAFgKALgFQALgGAMAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgGAKQgGAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_11.setTransform(42.3,21.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_12.setTransform(20.475,20.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_13.setTransform(20.475,20.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AD/A6QgLgGgGgJQgFgLgBgOIAAgkQABgNAFgLQAGgKALgGQALgFANAAQAOAAALAFQALAGAFAKQAGALAAANIAAAkQAAAOgGALQgFAJgLAGQgLAGgOAAQgNAAgLgGgAEIgjQgHAGAAALIAAAlQAAALAHAGQAFAHAKAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgKABgFAGgAoiA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFAOAAQAOAAAKAFQALAGAGAKQAFALABANIAAAkQgBAOgFALQgGAJgLAGQgKAGgOAAQgOAAgLgGgAoZgjQgGAGAAALIAAAlQAAALAGAGQAGAHAKAAQAJAAAGgHQAHgGgBgLIAAglQABgLgHgGQgGgGgJgBQgKABgGAGgAJfA6QgKgGgHgJQgFgJAAgOIAAhQIABgBIABAAIAVAAIABAAIABABIAABRQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJIAAhRIAAgBIACAAIAVAAIACAAIAAABIAABQQAAAOgGAJQgFAKgLAFQgKAFgOAAQgOAAgKgFgAGPA7QgLgFgGgIQgGgJAAgLIAAgEIABgBIACgBIAUAAIABABIABABIAAADQAAAHAHAFQAGAFAMAAQAJAAAEgEQAFgEAAgGQAAgEgDgDQgDgDgEgCIgQgHQgMgDgIgFQgJgDgFgHQgGgIAAgKQAAgMAFgHQAGgJAKgEQAKgEAMAAQAOAAAKAFQAMAFAFAIQAGAJAAALIAAADIAAACIgCAAIgVAAIgBAAIAAgCIAAgCQAAgHgHgFQgGgGgLAAQgIABgEADQgFADAAAHQAAAFADADQACACAGADIAQAHIAVAIQAHACAFAHQAGAHAAALQAAARgMAKQgNAKgUgBQgOAAgLgEgAhgA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgFAKQgHAJgKAFQgKAGgOgBQgNAAgLgFgAqOA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgGAKQgGAJgKAFQgKAGgOgBQgNAAgLgFgAHpA+IgCAAIAAgCIAAh4IAAgBIACAAIBRAAIACAAIAAABIAAASIAAABIgCABIg5AAIgCABIAAAcIACABIAmAAIABAAIABACIAAAQIgBABIgBABIgmAAIgCAAIAAAyIAAACIgCAAgAChA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBaAAIACAAIAAABIAAASIAAABIgCABIggAAIgBABIAABjIgBACIgBAAgAAVA+IgBAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBZAAIACAAIAAABIAAASIAAABIgCABIgfAAIgBABIAABjIgBACIgCAAgAjZA+IgCAAIAAgCIAAh4IAAgBIACAAIBTAAIABAAIABABIAAASIgBABIgBABIg7AAIgBABIAAAcIABABIAmAAIABAAIACACIAAAQIgCABIgBABIgmAAIgBAAIAAAdIABABIA7AAIABABIABACIAAARIgBACIgBAAgAkHA+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBAAIgthMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIAAAAIAAhLIABgBIABAAIAWAAIABAAIABABIAAB4IgBACIgBAAgAl9A+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAAAIguhMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIABAAIAAhLIAAgBIABAAIAVAAIACAAIABABIAAB4IgBACIgCAAg");
	this.shape_14.setTransform(105.4,21.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AueDNIAAmZIc9AAIAAGZg");
	this.shape_15.setTransform(92.725,20.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AOfDNI89AAIAAmZIc9AAg");
	this.shape_16.setTransform(92.725,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,187.5,43);


(lib.gpic2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(270,12,1,1,180,0,0,26,26);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(156,129.05,1,1,0,0,0,26,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Halo
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.6)","rgba(0,0,0,0)"],[0,0.953],-77.9,51.9,0,-77.9,51.9,169.1).s().p("A2zOEIAA8BQB2gGB7AAQRWAAMPIOQMDIGAOLZIAAAag");
	this.shape.setTransform(145.975,160.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Photo
	this.instance_2 = new lib.Pic2();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250.1);


// stage content:
(lib.banner_300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	var mask_graphics_80 = new cjs.Graphics().p("AisTiMAAAgnDIFZAAMAAAAnDg");
	var mask_graphics_81 = new cjs.Graphics().p("AkiTiMAAAgnDIJFAAMAAAAnDg");
	var mask_graphics_82 = new cjs.Graphics().p("AmSTiMAAAgnDIMlAAMAAAAnDg");
	var mask_graphics_83 = new cjs.Graphics().p("An+TiMAAAgnDIP9AAMAAAAnDg");
	var mask_graphics_84 = new cjs.Graphics().p("ApjTiMAAAgnDITHAAMAAAAnDg");
	var mask_graphics_85 = new cjs.Graphics().p("ArDTiMAAAgnDIWHAAMAAAAnDg");
	var mask_graphics_86 = new cjs.Graphics().p("AsdTiMAAAgnDIY7AAMAAAAnDg");
	var mask_graphics_87 = new cjs.Graphics().p("AtyTiMAAAgnDIblAAMAAAAnDg");
	var mask_graphics_88 = new cjs.Graphics().p("AvCTiMAAAgnDIeFAAMAAAAnDg");
	var mask_graphics_89 = new cjs.Graphics().p("AwMTiMAAAgnDMAgZAAAMAAAAnDg");
	var mask_graphics_90 = new cjs.Graphics().p("AxQTiMAAAgnDMAihAAAMAAAAnDg");
	var mask_graphics_91 = new cjs.Graphics().p("AyQTiMAAAgnDMAkhAAAMAAAAnDg");
	var mask_graphics_92 = new cjs.Graphics().p("AzJTiMAAAgnDMAmTAAAMAAAAnDg");
	var mask_graphics_93 = new cjs.Graphics().p("Az9TiMAAAgnDMAn7AAAMAAAAnDg");
	var mask_graphics_94 = new cjs.Graphics().p("A0sTiMAAAgnDMApZAAAMAAAAnDg");
	var mask_graphics_95 = new cjs.Graphics().p("A1VTiMAAAgnDMAqrAAAMAAAAnDg");
	var mask_graphics_96 = new cjs.Graphics().p("A14TiMAAAgnDMArxAAAMAAAAnDg");
	var mask_graphics_97 = new cjs.Graphics().p("A2WTiMAAAgnDMAstAAAMAAAAnDg");
	var mask_graphics_98 = new cjs.Graphics().p("A2vTiMAAAgnDMAtfAAAMAAAAnDg");
	var mask_graphics_99 = new cjs.Graphics().p("A3CTiMAAAgnDMAuFAAAMAAAAnDg");
	var mask_graphics_100 = new cjs.Graphics().p("A3QTiMAAAgnDMAuhAAAMAAAAnDg");
	var mask_graphics_101 = new cjs.Graphics().p("A3YTiMAAAgnDMAuxAAAMAAAAnDg");
	var mask_graphics_102 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:305,y:125}).wait(1).to({graphics:mask_graphics_80,x:291.825,y:125}).wait(1).to({graphics:mask_graphics_81,x:279.225,y:125}).wait(1).to({graphics:mask_graphics_82,x:267.2,y:125}).wait(1).to({graphics:mask_graphics_83,x:255.75,y:125}).wait(1).to({graphics:mask_graphics_84,x:244.925,y:125}).wait(1).to({graphics:mask_graphics_85,x:234.675,y:125}).wait(1).to({graphics:mask_graphics_86,x:225.025,y:125}).wait(1).to({graphics:mask_graphics_87,x:215.925,y:125}).wait(1).to({graphics:mask_graphics_88,x:207.425,y:125}).wait(1).to({graphics:mask_graphics_89,x:199.525,y:125}).wait(1).to({graphics:mask_graphics_90,x:192.175,y:125}).wait(1).to({graphics:mask_graphics_91,x:185.45,y:125}).wait(1).to({graphics:mask_graphics_92,x:179.3,y:125}).wait(1).to({graphics:mask_graphics_93,x:173.75,y:125}).wait(1).to({graphics:mask_graphics_94,x:168.75,y:125}).wait(1).to({graphics:mask_graphics_95,x:164.375,y:125}).wait(1).to({graphics:mask_graphics_96,x:160.55,y:125}).wait(1).to({graphics:mask_graphics_97,x:157.325,y:125}).wait(1).to({graphics:mask_graphics_98,x:154.675,y:125}).wait(1).to({graphics:mask_graphics_99,x:152.625,y:125}).wait(1).to({graphics:mask_graphics_100,x:151.175,y:125}).wait(1).to({graphics:mask_graphics_101,x:150.275,y:125}).wait(1).to({graphics:mask_graphics_102,x:150,y:125}).wait(252));

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(26.1,0.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(275));

	// Btn
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(97.5,158.3,1,1,0,0,0,83,25.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:118.5,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD123
	this.instance_2 = new lib.g_txt03AD123("synched",0);
	this.instance_2.setTransform(32.05,80.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(116));

	// text_02__Ad02
	this.instance_3 = new lib.g_txt02AD2("synched",0);
	this.instance_3.setTransform(-344.95,88.5,1,1,0,0,0,-66.5,28);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({x:-42.5},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-344.95},21,cjs.Ease.get(1)).to({_off:true},3).wait(147));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	this.shape.setTransform(305,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("AisTiMAAAgnDIFZAAMAAAAnDg");
	this.shape_1.setTransform(291.825,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AkiTiMAAAgnDIJFAAMAAAAnDg");
	this.shape_2.setTransform(279.225,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("AmSTiMAAAgnDIMlAAMAAAAnDg");
	this.shape_3.setTransform(267.2,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("An+TiMAAAgnDIP9AAMAAAAnDg");
	this.shape_4.setTransform(255.75,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("ApjTiMAAAgnDITHAAMAAAAnDg");
	this.shape_5.setTransform(244.925,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("ArDTiMAAAgnDIWHAAMAAAAnDg");
	this.shape_6.setTransform(234.675,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("AsdTiMAAAgnDIY7AAMAAAAnDg");
	this.shape_7.setTransform(225.025,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("AtyTiMAAAgnDIblAAMAAAAnDg");
	this.shape_8.setTransform(215.925,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("AvCTiMAAAgnDIeFAAMAAAAnDg");
	this.shape_9.setTransform(207.425,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("AwMTiMAAAgnDMAgZAAAMAAAAnDg");
	this.shape_10.setTransform(199.525,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("AxQTiMAAAgnDMAihAAAMAAAAnDg");
	this.shape_11.setTransform(192.175,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("AyQTiMAAAgnDMAkhAAAMAAAAnDg");
	this.shape_12.setTransform(185.45,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("AzJTiMAAAgnDMAmTAAAMAAAAnDg");
	this.shape_13.setTransform(179.3,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("Az9TiMAAAgnDMAn7AAAMAAAAnDg");
	this.shape_14.setTransform(173.75,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("A0sTiMAAAgnDMApZAAAMAAAAnDg");
	this.shape_15.setTransform(168.75,125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("A1VTiMAAAgnDMAqrAAAMAAAAnDg");
	this.shape_16.setTransform(164.375,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("A14TiMAAAgnDMArxAAAMAAAAnDg");
	this.shape_17.setTransform(160.55,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("A2WTiMAAAgnDMAstAAAMAAAAnDg");
	this.shape_18.setTransform(157.325,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("A2vTiMAAAgnDMAtfAAAMAAAAnDg");
	this.shape_19.setTransform(154.675,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("A3CTiMAAAgnDMAuFAAAMAAAAnDg");
	this.shape_20.setTransform(152.625,125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("A3QTiMAAAgnDMAuhAAAMAAAAnDg");
	this.shape_21.setTransform(151.175,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("A3YTiMAAAgnDMAuxAAAMAAAAnDg");
	this.shape_22.setTransform(150.275,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_23.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},79).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(252));

	// Text_01___AD2
	this.instance_4 = new lib.g_txt01AD2("synched",0);
	this.instance_4.setTransform(-244.2,186,1,1,0,0,0,-66.5,28);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({_off:false},0).to({x:-69.45},21,cjs.Ease.get(1)).to({_off:true},72).wait(250));

	// Photo_AD2
	this.instance_5 = new lib.gpic2("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,304,254);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},86).wait(250));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(250));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:18, x:-2, y:-2, w:304, h:254});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:304, h:254});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-25,125,335,125.1);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;