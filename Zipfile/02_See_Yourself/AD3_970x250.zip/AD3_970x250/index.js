(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,970,250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap9 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD123 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AVQAyQAAgyAYgaQAUgVAeAAQAjAAASAVQATAVAAAkIAAAQIhwAAIAAAEQAABAAzAAQAaABAXgVIAKAJQgJAQgTAJQgTAJgVAAQhMAAAAhYgAXBAeQAAg8gnAAQgmAAgCA8IBPAAIAAAAgASrAxQAAgvAWgYQAVgYAmAAQAhAAAVAPIAAAqIgNAAQgOgpggAAQgqABAABGQAAArAMATQALASAYAAQAQAAAMgNQAMgMAEgWIANAAIAAArQgcAVggAAQhOAAAAhZgAMoAyQAAgyAYgaQAUgVAeAAQAjAAASAVQATAVAAAkIAAAQIhwAAIAAAEQAABAAzAAQAaABAXgVIAKAJQgJAQgTAJQgTAJgVAAQhMAAAAhYgAOZAeQAAg8gnAAQgmAAgCA8IBPAAIAAAAgAGzAyQAAgyAYgaQAUgVAeAAQAjAAASAVQATAVAAAkIAAAQIhwAAIAAAEQAABAAzAAQAaABAXgVIAKAJQgJAQgTAJQgTAJgVAAQhMAAAAhYgAIkAeQAAg8gnAAQgmAAgCA8IBPAAIAAAAgAEOAxQAAgvAWgYQAVgYAmAAQAhAAAVAPIAAAqIgNAAQgOgpggAAQgqABAABGQAAArAMATQALASAYAAQAQAAAMgNQAMgMAEgWIANAAIAAArQgcAVggAAQhOAAAAhZgAhPAyQAAgyAYgaQAUgVAeAAQAiAAASAVQATAVAAAkIAAAQIhvAAIAAAEQAABAAyAAQAaABAXgVIAKAJQgJAQgTAJQgTAJgUAAQhMAAAAhYgAAhAeQAAg8gmAAQgmAAgCA8IBOAAIAAAAgAneAyQAAgyAYgaQAUgVAeAAQAjAAASAVQATAVAAAkIAAAQIhwAAIAAAEQAABAAzAAQAaABAXgVIAKAJQgJAQgTAJQgTAJgVAAQhMAAAAhYgAltAeQAAg8gnAAQgmAAgCA8IBPAAIAAAAgAvqAxQAAgvAWgYQAVgYAmAAQAhAAAVAPIAAAqIgNAAQgOgpggAAQgqABAABGQAAArAMATQALASAYAAQAQAAAMgNQAMgMAEgWIANAAIAAArQgcAVggAAQhOAAAAhZgAyOB1IAAgvIANAAQADAYAPANQAOAOATAAQAUAAAKgKQAJgJAAgPQAAgZgkgGQgmgGgNgKQgPgLAAgYQAAgTAOgOQARgSAhAAQAkAAAWAQIAAAqIgMAAQgGgTgOgMQgNgLgPAAQgOAAgJAJQgIAIAAALQAAAMAJAHQAJAGAYAFQAkAGAOAPQALAMAAAXQAAASgNAOQgSAWgoAAQgkAAgcgVgAtFAuQAAgoASgYQAVgcApAAQBLAAAABaQAAAtgRAXQgTAagrAAQhMgBAAhbgAsbgEQgIAQAAAjQABBKArAAQAbAAAJgbQAGgRAAgmQAAhEgqAAQgaAAgKAZgARECIIAAgQIAWgBIACgEIAAhcQAAgWgEgIQgIgPgXAAQgVAAgNAQQgNAPAAAWIAABUIADAEIATABIAAAQIhNAAIAAgQIAWgBIACgEIABh8QAAgKgGgBIgSgDIAAgNIAxgLIAEAAIgCAgIABAAQATgfAoAAQA4AAAAA2IAABrIACAEIAUABIAAAQgALBCIIAAgQIAWgBIACgEIABjZQAAgKgGAAIgSgEIAAgNIAygIIAEAAIAAD8IADAEIAUABIAAAQgAJeCIIAAgQIAWgBIACgEIABjZQAAgKgGAAIgSgEIAAgNIAygIIAEAAIAAD8IADAEIAUABIAAAQgAC7CIIAAgQIASgBIADgEIgng4IgoA4IADAEIATABIAAAQIhDAAIAAgRIASgBIAEgDIAzhFIgzhGIgDgDIgPgBIAAgRIBJAAIAAAQIgRABIgCAEIAiAwIAjgwIgDgEIgSgBIAAgQIBEAAIAAARIgUABIgEADIguA+IA3BNIAEADIAQABIAAARgAkzCIIAAgQIAVgBIAEgEIAAh8QAAgKgGgBIgTgDIAAgNIAygLIAEAAIgCApIABAAQATgoAoAAQAKAAAKADIgHAeQgLgFgNAAQgUAAgNASQgMARAAAeIAABEIADAEIAUABIAAAQgApOCIIg6igIgDgDIgPgBIAAgRIBKAAIAAAQIgVABIgCAEIArB+IABAAIArh+IgDgEIgVgBIAAgQIA/AAIAAARIgPABIgDADIg4CggAz2CIIAAgQIAVgBIADgEIAAh8QAAgKgGgBIgRgDIAAgOIAxgKIAFAAIAACiIACAEIAUABIAAAQgA3hCIIAAgQIAYgBIACgEIAAjTIgCgFIgYgBIAAgQIBnAAQA6ABAZAkQAUAfAAA9QAAA8gVAeQgZAig7ABgA2nB3IAqAAQBHgBAAhmIAAgOQAAhnhHAAIgqAAgAzdhWQgGgGAAgJQAAgIAGgGQAGgGAJAAQAIAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgIAAQgJAAgGgGg");
	this.shape.setTransform(154.025,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.5,8.7,301.1,27.599999999999998);


(lib.g_txt02AD3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EAmWACxQgmgOAAguIAAjqQAAgsAmgOIBzAAQAmAOAAAsIAADqQAAAugmAOgEAm+gBrIAADXIAFAFIAZAAIAFgFIAAjXIgFgEIgZAAgEAjsACxIAAhKIAPAAIAAjMIgPAAIAAhKIBsAAIAABKIgPAAIAADMIAPAAIAABKgEAhXACxIAAkWIg5AAIAAhKIC/AAIAABKIg4AAIAAEWgAfLCxIgGhFIglAAIgGBFIhJAAIAAg8IAskkIBrAAIAtEkIAAA8gAe/AiIgKhuIgFAAIgKBuIAZAAgAcDCxIgtiJIgJAAIAACJIhOAAIAAlgICZAAQAmAOAAAsIAABLQAAAqghAPIAqBwIAAAygAbNgYIAeAAIAFgEIAAhPIgFgEIgeAAgAWZCxIAAiMIg7iZIAAg7IBKAAIAWB4IAFAAIAWh4IBJAAIAAA7Ig7CZIAACMgATOCxIAAkWIg5AAIAAhKIC/AAIAABKIg4AAIAAEWgAPvCxIAAlgIBOAAIAAEWIBRAAIAABKgANDCxQgngOAAguIAAkkIBPAAIAAEbIAFAFIATAAIAFgFIAAkbIBPAAIAAEkQAAAugmAOgAJrCxQgmgOAAguIAAjqQAAgsAmgOIBzAAQAmAOAAAsIAABWIhOAAIAAhMIgFgEIgZAAIgFAEIAADXIAFAFIAZAAIAFgFIAAhKIBOAAIAABTQAAAugmAOgAHoCxIgGhFIglAAIgGBFIhJAAIAAg8IAskkIBrAAIAtEkIAAA8gAHcAiIgKhuIgFAAIgKBuIAZAAgAC4CxIAAlgICiAAIAABKIhTAAIAABDIBOAAIAABKIhOAAIAACJgAhBCxQgngOAAguIAAjqQAAgsAngOIBxAAQAnAOAAAsIAADqQAAAugnAOgAgZhrIAADXIAFAFIAXAAIAFgFIAAjXIgFgEIgXAAgAj9CxIAAkWIg4AAIAAhKIC/AAIAABKIg5AAIAAEWgAoKCxIAAkWIg5AAIAAhKIC/AAIAABKIg4AAIAAEWgAqWCxIgxiaIgFAAIAACaIhFAAIAAlgIBFAAIAxCaIAFAAIAAiaIBFAAIAAFggAvNCxIAAlgICiAAIAABKIhUAAIAAA/IBPAAIAABIIhPAAIAABFIBWAAIAABKgAylCxIAAlgICZAAQAnAOAAAsIAADqQAAAugnAOgAxWBxIAdAAIAFgFIAAjXIgFgEIgdAAgA1RCxQgmgOAAguIAAkkIBOAAIAAEbIAFAFIAUAAIAFgFIAAkbIBOAAIAAEkQAAAugmAOgA4MCxIAAkWIg5AAIAAhKIC/AAIAABKIg4AAIAAEWgA7qCxQgmgOAAguIAAhFIBPAAIAAA8IAEAFIAZAAIAFgFIAAg2IgFgHIhQgkQgRgIgGgMQgFgLAAgWIAAhLQAAgsAmgOIBzAAQAmAOAAAsIAABCIhOAAIAAg4IgFgEIgZAAIgEAEIAAA0IAGAIIBPAfQAQAIAGAMQAFALAAAWIAABQQAAAugmAOgEggdACxIAAhKIAsAAIAAjMIgoAAIAAhKIB2AAIAAEWIAnAAIAABKgEgiRACxIAAhFIBKAAIAABFgEglCACxQgmgOAAguIAAguIBOAAIAAAlIAFAFIAZAAIAFgFIAAhSIgPAPIg8AAQgmgOAAgsIAAhkQAAgsAmgOIBzAAQAmAOAAAsIAADqQAAAugmAOgEgkagBrIAABVIAFAFIAZAAIAFgFIAAhVIgFgEIgZAAgEgouACxIAAhKIAsAAIAAjMIgoAAIAAhKIB2AAIAAEWIAnAAIAABKgEgiRAAAIAAhDIBKAAIAABDg");
	this.shape.setTransform(265.675,23.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgqHAD6IAAnzMBUPAAAIAAHzg");
	this.shape_1.setTransform(264.625,23.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,-1.5,539.3,50.1);


(lib.g_txt01AD3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ATXDjIAAnFIDQAAIAABfIhrAAIAABYIBlAAIAABdIhlAAIAACxgAP1DjIAAnFIBkAAIAAFmIBpAAIAABfgAMCDjIAAnFIDQAAIAABfIhrAAIAABSIBlAAIAABdIhlAAIAABYIBuAAIAABfgAIiDjQgxgSAAg6IAAhZIBlAAIAABMIAFAHIAhAAIAGgHIAAhFIgGgJIhoguQgWgKgHgQQgHgOABgcIAAhgQAAg6AxgSICTAAQAyASAAA6IAABUIhlAAIAAhIIgGgGIghAAIgFAGIAABCIAIALIBlApQAVAIAIARQAGAOABAdIAABnQAAA6gyASgAGJDjIg5ixIgLAAIAACxIhlAAIAAnFIDFAAQAxASAAA6IAABgQAAA2gqASIA2CRIAABAgAFFgfIAmAAIAGgGIAAhlIgGgGIgmAAgAADDjQgwgSgBg6IAAl5IBkAAIAAFsIAGAHIAaAAIAHgHIAAlsIBkAAIAAF5QAAA6gxASgAkRDjQgxgSgBg6IAAktQABg6AxgSICTAAQAyASAAA6IAAEtQAAA6gyASgAjdiKIAAEUIAFAHIAhAAIAGgHIAAkUIgGgGIghAAgAoMDjIAAizIhLjGIAAhMIBeAAIAdCcIAGAAIAcicIBfAAIAABMIhMDGIAACzgAuiDjIAAnFIDQAAIAABfIhrAAIAABSIBlAAIAABdIhlAAIAABYIBuAAIAABfgAyUDjIAAnFIDPAAIAABfIhrAAIAABSIBlAAIAABdIhlAAIAABYIBuAAIAABfgA11DjQgxgSAAg6IAAhZIBlAAIAABMIAGAHIAgAAIAGgHIAAhFIgGgJIhnguQgWgKgIgQQgGgOAAgcIAAhgQAAg6AxgSICTAAQAyASAAA6IAABUIhlAAIAAhIIgGgGIggAAIgGAGIAABCIAIALIBlApQAWAIAHARQAHAOAAAdIAABnQAAA6gyASg");
	this.shape.setTransform(147.95,-4.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.3,-26.9,289.4,45.3);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(72.895,36.9161,1.5386,1.5404);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(52.0086,26.0181,1.5386,1.5404);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104,52.1);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("ABYEEIAAlbIlbAAIAAisIIHAAIAAIHg");
	this.shape.setTransform(26,26);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,52,52);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgdBJQgOgHgHgMQgHgNAAgPIAAhmIABgCIACgBIAaAAIACABIABACIAABmQAAAMAHAHQAHAHALAAQAMAAAHgHQAIgHAAgMIAAhmIAAgCIACgBIAbAAIACABIAAACIAABmQAAAPgHANQgHAMgNAHQgOAHgRAAQgQAAgNgHg");
	this.shape.setTransform(213.075,27.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgzBPIgCgBIgBgCIAAiXIABgCIACgBIBnAAIACABIABACIAAAWIgBACIgCAAIhJAAQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABIAAAiQAAABAAAAQAAAAAAAAQABABAAAAQAAAAAAAAIAwAAIACAAIAAACIAAAVIAAACIgCABIgwAAIgBABIAAA+IgBACIgCABg");
	this.shape_1.setTransform(200.225,27.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgdBLQgOgGgHgLQgIgKAAgPIAAgEIABgCIACgBIAaAAIACABIAAACIAAADQAAAJAJAGQAIAGANAAQAMAAAGgFQAGgFAAgHQAAgGgEgDQgDgEgHgDIgSgIQgPgFgLgFQgKgFgHgJQgHgJAAgOQAAgNAHgLQAHgKAMgFQAMgGARAAQAQAAANAGQANAHAIALQAHAKAAAPIAAADIAAACIgCABIgaAAIgCgBIgBgCIAAgCQAAgJgIgHQgHgGgNAAQgKAAgGAEQgGAFAAAIQAAAFADAEQAEAEAHADIAUAIQAQAGAJAEQAJAEAHAJQAIAJAAAOQAAAVgQAMQgPANgbAAQgRAAgNgGg");
	this.shape_2.setTransform(186.725,27.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgeBKQgNgIgIgNQgHgMAAgRIAAgvQAAgRAHgNQAIgMANgIQANgHARAAQASAAANAHQAOAIAHAMQAHANAAARIAAAvQAAARgHANQgHAMgOAIQgNAHgSAAQgRAAgNgHgAgTgtQgHAJAAANIAAAwQAAANAHAIQAIAIALAAQAMAAAIgIQAIgIAAgNIAAgwQAAgNgIgJQgHgHgNgBQgLABgIAHg");
	this.shape_3.setTransform(168.575,27.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgNBPIgCgBIAAgCIAAh9IgCgBIgnAAIgCgBIAAgCIAAgWIAAgCIACgBIBxAAIACABIAAACIAAAWIAAACIgCABIgpAAIgBABIAAB9IgBACIgBABg");
	this.shape_4.setTransform(155.025,27.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgNBPIgCgBIAAgCIAAh9IgCgBIgnAAIgCgBIAAgCIAAgWIAAgCIACgBIBxAAIACABIAAACIAAAWIAAACIgCABIgpAAIgBABIAAB9IgBACIgBABg");
	this.shape_5.setTransform(137.375,27.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgeBKQgNgHgHgNQgIgMAAgQIAAgzQAAgQAIgNQAHgMANgHQAOgHAQAAQASAAAMAHQANAGAIAMQAIAMgBAPQAAABAAAAQAAABAAAAQgBAAAAABQgBAAgBAAIgaABIAAAAQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgMgIgHQgHgHgMAAQgLAAgHAHQgIAHABAMIAAA1QgBAMAIAHQAHAHALAAQAMAAAHgHQAIgHAAgMQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIAaABIACABIABABQABAQgIAMQgIAMgNAGQgMAHgSAAQgQAAgOgHg");
	this.shape_6.setTransform(124.05,27.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgzBPIgCgBIgBgCIAAiXIABgCIACgBIBnAAIACABIABACIAAAWIgBACIgCAAIhJAAQAAAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIAAAiQAAABAAAAQAAAAABAAQAAABAAAAQAAAAAAAAIAwAAIACAAIAAACIAAAVIAAACIgCABIgwAAIgBABIAAAkQAAABAAAAQAAAAABAAQAAABAAAAQAAAAAAAAIBJAAIACAAIABACIAAAWIgBACIgCABg");
	this.shape_7.setTransform(110.875,27.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAhBPQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAIg5hfIgBgBIgBABIABBeIgBACIgCABIgaAAIgCgBIgBgCIAAiXIABgCIACgBIAZAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIA5BfIABAAIABgBIgBhdIABgCIACgBIAaAAIACABIABACIAACXIgBACIgCABg");
	this.shape_8.setTransform(96.575,27.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAhBPQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAIg5hfIgBgBIgBABIABBeIgBACIgCABIgaAAIgCgBIgBgCIAAiXIABgCIACgBIAZAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIA5BfIABAAIABgBIgBhdIABgCIACgBIAaAAIACABIABACIAACXIgBACIgCABg");
	this.shape_9.setTransform(81.625,27.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgeBKQgNgIgIgNQgHgMAAgRIAAgvQAAgRAHgNQAIgMANgIQANgHARAAQASAAANAHQAOAIAHAMQAHANAAARIAAAvQAAARgHANQgHAMgOAIQgNAHgSAAQgRAAgNgHgAgTgtQgHAJAAANIAAAwQAAANAHAIQAIAIALAAQAMAAAIgIQAIgIAAgNIAAgwQAAgNgIgJQgHgHgNgBQgLABgIAHg");
	this.shape_10.setTransform(67.175,27.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgeBKQgNgHgHgNQgHgMAAgQIAAgzQAAgQAHgNQAHgMANgHQAOgHAQAAQARAAAOAHQANAGAHAMQAHAMABAPQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAIgaABIgBAAQgBAAAAAAQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgMgGgHQgIgHgMAAQgLAAgIAHQgGAHgBAMIAAA1QABAMAGAHQAIAHALAAQAMAAAIgHQAGgHAAgMQAAAAABgBQAAAAAAgBQABAAAAAAQABAAABAAIAaABIACABIABABQgBAQgHAMQgHAMgNAGQgOAHgRAAQgQAAgOgHg");
	this.shape_11.setTransform(53.45,27.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AhXB7IB6h7Ih6h6IAagbICVCVIiVCWg");
	this.shape_12.setTransform(25.825,25.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhXB7IB6h7Ih6h6IAagbICVCVIiVCWg");
	this.shape_13.setTransform(25.825,25.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AFDBKQgOgIgHgNQgIgMAAgRIAAgvQAAgRAIgNQAHgMAOgIQANgHARAAQASAAAOAHQANAIAHAMQAHANABARIAAAvQgBARgHANQgHAMgNAIQgOAHgSAAQgRAAgNgHgAFNgtQgHAJAAANIAAAwQAAANAHAIQAIAIAMAAQAMAAAJgIQAHgIAAgNIAAgwQAAgNgHgJQgIgHgNgBQgMABgIAHgAqzBKQgNgIgHgNQgIgMAAgRIAAgvQAAgRAIgNQAHgMANgIQANgHATAAQARAAANAHQAOAIAHAMQAHANAAARIAAAvQAAARgHANQgHAMgOAIQgNAHgRAAQgTAAgNgHgAqogtQgHAJAAANIAAAwQAAANAHAIQAIAIANAAQALAAAJgIQAHgIAAgNIAAgwQAAgNgHgJQgIgHgMgBQgNABgIAHgAMABJQgNgGgIgNQgHgMAAgQIAAhlIABgCIACgBIAaAAIACABIABACIAABlQAAAMAHAIQAIAHAMAAQALAAAIgHQAHgIAAgMIAAhlIABgCIACgBIAaAAIACABIAAACIAABlQABAQgIAMQgHANgNAGQgNAIgRgBQgSABgNgIgAH4BLQgOgGgGgLQgIgKAAgPIAAgFIABgCIACgBIAZAAIACABIABACIAAAEQAAAIAIAHQAJAGAOAAQAMAAAGgFQAGgFgBgIQAAgFgDgEQgEgEgGgCIgTgIQgPgFgLgGQgKgEgHgJQgIgJAAgOQAAgNAIgLQAHgKALgFQANgGAQAAQASAAANAGQANAHAHALQAIAKAAAPIAAADIAAACIgCAAIgaAAIgDAAIAAgCIAAgCQAAgJgIgHQgIgHgNAAQgKAAgHAFQgFAFAAAHQgBAGAEADQAEAFAGACIAWAJQAQAFAIAFQAJADAIAKQAHAIAAAOQAAAWgPAMQgPAMgbAAQgSAAgOgFgAh6BJQgNgGgHgNQgIgMAAgRIAAgzQAAgPAIgNQAHgNANgGQAOgHARAAQASAAAMAGQANAHAIAMQAIALgBAQQAAABAAAAQAAABAAAAQgBAAAAAAQgBAAgBAAIgaACIAAAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAgBQAAgLgIgIQgHgGgMgBQgMABgHAGQgIAIABALIAAA2QgBALAIAIQAHAHAMAAQAMAAAHgHQAIgIAAgLQAAgBAAAAQAAgBAAAAQABAAAAAAQABAAAAgBIAaABIACABIABACQABAQgIALQgIANgNAGQgMAGgSAAQgRABgOgIgAs8BJQgNgGgHgNQgHgMAAgRIAAgzQAAgPAHgNQAHgNANgGQAOgHARAAQARAAAOAGQANAHAHAMQAHALABAQQAAABgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIgaACIgBAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAgBQAAgLgGgIQgIgGgMgBQgMABgIAGQgGAIgBALIAAA2QABALAGAIQAIAHAMAAQAMAAAIgHQAGgIAAgLQAAgBABAAQAAgBAAAAQABAAAAAAQABAAABgBIAaABIACABIABACQgBAQgHALQgHANgNAGQgOAGgRAAQgRABgOgIgAJqBOIgCAAIgBgCIAAiXIABgCIACgBIBnAAIACABIACACIAAAVIgCACIgCABIhJAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAABIAAAiQAAAAAAABQAAAAAAAAQAAAAABAAQAAABAAAAIAwAAIADAAIAAACIAAAVIAAACIgDABIgwAAIgBABIAAA+IgBACIgCAAgADMBOIgCAAIgBgCIAAh9IgBgBIgnAAIgCgCIAAgBIAAgWIAAgCIACgBIByAAIACABIAAACIAAAWIAAABIgCACIgpAAIgBABIAAB9IgBACIgBAAgAAbBOIgBAAIgBgCIAAh9IgBgBIgnAAIgCgCIAAgBIAAgWIAAgCIACgBIBxAAIACABIAAACIAAAWIAAABIgCACIgpAAIgBABIAAB9IgBACIgBAAgAkTBOIgCAAIgBgCIAAiXIABgCIACgBIBoAAIACABIABACIAAAVIgBACIgCABIhJAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIAAAiQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABABAAIAwAAIACAAIAAACIAAAVIAAACIgCABIgwAAIgBABIAAAkQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIBJAAIACABIABACIAAAWIgBACIgCAAgAlMBOQgBAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIg6hgIgBAAIgBABIABBeIgBACIgCAAIgaAAIgCAAIgBgCIAAiXIABgCIACgBIAaAAQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIA6BeIACABIAAgBIAAhdIABgCIACgBIAaAAIABABIABACIAACXIgBACIgBAAgAniBOQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAIg5hgIgCAAIAAABIAABeIgBACIgCAAIgaAAIgCAAIAAgCIAAiXIAAgCIACgBIAaAAQABAAAAAAQAAAAABAAQAAABAAAAQABAAAAABIA6BeIABABIAAgBIAAhdIABgCIACgBIAaAAIACABIABACIAACXIgBACIgCAAg");
	this.shape_14.setTransform(133.25,27.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AySEDIAAoFMAkkAAAIAAIFg");
	this.shape_15.setTransform(117.05,25.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("ASTEDMgklAAAIAAoFMAklAAAg");
	this.shape_16.setTransform(117.05,25.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,236.1,53.8);


(lib.gpic3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(826.15,81.95,1,1,180,0,0,26,26);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(685.1,204.05,1,1,0,0,0,26,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Photo
	this.instance_2 = new lib.Bitmap9();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


// stage content:
(lib.banner_970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	var mask_graphics_80 = new cjs.Graphics().p("AnJTiMAAAgnDIOTAAMAAAAnDg");
	var mask_graphics_81 = new cjs.Graphics().p("AtQTiMAAAgnDIahAAMAAAAnDg");
	var mask_graphics_82 = new cjs.Graphics().p("AzETiMAAAgnDMAmJAAAMAAAAnDg");
	var mask_graphics_83 = new cjs.Graphics().p("A4lTiMAAAgnDMAxLAAAMAAAAnDg");
	var mask_graphics_84 = new cjs.Graphics().p("A91TiMAAAgnDMA7rAAAMAAAAnDg");
	var mask_graphics_85 = new cjs.Graphics().p("EgizATiMAAAgnDMBFmAAAMAAAAnDg");
	var mask_graphics_86 = new cjs.Graphics().p("EgneATiMAAAgnDMBO9AAAMAAAAnDg");
	var mask_graphics_87 = new cjs.Graphics().p("Egr3ATiMAAAgnDMBXvAAAMAAAAnDg");
	var mask_graphics_88 = new cjs.Graphics().p("Egv/ATiMAAAgnDMBf/AAAMAAAAnDg");
	var mask_graphics_89 = new cjs.Graphics().p("Egz0ATiMAAAgnDMBnoAAAMAAAAnDg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg3WATiMAAAgnDMButAAAMAAAAnDg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg6nATiMAAAgnDMB1PAAAMAAAAnDg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg9mATiMAAAgnDMB7NAAAMAAAAnDg");
	var mask_graphics_93 = new cjs.Graphics().p("EhASATiMAAAgnDMCAlAAAMAAAAnDg");
	var mask_graphics_94 = new cjs.Graphics().p("EhCsATiMAAAgnDMCFZAAAMAAAAnDg");
	var mask_graphics_95 = new cjs.Graphics().p("EhE1ATiMAAAgnDMCJqAAAMAAAAnDg");
	var mask_graphics_96 = new cjs.Graphics().p("EhGrATiMAAAgnDMCNXAAAMAAAAnDg");
	var mask_graphics_97 = new cjs.Graphics().p("EhIOATiMAAAgnDMCQdAAAMAAAAnDg");
	var mask_graphics_98 = new cjs.Graphics().p("EhJgATiMAAAgnDMCTBAAAMAAAAnDg");
	var mask_graphics_99 = new cjs.Graphics().p("EhKfATiMAAAgnDMCU/AAAMAAAAnDg");
	var mask_graphics_100 = new cjs.Graphics().p("EhLNATiMAAAgnDMCWbAAAMAAAAnDg");
	var mask_graphics_101 = new cjs.Graphics().p("EhLoATiMAAAgnDMCXRAAAMAAAAnDg");
	var mask_graphics_102 = new cjs.Graphics().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:975,y:125}).wait(1).to({graphics:mask_graphics_80,x:933.325,y:125}).wait(1).to({graphics:mask_graphics_81,x:893.5,y:125}).wait(1).to({graphics:mask_graphics_82,x:855.5,y:125}).wait(1).to({graphics:mask_graphics_83,x:819.375,y:125}).wait(1).to({graphics:mask_graphics_84,x:785.1,y:125}).wait(1).to({graphics:mask_graphics_85,x:752.7,y:125}).wait(1).to({graphics:mask_graphics_86,x:722.125,y:125}).wait(1).to({graphics:mask_graphics_87,x:693.425,y:125}).wait(1).to({graphics:mask_graphics_88,x:666.55,y:125}).wait(1).to({graphics:mask_graphics_89,x:641.55,y:125}).wait(1).to({graphics:mask_graphics_90,x:618.375,y:125}).wait(1).to({graphics:mask_graphics_91,x:597.075,y:125}).wait(1).to({graphics:mask_graphics_92,x:577.625,y:125}).wait(1).to({graphics:mask_graphics_93,x:560.05,y:125}).wait(1).to({graphics:mask_graphics_94,x:544.275,y:125}).wait(1).to({graphics:mask_graphics_95,x:530.4,y:125}).wait(1).to({graphics:mask_graphics_96,x:518.35,y:125}).wait(1).to({graphics:mask_graphics_97,x:508.15,y:125}).wait(1).to({graphics:mask_graphics_98,x:499.825,y:125}).wait(1).to({graphics:mask_graphics_99,x:493.325,y:125}).wait(1).to({graphics:mask_graphics_100,x:488.725,y:125}).wait(1).to({graphics:mask_graphics_101,x:485.925,y:125}).wait(1).to({graphics:mask_graphics_102,x:485,y:125}).wait(252));

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(131.1,0.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(275));

	// Btn
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(632.55,119.8,1,1,0,0,0,83,25.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:650.55,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD123
	this.instance_2 = new lib.g_txt03AD123("synched",0);
	this.instance_2.setTransform(129.25,96.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(116));

	// text_02__Ad03
	this.instance_3 = new lib.g_txt02AD3("synched",0);
	this.instance_3.setTransform(-602.95,134,1,1,0,0,0,-66.5,28);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({x:70},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-602.95},21,cjs.Ease.get(1)).to({_off:true},3).wait(147));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	this.shape.setTransform(975,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("AnJTiMAAAgnDIOTAAMAAAAnDg");
	this.shape_1.setTransform(933.325,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AtQTiMAAAgnDIahAAMAAAAnDg");
	this.shape_2.setTransform(893.5,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("AzETiMAAAgnDMAmJAAAMAAAAnDg");
	this.shape_3.setTransform(855.5,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("A4lTiMAAAgnDMAxLAAAMAAAAnDg");
	this.shape_4.setTransform(819.375,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("A91TiMAAAgnDMA7rAAAMAAAAnDg");
	this.shape_5.setTransform(785.1,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("EgizATiMAAAgnDMBFmAAAMAAAAnDg");
	this.shape_6.setTransform(752.7,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("EgneATiMAAAgnDMBO9AAAMAAAAnDg");
	this.shape_7.setTransform(722.125,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("Egr3ATiMAAAgnDMBXvAAAMAAAAnDg");
	this.shape_8.setTransform(693.425,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("Egv/ATiMAAAgnDMBf/AAAMAAAAnDg");
	this.shape_9.setTransform(666.55,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("Egz0ATiMAAAgnDMBnoAAAMAAAAnDg");
	this.shape_10.setTransform(641.55,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("Eg3WATiMAAAgnDMButAAAMAAAAnDg");
	this.shape_11.setTransform(618.375,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("Eg6nATiMAAAgnDMB1PAAAMAAAAnDg");
	this.shape_12.setTransform(597.075,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("Eg9mATiMAAAgnDMB7NAAAMAAAAnDg");
	this.shape_13.setTransform(577.625,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("EhASATiMAAAgnDMCAlAAAMAAAAnDg");
	this.shape_14.setTransform(560.05,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("EhCsATiMAAAgnDMCFZAAAMAAAAnDg");
	this.shape_15.setTransform(544.275,125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("EhE1ATiMAAAgnDMCJqAAAMAAAAnDg");
	this.shape_16.setTransform(530.4,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("EhGrATiMAAAgnDMCNXAAAMAAAAnDg");
	this.shape_17.setTransform(518.35,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("EhIOATiMAAAgnDMCQdAAAMAAAAnDg");
	this.shape_18.setTransform(508.15,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("EhJgATiMAAAgnDMCTBAAAMAAAAnDg");
	this.shape_19.setTransform(499.825,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("EhKfATiMAAAgnDMCU/AAAMAAAAnDg");
	this.shape_20.setTransform(493.325,125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("EhLNATiMAAAgnDMCWbAAAMAAAAnDg");
	this.shape_21.setTransform(488.725,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("EhLoATiMAAAgnDMCXRAAAMAAAAnDg");
	this.shape_22.setTransform(485.925,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_23.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},79).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(252));

	// Text_01___AD3
	this.instance_4 = new lib.g_txt01AD3("synched",0);
	this.instance_4.setTransform(-359.2,95.65,1,1,0,0,0,-66.5,28);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({_off:false},0).to({x:-69.45},21,cjs.Ease.get(1)).to({_off:true},72).wait(250));

	// Photo_AD3
	this.instance_5 = new lib.gpic3("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,974,254);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},86).wait(250));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(250));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:18, x:-2, y:-2, w:974, h:254});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:974, h:254});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(195.6,125,784.4,125);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 970,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;