(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,318,90]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Pic5 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD456 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("APVBWQAAgQAPgGIAAgBQgOgFAAgPQAAgUARgDQgMgLABgSQAAgSAIgLQAMgQAaAAIAKABIAqAAIAAALIgUABQAKAMAAASQAAAQgJAMQgNANgXAAIgaAAQgJAAAAAIQAAAGAJABIAuAAQAkgBAAAfQAAAQgMAKQgPAOggAAQgvAAAAgdgAPmBRQAAAWAhAAQAVAAAKgJQAHgGAAgJQAAgOgRgBIgtAAQgJAHAAAKgAP2ghQgFAIAAAMQAAAiAXgBQAOAAAFgLQAEgHgBgPQAAgNgEgIQgHgJgLAAQgMAAgGAKgAKRBWQAAgQAPgGIAAgBQgOgFgBgPQAAgUARgDQgLgLAAgSQAAgSAJgLQAMgQAZAAIALABIAqAAIAAALIgVABQALAMAAASQAAAQgKAMQgMANgYAAIgaAAQgJAAAAAIQAAAGAKABIAuAAQAjgBABAfQgBAQgMAKQgOAOghAAQguAAAAgdgAKiBRQgBAWAiAAQAUAAAKgJQAIgGAAgJQAAgOgRgBIguAAQgIAHAAAKgAKxghQgEAIgBAMQAAAiAXgBQAOAAAGgLQADgHAAgPQAAgNgFgIQgGgJgLAAQgMAAgHAKgAtCBxIAAgLIAOgBIABgBIAAiCQAAgGgDgBIgMgCIAAgJIAggGIACAAIgBARIABAAQAMgRAXAAQAaAAAKATQAJAPAAAcQgBAXgKAQQgNATgYAAQgVAAgJgLIgCAAIAAAtIACABIAPABIAAALgAsgAHQAAAvAcAAQASAAAGgQQAFgKgBgVQAAgXgDgKQgHgQgSAAQgcAAAAAxgAGOAFQAAgYAMgQQANgTAbAAQAyAAAAA7QAAAdgMAOQgMASgcAAQgyAAAAg9gAGpgbQgEALAAAWQAAAxAcAAQASAAAGgSQADgKABgaQgBgsgbAAQgRAAgHAQgADaAJQAAghAQgRQANgNAVAAQAWAAAMANQAMAOAAAYIAAAKIhJAAIAAADQgBAqAjAAQARAAAOgOIAHAGQgGAKgMAHQgMAFgOAAQgzAAAAg5gAElgEQAAgngaAAQgZAAgBAnIA0AAIAAAAgAhIAJQAAghAQgRQANgNAUAAQAXAAAKANQANAOAAAYIAAAKIhJAAIAAADQAAAqAiAAQAQAAAPgOIAGAGQgFAKgNAHQgLAFgOAAQgyAAAAg5gAABgEQAAgngZAAQgYAAgCAnIAzAAIAAAAgAi0AIQAAgeAPgQQAOgQAYAAQAWAAAOAKIAAAcIgIAAQgKgcgVABQgcgBAAAvQAAAcAIANQAHALAQAAQALAAAIgJQAHgIADgOIAIAAIAAAdQgSANgVAAQgzAAAAg6gAmxAJQAAghAQgRQANgNAUAAQAWAAAMANQAMAOAAAYIAAAKIhJAAIAAADQAAAqAiAAQARAAAPgOIAGAGQgFAKgNAHQgMAFgOAAQgyAAAAg5gAlngEQAAgngaAAQgYAAgCAnIA0AAIAAAAgAq+AJQAAghAQgRQANgNAUAAQAXAAALANQANAOAAAYIAAAKIhKAAIAAADQAAAqAiAAQARAAAPgOIAGAGQgFAKgNAHQgMAFgOAAQgyAAAAg5gAp0gEQAAgngaAAQgYAAgCAnIA0AAIAAAAgAB2AwIgBAAIgIAQIgIAAIAAiaQAAgHgDAAIgMgDIAAgIIAggGIADAAIAABMIABAAQAKgQAXAAQAsAAAAA5QABA/gvgBQgXAAgMgRgAB4AFQAAAyAdAAQARgBAGgQQAFgMAAgVQAAgVgFgKQgGgQgRAAQgdAAAAAvgAOSBAIAAgKIAOAAIABgCIAAg8QAAgPgCgFQgFgLgPAAQgOAAgJALQgIAKAAAPIAAA3IACACIAMAAIAAAKIgyAAIAAgKIAOAAIACgCIAAhSQAAgGgDgBIgNgCIAAgJIAggGIADAAIgBAUIABAAQANgUAaAAQAkAAAAAlIAABFIACACIAMAAIAAAKgAMHBAIAAgKIAOAAIACgCIAAhSQAAgHgDAAIgNgDIAAgIIAigGIACAAIAABqIABACIAOAAIAAAKgAJOBAIAAgKIANAAIACgCIAAg8QAAgPgDgFQgEgLgPAAQgPAAgIALQgJAKAAAPIAAA3IACACIANAAIAAAKIgzAAIAAgKIAPAAIABgCIAAhSQAAgGgDgBIgMgCIAAgJIAggGIACAAIgBAUIABAAQANgUAaAAQAlAAAAAlIAABFIABACIANAAIAAAKgAFLBAIAAgKIANAAIADgCIAAiOQAAgHgEAAIgMgDIAAgIIAhgGIADAAIAACmIABACIANAAIAAAKgAj3BAIAAgKIAOAAIABgCIAAg8QABgPgDgFQgFgLgPAAQgOAAgJALQgIAKAAAPIAAA3IABACIAOAAIAAAKIgzAAIAAgKIAOAAIACgCIAAhSQAAgGgDgBIgNgCIAAgJIAhgGIACAAIgBAUIABAAQANgUAZAAQAlAAAAAlIAABFIACACIAMAAIAAAKgAn1BAIAAgKIAPAAIABgCIAAhSQAAgHgDAAIgMgDIAAgIIAhgGIACAAIAABqIACACIANAAIAAAKgApOBAIAAgKIAOAAIACgCIAAhSQAAgGgDgBIgNgCIAAgJIAhgGIACAAIgBAaIABAAQAMgaAbAAQAGAAAGACIgEATQgIgCgHAAQgOgBgJAMQgHAMAAASIAAAuIACACIAMAAIAAAKgAt4BAIAAgKIAMAAIACgCIgZgmIgbAmIACACIANAAIAAAKIgsAAIAAgKIALgBIACgBIAigvIghgtIgCgCIgKgBIAAgKIAvAAIAAAKIgKABIgCACIAWAhIAXghIgBgCIgMgBIAAgKIAsAAIAAAKIgNABIgCACIgfApIAlAzIACABIALABIAAAKgAw+BAIAAgKIAPAAIACgCIAAiMIgCgBIgPgBIAAgKIB2AAIAAAmIgKAAQgEgTgHgFQgEgDgUAAIgiAAIAAA/IAXAAQAQAAAEgFQADgDADgPIAJAAIAAA4IgJAAQgDgOgDgDQgEgFgQAAIgXAAIAABEIAkAAQASAAAGgFQAIgFADgXIAKAAIAAAsgAMYhQQgEgEAAgFQAAgGAEgEQAEgEAFAAQAFAAAEAEQAEAEABAGQgBAFgEAEQgEAEgFAAQgFAAgEgEgAnkhQQgDgEAAgFQAAgGADgEQAEgEAGAAQAFAAAEAEQAEAEAAAGQAAAFgEAEQgEAEgFAAQgGAAgEgEg");
	this.shape.setTransform(111.65,17.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3,6.4,217.4,22.9);


(lib.g_txt02AD5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AriFEIAPgtIgOAAIAAg2IA5AAIAAA2IgSAtgAdiEXIAAkRIB+AAIAAA4IhBAAIAAAyIA9AAIAAA5Ig9AAIAAA1IBCAAIAAA5gAbeEXIgijjIAAguIA4AAIASDEIADAAIARjEIA5AAIAAAuIgiDjgAZZEXIAAg5IALAAIAAigIgLAAIAAg4IBTAAIAAA4IgLAAIAACgIALAAIAAA5gAYYEXIgihrIgGAAIAABrIg+AAIAAkRIB3AAQAeALAAAiIAAA6QAAAhgZALIAgBYIAAAmgAXwB7IAWAAIAEgEIAAg8IgEgEIgWAAgAVjEXIAAhrIgbAAIAABrIg8AAIAAkRIA8AAIAABtIAbAAIAAhtIA8AAIAAERgASYEXIAAjZIgsAAIAAg4ICUAAIAAA4IgsAAIAADZgAOUEXIAAkRIB2AAQAeALgBAiIAAC2QABAjgeALgAPRDmIAWAAIAEgFIAAimIgEgEIgWAAgANMEXIgmh3IgFAAIAAB3Ig1AAIAAkRIA1AAIAnB3IAEAAIAAh3IA1AAIAAERgAKlEXIgFg2IgdAAIgFA2Ig4AAIAAguIAjjjIBSAAIAjDjIAAAugAKbCpIgIhXIgDAAIgIBXIATAAgAGdEXIAAjZIgsAAIAAg4ICUAAIAAA4IgrAAIAADZgADvEXQgegLAAgjIAAi2QAAgiAegLIBZAAQAdALABAiIAABCIg9AAIAAg6IgEgEIgTAAIgEAEIAACmIAEAFIATAAIAEgFIAAg5IA9AAIAABBQgBAjgdALgAA/EXIAAkRIB+AAIAAA4IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBBAAIAAA5gAgIEXIglh3IgFAAIAAB3Ig0AAIAAkRIA0AAIAnB3IADAAIAAh3IA0AAIAAERgAiuEXIgnh3IgDAAIAAB3Ig2AAIAAkRIA2AAIAmB3IAEAAIAAh3IA0AAIAAERgAmXEXQgegLAAgjIAAi2QAAgiAegLIBZAAQAdALABAiIAAC2QgBAjgdALgAl4A7IAACmIAEAFIATAAIAEgFIAAimIgEgEIgTAAgAo+EXQgegLABgjIAAi2QgBgiAegLIBZAAQAdALAAAiIAABCIg8AAIAAg6IgEgEIgTAAIgDAEIAACmIADAFIATAAIAEgFIAAg5IA8AAIAABBQAAAjgdALgAtoEXQgdgLAAgjIAAg2IA9AAIAAAuIADAFIATAAIAEgFIAAgpIgEgGIg+gbQgNgHgFgKQgDgIAAgRIAAg6QAAgiAdgLIBZAAQAeALAAAiIAAAzIg9AAIAAgrIgEgEIgTAAIgDAEIAAAnIAEAHIA+AZQANAFAEAKQAEAJAAARIAAA+QAAAjgeALgAv4EXIAAjZIgrAAIAAg4ICUAAIAAA4IgrAAIAADZgAyjEXQgdgLAAgjIAAg2IA9AAIAAAuIADAFIATAAIAEgFIAAgpIgEgGIg+gbQgNgHgFgKQgDgIAAgRIAAg6QAAgiAdgLIBZAAQAeALAAAiIAAAzIg9AAIAAgrIgEgEIgTAAIgDAEIAAAnIAEAHIA+AZQANAFAEAKQAEAJAAARIAAA+QAAAjgeALgA1QEXIAAkRIB9AAIAAA4IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBCAAIAAA5gA2QEXIgjhrIgHAAIAABrIg9AAIAAkRIB3AAQAdALABAiIAAA6QAAAhgaALIAhBYIAAAmgA26B7IAXAAIAEgEIAAg8IgEgEIgXAAgA6JEXIAAkRIB+AAIAAA4IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBBAAIAAA5gA79EXIAAjZIgrAAIAAg4ICUAAIAAA4IgsAAIAADZgA9pEXIgmh3IgDAAIAAB3Ig1AAIAAkRIA1AAIAmB3IADAAIAAh3IA1AAIAAERgEgguAEXIAAg5IAMAAIAAigIgMAAIAAg4IBUAAIAAA4IgMAAIAACgIAMAAIAAA5gAewgyIAAkSIB+AAIAAA5IhBAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBCAAIAAA5gAdwgyIgihqIgHAAIAABqIg9AAIAAkSIB2AAQAeALAAAjIAAA6QAAAhgZALIAhBXIAAAngAdHjOIAXAAIADgDIAAg+IgDgDIgXAAgAaAgyQgdgLAAgjIAAi2QAAgjAdgLIBaAAQAdALAAAjIAAC2QAAAjgdALgAagkPIAACoIAEADIASAAIAEgDIAAioIgEgDIgSAAgAXbgyIAAkSIA8AAIAADZIA/AAIAAA5gAU3gyIAAkSIB3AAQAdALABAjIAABYQgBAigdALIg6AAIAABfgAV0jDIAXAAIAEgEIAAhIIgEgDIgXAAgATwgyIgRhhIgEAAIgSBhIg4AAIAAguIAdhbIgdhbIAAguIA4AAIASBiIAEAAIARhiIA5AAIAAAuIgdBbIAdBbIAAAugAQCgyIAAkSIB+AAIAAA5IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBBAAIAAA5gANAgyQgdgLgBgjIAAi2QABgjAdgLIBZAAQAeALAAAjIAAC2QAAAjgeALgANfkPIAACoIAEADIATAAIAEgDIAAioIgEgDIgTAAgAKugyIAAjZIgrAAIAAg5ICUAAIAAA5IgsAAIAADZgAHKgyQgdgLAAgjIAAg2IA8AAIAAAvIAEADIATAAIAEgDIAAgqIgEgGIg+gcQgNgFgFgLQgDgIAAgRIAAg6QAAgjAdgLIBZAAQAeALAAAjIAAAzIg9AAIAAgsIgEgDIgTAAIgEADIAAAoIAFAGIA+AaQANAEAEAMQAEAIAAARIAAA+QAAAjgeALgAEHgyIAAkSIB3AAQAdALABAjIAAApQAAAigfALQAfALAAAjIAAAyQgBAjgdALgAFEhgIAXAAIAEgEIAAg8IgEgEIgXAAgAFEjRIAXAAIAEgFIAAg8IgEgEIgXAAgACCgyQgdgLgBgjIAAjkIA9AAIAADdIAEADIAPAAIAEgDIAAjdIA9AAIAADkQAAAjgdALgAgjgyIAAkSIA8AAIAADZIA/AAIAAA5gAisgyQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAABCIg9AAIAAg7IgDgDIgTAAIgEADIAACoIAEADIATAAIADgDIAAg6IA9AAIAABBQAAAjgdALgAl3gyIAAjZIgsAAIAAg5ICVAAIAAA5IgsAAIAADZgAnjgyIgmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAnB4IADAAIAAh4IA1AAIAAESgArUgyIAAkSIB9AAIAAA5IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBCAAIAAA5gAt7gyIAAkSIB2AAQAeALAAAjIAAC2QAAAjgeALgAs+hkIAWAAIAFgDIAAioIgFgDIgWAAgAwBgyQgdgLAAgjIAAjkIA9AAIAADdIAEADIAPAAIADgDIAAjdIA+AAIAADkQgBAjgdALgAySgyIAAjZIgsAAIAAg5ICVAAIAAA5IgsAAIAADZgA09gyQgegLAAgjIAAg2IA9AAIAAAvIAEADIATAAIADgDIAAgqIgDgGIg+gcQgOgFgEgLQgEgIAAgRIAAg6QAAgjAegLIBZAAQAdALAAAjIAAAzIg9AAIAAgsIgDgDIgTAAIgEADIAAAoIAFAGIA9AaQANAEAFAMQADAIAAARIAAA+QAAAjgdALgA7CgyQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAAC2QAAAjgdALgA6jkPIAACoIAEADIATAAIADgDIAAioIgDgDIgTAAgA9qgyQgdgLAAgjIAAglIA9AAIAAAeIAEADIASAAIAFgDIAAg7IgFgEIgiAAIAAgtIAiAAIAFgFIAAg3IgFgDIgSAAIgEADIAAAeIg9AAIAAglQAAgjAdgLIBZAAQAeALAAAjIAAAvQAAAegVAMQAVANAAAdIAAAzQAAAjgeALgEggugAyIAAhcQAAgfAWgKIBBgeIAAg6IgDgDIgUAAIgDADIAAAoIg9AAIAAgvQAAgjAegLIBYAAQAeALAAAjIAABFQAAARgEAJQgEAKgNAGIhCAeIAAAeIBXAAIAAA5gA4EhkIAAg1IgxAAIAAgqIAxAAIAAg0IAqAAIAAA0IAxAAIAAAqIgxAAIAAA1g");
	this.shape.setTransform(212.45,37.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EghyAFpIAAnPIABAAIAAkDMBDkAAAIAAGEIhUAAIAAFOg");
	this.shape_1.setTransform(212.825,34.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.5,-1.2,432.7,72.3);


(lib.g_txt01AD45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AZ4DRIAAmhIDAAAIAABXIhiAAIAABRIBcAAIAABWIhcAAIAACjgAWoDRIAAmhIBdAAIAAFKIBfAAIAABXgATJDRIAAmhIDAAAIAABXIhjAAIAABMIBcAAIAABWIhcAAIAABRIBlAAIAABXgAP7DRQgugRAAg1IAAhSIBdAAIAABGIAFAGIAeAAIAFgGIAAg/IgEgIIhhgrQgTgJgHgPQgGgNAAgaIAAhYQAAg1AugRICHAAQAtARABA1IAABOIheAAIAAhDIgFgFIgeAAIgFAFIAAA9IAIAKIBdAlQATAIAHAQQAGANABAaIAABfQgBA1gtARgANuDRIg2ijIgJAAIAACjIhdAAIAAmhIC1AAQAtARAAA1IAABZQAAAxgnARIAyCFIAAA7gAMvgcIAjAAIAFgGIAAhdIgFgFIgjAAgAIGDRQgtgRAAg1IAAlbIBdAAIAAFPIAGAGIAWAAIAGgGIAAlPIBdAAIAAFbQAAA1gtARgAEIDRQgugRAAg1IAAkVQAAg1AugRICHAAQAtARAAA1IAAEVQAAA1gtARgAE3h/IAAD+IAGAGIAdAAIAFgGIAAj+IgFgFIgdAAgAAgDRIAAilIhEi2IAAhGIBWAAIAbCPIAFAAIAaiPIBXAAIAABGIhGC2IAAClgAkmDRIAAlKIhDAAIAAhXIDiAAIAABXIhCAAIAAFKgAovDRQgtgRAAg1IAAkVQAAg1AtgRICIAAQAtARAAA1IAABlIhdAAIAAhaIgGgFIgdAAIgFAFIAAD+IAFAGIAdAAIAGgGIAAhYIBdAAIAABkQAAA1gtARgAs7DRIAAmhIDAAAIAABXIhjAAIAABMIBcAAIAABWIhcAAIAABRIBlAAIAABXgAupDRIg6i2IgGAAIAAC2IhRAAIAAmhIBRAAIA7C2IAFAAIAAi2IBRAAIAAGhgAyoDRIg6i2IgGAAIAAC2IhRAAIAAmhIBRAAIA6C2IAGAAIAAi2IBRAAIAAGhgA4LDRQgtgRAAg1IAAkVQAAg1AtgRICIAAQAtARAAA1IAAEVQAAA1gtARgA3bh/IAAD+IAFAGIAeAAIAFgGIAAj+IgFgFIgeAAgA8KDRQgtgRAAg1IAAkVQAAg1AtgRICIAAQAtARAAA1IAABlIhcAAIAAhaIgHgFIgdAAIgFAFIAAD+IAFAGIAdAAIAHgGIAAhYIBcAAIAABkQAAA1gtARg");
	this.shape.setTransform(-188.2,27.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-373,6.7,369.6,41.699999999999996);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(72.8903,36.9128,1.5385,1.5402);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(52.0052,26.0157,1.5385,1.5402);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,104,52.1);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("ABAC+IAAj+Ij9AAIAAh9IF7AAIAAF7g");
	this.shape.setTransform(19,19);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38,38);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgXA5QgKgFgHgJQgFgKAAgNIAAhQIABgCIABAAIAVAAIABAAIABACIAABQQAAAKAGAFQAGAGAIABQAKgBAFgGQAGgFAAgKIAAhQIAAgCIACAAIAVAAIACAAIAAACIAABQQAAANgGAKQgFAKgLAEQgKAGgOAAQgNAAgKgGg");
	this.shape.setTransform(168.5,21.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIACAAIAAACIAAARIAAACIgCAAIg5AAIgBABIAAAcIABABIAlAAIABAAIACACIAAAQIgCABIgBABIglAAIgBABIAAAxIAAACIgCAAg");
	this.shape_1.setTransform(158.35,21.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgXA7QgLgEgGgJQgFgIAAgMIAAgDIAAgCIACgBIAUAAIACABIAAACIAAACQAAAHAHAFQAGAFALAAQAJAAAFgEQAEgEAAgGQAAgEgDgDQgCgDgFgCIgPgGQgMgEgIgFQgIgDgGgHQgGgIAAgKQAAgLAGgIQAFgIAKgFQAKgEANAAQAMAAALAFQALAFAGAIQAFAJAAALIAAADIAAACIgCAAIgUAAIgCAAIAAgCIAAgBQAAgIgGgFQgHgFgJAAQgJAAgEADQgFAEAAAGQAAAFADADQACADAGACIAQAHIAUAIQAHACAGAHQAFAHAAAMQAAAQgMAKQgMAKgVAAQgNAAgLgFg");
	this.shape_2.setTransform(147.675,21.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgYA6QgKgFgGgLQgGgKAAgNIAAgmQAAgMAGgKQAGgLAKgGQALgFANAAQAOAAALAFQAKAGAGALQAGAKAAAMIAAAmQAAANgGAKQgGALgKAFQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAAKIAAAnQAAAKAGAGQAGAGAJAAQAKAAAGgGQAGgGAAgKIAAgnQAAgKgGgGQgGgGgKAAQgJAAgGAGg");
	this.shape_3.setTransform(133.325,21.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIAAACIgCAAg");
	this.shape_4.setTransform(122.6,21.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIgBACIgBAAg");
	this.shape_5.setTransform(108.65,21.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgXA6QgLgFgGgKQgFgKAAgNIAAgoQAAgNAFgJQAGgKALgFQALgGAMAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACABIAAABQAAAMgFAKQgHAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_6.setTransform(98.1,21.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIABAAIABACIAAARIgBACIgBAAIg5AAIgBABIAAAcIABABIAlAAIABAAIABACIAAAQIgBABIgBABIglAAIgBABIAAAdIABABIA5AAIABAAIABACIAAARIgBACIgBAAg");
	this.shape_7.setTransform(87.725,21.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_8.setTransform(76.425,21.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAgBAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_9.setTransform(64.625,21.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgYA6QgKgFgGgLQgGgKAAgNIAAgmQAAgMAGgKQAGgLAKgGQALgFANAAQAOAAALAFQAKAGAGALQAGAKAAAMIAAAmQAAANgGAKQgGALgKAFQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAAKIAAAnQAAAKAGAGQAGAGAJAAQAKAAAGgGQAGgGAAgKIAAgnQAAgKgGgGQgGgGgKAAQgJAAgGAGg");
	this.shape_10.setTransform(53.175,21.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgXA6QgLgFgFgKQgGgKAAgNIAAgoQAAgNAGgJQAFgKALgFQALgGAMAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACABIAAABQAAAMgGAKQgGAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_11.setTransform(42.3,21.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AhFBiIBghiIhghhIAVgVIB2B2Ih2B3g");
	this.shape_12.setTransform(20.45,20.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_13.setTransform(20.45,20.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AD/A6QgLgFgGgLQgFgKgBgNIAAgmQABgMAFgKQAGgLALgGQALgFANAAQAOAAALAFQALAGAFALQAGAKAAAMIAAAmQAAANgGAKQgFALgLAFQgLAGgOAAQgNAAgLgGgAEIgjQgHAGAAAKIAAAnQAAAKAHAGQAFAGAKAAQAKAAAGgGQAGgGAAgKIAAgnQAAgKgGgGQgGgGgKAAQgKAAgFAGgAoiA6QgKgFgGgLQgGgKAAgNIAAgmQAAgMAGgKQAGgLAKgGQALgFAOAAQAOAAAKAFQALAGAGALQAFAKABAMIAAAmQgBANgFAKQgGALgLAFQgKAGgOAAQgOAAgLgGgAoZgjQgGAGAAAKIAAAnQAAAKAGAGQAGAGAKAAQAJAAAGgGQAHgGgBgKIAAgnQABgKgHgGQgGgGgJAAQgKAAgGAGgAJfA6QgKgGgHgJQgFgJAAgNIAAhQIABgCIABAAIAVAAIABAAIABACIAABQQAAAKAGAFQAGAGAJAAQAKAAAFgGQAGgFAAgKIAAhQIAAgCIACAAIAVAAIACAAIAAACIAABQQAAANgGAJQgFAKgLAFQgKAGgOAAQgOAAgKgGgAGPA7QgLgFgGgIQgGgJAAgLIAAgDIABgCIACgBIAUAAIABABIABACIAAACQAAAHAHAFQAGAFAMAAQAJAAAEgEQAFgEAAgGQAAgEgDgDQgDgDgEgDIgQgFQgMgFgIgEQgJgDgFgIQgGgHAAgLQAAgKAFgJQAGgHAKgFQAKgEAMAAQAOAAAKAFQAMAFAFAIQAGAJAAALIAAADIAAABIgCABIgVAAIgBgBIAAgBIAAgBQAAgIgHgGQgGgEgLAAQgIgBgEAEQgFADAAAHQAAAEADADQACADAGADIAQAGIAVAIQAHADAFAHQAGAHAAAMQAAAQgMAJQgNALgUAAQgOAAgLgFgAhgA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgJQAGgLALgFQALgFANAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIgVABQAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAgJgGgGQgFgGgKABQgJgBgGAGQgGAGAAAJIAAAqQAAAKAGAFQAGAGAJAAQAKAAAFgGQAGgFAAgKQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIAVABIACABIAAABQAAAMgFAJQgHAKgKAFQgKAFgOABQgNAAgLgGgAqOA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgJQAGgLALgFQALgFANAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIgVABQAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAgJgGgGQgFgGgKABQgJgBgGAGQgGAGAAAJIAAAqQAAAKAGAFQAGAGAJAAQAKAAAFgGQAGgFAAgKQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIAVABIACABIAAABQAAAMgGAJQgGAKgKAFQgKAFgOABQgNAAgLgGgAHpA+IgCgBIAAgBIAAh3IAAgCIACAAIBRAAIACAAIAAACIAAARIAAACIgCAAIg5AAIgCABIAAAbIACABIAmAAIABABIABABIAAAQIgBACIgBABIgmAAIgCABIAAAxIAAABIgCABgAChA+IgCgBIAAgBIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBaAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIgBABIgBABgAAVA+IgBgBIAAgBIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIgfAAIgBABIAABjIgBABIgCABgAjZA+IgCgBIAAgBIAAh3IAAgCIACAAIBTAAIABAAIABACIAAARIgBACIgBAAIg7AAIgBABIAAAbIABABIAmAAIABABIACABIAAAQIgCACIgBABIgmAAIgBABIAAAdIABAAIA7AAIABABIABABIAAASIgBABIgBABgAkHA+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBIgthKIgBgBIAAABIAABKIAAABIgCABIgVAAIgCgBIAAgBIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBKIAAABIAAgBIAAhJIABgCIABAAIAWAAIABAAIABACIAAB3IgBABIgBABgAl9A+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIguhKIgBgBIAAABIAABKIAAABIgCABIgVAAIgCgBIAAgBIAAh3IAAgCIACAAIAUAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBKIAAABIABgBIAAhJIAAgCIABAAIAVAAIACAAIABACIAAB3IgBABIgCABg");
	this.shape_14.setTransform(105.4,21.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AueDNIAAmZIc9AAIAAGZg");
	this.shape_15.setTransform(92.7,20.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AOfDNI89AAIAAmZIc9AAg");
	this.shape_16.setTransform(92.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,187.4,43);


(lib.gpic5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(522.9,26,1,1,89.9948,0,0,26,26.1);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(614.9,63.9,1,1,-89.9948,0,0,26.1,25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BE272E").s().p("EggBAHCIAAuDMBADAAAIAAODg");
	this.shape.setTransform(205,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Photo
	this.instance_2 = new lib.Pic5();
	this.instance_2.setTransform(410,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


// stage content:
(lib.banner_728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("AgxHCIAAuDIBjAAIAAODg");
	var mask_graphics_80 = new cjs.Graphics().p("AliHCIAAuDILFAAIAAODg");
	var mask_graphics_81 = new cjs.Graphics().p("AqGHCIAAuDIUNAAIAAODg");
	var mask_graphics_82 = new cjs.Graphics().p("AucHCIAAuDIc5AAIAAODg");
	var mask_graphics_83 = new cjs.Graphics().p("AylHCIAAuDMAlLAAAIAAODg");
	var mask_graphics_84 = new cjs.Graphics().p("A2gHCIAAuDMAtBAAAIAAODg");
	var mask_graphics_85 = new cjs.Graphics().p("A6OHCIAAuDMA0cAAAIAAODg");
	var mask_graphics_86 = new cjs.Graphics().p("A9uHCIAAuDMA7dAAAIAAODg");
	var mask_graphics_87 = new cjs.Graphics().p("EghAAHCIAAuDMBCBAAAIAAODg");
	var mask_graphics_88 = new cjs.Graphics().p("EgkFAHCIAAuDMBILAAAIAAODg");
	var mask_graphics_89 = new cjs.Graphics().p("Egm8AHCIAAuDMBN5AAAIAAODg");
	var mask_graphics_90 = new cjs.Graphics().p("EgpmAHCIAAuDMBTNAAAIAAODg");
	var mask_graphics_91 = new cjs.Graphics().p("EgsCAHCIAAuDMBYFAAAIAAODg");
	var mask_graphics_92 = new cjs.Graphics().p("EguQAHCIAAuDMBchAAAIAAODg");
	var mask_graphics_93 = new cjs.Graphics().p("EgwSAHCIAAuDMBgkAAAIAAODg");
	var mask_graphics_94 = new cjs.Graphics().p("EgyEAHCIAAuDMBkJAAAIAAODg");
	var mask_graphics_95 = new cjs.Graphics().p("EgzrAHCIAAuDMBnWAAAIAAODg");
	var mask_graphics_96 = new cjs.Graphics().p("Eg1DAHCIAAuDMBqHAAAIAAODg");
	var mask_graphics_97 = new cjs.Graphics().p("Eg2NAHCIAAuDMBsbAAAIAAODg");
	var mask_graphics_98 = new cjs.Graphics().p("Eg3LAHCIAAuDMBuWAAAIAAODg");
	var mask_graphics_99 = new cjs.Graphics().p("Eg36AHCIAAuDMBv1AAAIAAODg");
	var mask_graphics_100 = new cjs.Graphics().p("Eg4cAHCIAAuDMBw5AAAIAAODg");
	var mask_graphics_101 = new cjs.Graphics().p("Eg4wAHCIAAuDMBxhAAAIAAODg");
	var mask_graphics_102 = new cjs.Graphics().p("Eg43AHCIAAuDMBxvAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:733,y:45}).wait(1).to({graphics:mask_graphics_80,x:701.625,y:45}).wait(1).to({graphics:mask_graphics_81,x:671.625,y:45}).wait(1).to({graphics:mask_graphics_82,x:643.025,y:45}).wait(1).to({graphics:mask_graphics_83,x:615.8,y:45}).wait(1).to({graphics:mask_graphics_84,x:590,y:45}).wait(1).to({graphics:mask_graphics_85,x:565.6,y:45}).wait(1).to({graphics:mask_graphics_86,x:542.575,y:45}).wait(1).to({graphics:mask_graphics_87,x:520.95,y:45}).wait(1).to({graphics:mask_graphics_88,x:500.7,y:45}).wait(1).to({graphics:mask_graphics_89,x:481.9,y:45}).wait(1).to({graphics:mask_graphics_90,x:464.425,y:45}).wait(1).to({graphics:mask_graphics_91,x:448.4,y:45}).wait(1).to({graphics:mask_graphics_92,x:433.75,y:45}).wait(1).to({graphics:mask_graphics_93,x:420.5,y:45}).wait(1).to({graphics:mask_graphics_94,x:408.65,y:45}).wait(1).to({graphics:mask_graphics_95,x:398.2,y:45}).wait(1).to({graphics:mask_graphics_96,x:389.125,y:45}).wait(1).to({graphics:mask_graphics_97,x:381.425,y:45}).wait(1).to({graphics:mask_graphics_98,x:375.15,y:45}).wait(1).to({graphics:mask_graphics_99,x:370.275,y:45}).wait(1).to({graphics:mask_graphics_100,x:366.8,y:45}).wait(1).to({graphics:mask_graphics_101,x:364.7,y:45}).wait(1).to({graphics:mask_graphics_102,x:364,y:45}).wait(252));

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(0.1,16.85,0.7692,0.7685,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(275));

	// Btn
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(503.55,49.3,1,1,0,0,0,83,25.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:513.55,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD456
	this.instance_2 = new lib.g_txt03AD456("synched",0);
	this.instance_2.setTransform(163.75,30.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(116));

	// text_02__Ad05
	this.instance_3 = new lib.g_txt02AD5("synched",0);
	this.instance_3.setTransform(-497.3,37.4,1,1,0,0,0,-66.5,28);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({x:64.5,y:38},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-497.3,y:37.4},21,cjs.Ease.get(1)).to({_off:true},3).wait(147));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AgxHCIAAuDIBjAAIAAODg");
	this.shape.setTransform(733,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("AliHCIAAuDILFAAIAAODg");
	this.shape_1.setTransform(701.625,45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("AqGHCIAAuDIUNAAIAAODg");
	this.shape_2.setTransform(671.625,45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("AucHCIAAuDIc5AAIAAODg");
	this.shape_3.setTransform(643.025,45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("AylHCIAAuDMAlLAAAIAAODg");
	this.shape_4.setTransform(615.8,45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("A2gHCIAAuDMAtBAAAIAAODg");
	this.shape_5.setTransform(590,45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("A6OHCIAAuDMA0cAAAIAAODg");
	this.shape_6.setTransform(565.6,45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("A9uHCIAAuDMA7dAAAIAAODg");
	this.shape_7.setTransform(542.575,45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("EghAAHCIAAuDMBCBAAAIAAODg");
	this.shape_8.setTransform(520.95,45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("EgkFAHCIAAuDMBILAAAIAAODg");
	this.shape_9.setTransform(500.7,45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("Egm8AHCIAAuDMBN5AAAIAAODg");
	this.shape_10.setTransform(481.9,45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("EgpmAHCIAAuDMBTNAAAIAAODg");
	this.shape_11.setTransform(464.425,45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("EgsCAHCIAAuDMBYFAAAIAAODg");
	this.shape_12.setTransform(448.4,45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("EguQAHCIAAuDMBchAAAIAAODg");
	this.shape_13.setTransform(433.75,45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("EgwSAHCIAAuDMBgkAAAIAAODg");
	this.shape_14.setTransform(420.5,45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("EgyEAHCIAAuDMBkJAAAIAAODg");
	this.shape_15.setTransform(408.65,45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("EgzrAHCIAAuDMBnWAAAIAAODg");
	this.shape_16.setTransform(398.2,45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("Eg1DAHCIAAuDMBqHAAAIAAODg");
	this.shape_17.setTransform(389.125,45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("Eg2NAHCIAAuDMBsbAAAIAAODg");
	this.shape_18.setTransform(381.425,45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("Eg3LAHCIAAuDMBuWAAAIAAODg");
	this.shape_19.setTransform(375.15,45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("Eg36AHCIAAuDMBv1AAAIAAODg");
	this.shape_20.setTransform(370.275,45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("Eg4cAHCIAAuDMBw5AAAIAAODg");
	this.shape_21.setTransform(366.8,45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("Eg4wAHCIAAuDMBxhAAAIAAODg");
	this.shape_22.setTransform(364.7,45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_23.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},79).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(252));

	// Red (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EggBAHCIAAuDMBADAAAIAAODg");
	mask_1.setTransform(205,45);

	// Text_01___AD5
	this.instance_4 = new lib.g_txt01AD45("synched",0);
	this.instance_4.setTransform(717.45,56.75,1,1,0,0,0,-66.5,28);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({_off:false},0).to({x:333.5},21,cjs.Ease.get(1)).to({_off:true},72).wait(250));

	// Photo_AD5
	this.instance_5 = new lib.gpic5("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,732,94);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},86).wait(250));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(250));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:18, x:-2, y:-2, w:732, h:94});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:732, h:94});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,374,45);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;