(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,320,480]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Pic5 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.g_txt03AD456 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BEQAAgUASgIIAAgBQgRgGAAgSQAAgWAUgEQgNgMAAgYQAAgVAKgNQAOgTAeAAIAMABIAyAAIAAANIgYABQAMAOAAAWQAAAUgMAOQgOAQgbAAIgHgBIgYAAQgLAAAAAKQAAAIALAAIA2AAQArAAAAAkQAAATgOAMQgSAQglAAQg4AAAAghgAgqA+QAAAaAnAAQAYAAAMgLQAJgHAAgLQAAgSgUAAIg2AAQgKAIAAANgAgXhMQgGAKAAAPQAAApAbAAQAQAAAGgOQAEgJAAgSQAAgPgGgLQgHgLgNABQgOgBgHAMg");
	this.shape.setTransform(256.725,24.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOBHIAAgMIARAAIACgDIAAhHQAAgSgEgGQgFgNgTAAQgPAAgKANQgKAMAAASIAABBIACADIAPAAIAAAMIg8AAIAAgMIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAngIIADAAIgCAZIABAAQAPgYAeAAQAsAAAAArIAABTIACADIAPAAIAAAMg");
	this.shape_1.setTransform(240.975,21.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBlIAAgNIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAmgIIAEAAIAAB/IACADIAPAAIAAANgAgJhIQgFgFAAgHQAAgGAFgFQAEgFAGAAQAHAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgHAAQgGAAgEgFg");
	this.shape_2.setTransform(228.825,18.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BEQAAgUASgIIAAgBQgRgGAAgSQAAgWAUgEQgNgMAAgYQAAgVAKgNQAOgTAeAAIAMABIAyAAIAAANIgYABQAMAOAAAWQAAAUgMAOQgOAQgbAAIgHgBIgYAAQgLAAAAAKQAAAIALAAIA2AAQArAAAAAkQAAATgOAMQgSAQglAAQg4AAAAghgAgqA+QAAAaAnAAQAYAAAMgLQAJgHAAgLQAAgSgUAAIg2AAQgKAIAAANgAgXhMQgGAKAAAPQAAApAbAAQAQAAAGgOQAEgJAAgSQAAgPgGgLQgHgLgNABQgOgBgHAMg");
	this.shape_3.setTransform(217.925,24.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBHIAAgMIARAAIACgDIAAhHQAAgSgEgGQgFgNgTAAQgPAAgKANQgKAMAAASIAABBIACADIAPAAIAAAMIg8AAIAAgMIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAngIIADAAIgCAZIABAAQAPgYAeAAQAsAAAAArIAABTIACADIAPAAIAAAMg");
	this.shape_4.setTransform(202.175,21.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7AAQgBgdAOgUQARgWAfAAQA7AAgBBHQABAigNARQgQAVggAAQg8AAABhIgAgbgnQgGAOABAaQgBA6AiAAQAVABAHgWQAFgNgBgdQAAg2ghAAQgTAAgIATg");
	this.shape_5.setTransform(186.75,21.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdBrIAAgNIARAAIACgDIAAipQAAgIgFgBIgOgCIAAgKIAmgHIAEAAIAADFIACADIAPAAIAAANg");
	this.shape_6.setTransform(175.675,17.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhWAAIAAADQgBAzAnAAQAVAAASgQIAIAHQgIAMgOAIQgPAGgQABQg7AAAAhFgAAggMQAAguggAAQgcAAgBAuIA9AAIAAAAg");
	this.shape_7.setTransform(164.95,21.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgcBXIgBAAIgKATIgJAAIAAi4QAAgIgFgBIgOgDIAAgKIAngGIADAAIAABaIAAAAQAOgUAaAAQA1AAAABFQAABLg3gBQgcAAgNgUgAgaAjQAAA7AhAAQAVAAAHgTQAGgOAAgaQAAgagGgMQgHgSgVAAQghAAAAA4g");
	this.shape_8.setTransform(150.225,18);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAPAQQAOAQAAAeIAAALIhWAAIAAADQAAAzAmAAQAVAAASgQIAIAHQgIAMgOAIQgPAGgRABQg6AAAAhFgAAggMQgBgugfAAQgcAAgBAuIA9AAIAAAAg");
	this.shape_9.setTransform(130.1,21.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag1ACQAAgjARgUQAQgSAdAAQAaAAAQALIAAAiIgJAAQgLghgaAAQgfAAgBA5QAAAgAKAPQAJAOARAAQANAAAKgKQAJgKADgRIAKAAIAAAiQgWAQgaAAQg7AAAAhGg");
	this.shape_10.setTransform(116.9,21.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAOBHIAAgMIARAAIACgDIAAhHQAAgSgEgGQgFgNgTAAQgPAAgKANQgKAMAAASIAABBIACADIAPAAIAAAMIg8AAIAAgMIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAngIIADAAIgCAZIABAAQAPgYAeAAQAsAAAAArIAABTIACADIAPAAIAAAMg");
	this.shape_11.setTransform(102.075,21.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhXAAIAAADQABAzAnAAQAUAAASgQIAIAHQgHAMgQAIQgOAGgQABQg7AAAAhFgAAfgMQAAgugeAAQgdAAgBAuIA8AAIAAAAg");
	this.shape_12.setTransform(86.95,21.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdBlIAAgNIARAAIACgDIAAhhQAAgIgFgBIgOgDIAAgKIAmgIIAEAAIAAB/IACADIAPAAIAAANgAgJhIQgFgFAAgHQAAgGAFgFQAEgFAGAAQAHAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgHAAQgGAAgEgFg");
	this.shape_13.setTransform(76.225,18.575);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgzBHIAAgMIARAAIAEgDIAAhhQAAgIgFgBIgPgDIAAgKIAngIIADAAIgCAgIABAAQAOgfAfAAQAIAAAIACIgGAXQgIgDgKAAQgQAAgKAOQgIAOAAAWIAAA2IABADIAPAAIAAAMg");
	this.shape_14.setTransform(67.625,21.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag4AEQAAgnATgVQAPgQAXAAQAbAAAOAQQAPAQAAAeIAAALIhWAAIAAADQgBAzAnAAQAVAAASgQIAIAHQgHAMgQAIQgOAGgQABQg7AAAAhFgAAggMQAAguggAAQgcAAgBAuIA9AAIAAAAg");
	this.shape_15.setTransform(54.8,21.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhCBkIAAgMIAQgBIACgDIAAiaQAAgHgFgCIgOgDIAAgKIAmgHIADAAIgCAUIABAAQAPgUAaAAQAfAAANAWQAKASAAAjQAAAbgOATQgPAWgcAAQgXAAgMgNIgBAAIAAA1IACADIARABIAAAMgAgagZQAAA3AhAAQAVAAAHgSQAGgMAAgaQAAgcgGgNQgHgSgVAAQghAAAAA8g");
	this.shape_16.setTransform(40.075,24.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AALBHIAAgNIAOgBIACgCIgegsIgeAsIABACIAQABIAAANIg1AAIAAgNIAOgBIADgCIAog3Igng2IgEgCIgMgBIAAgNIA6AAIAAANIgNAAIgCADIAaAnIAbgnIgCgDIgOAAIAAgNIA1AAIAAANIgQABIgDACIgkAxIAsA8IADACIAMABIAAANg");
	this.shape_17.setTransform(25.75,21.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhHBjIAAgMIATgBIACgDIAAimIgCgCIgTgBIAAgMICMAAIAAAuIgLAAQgGgXgHgFQgHgEgVAAIgqAAIAABLIAbAAQAUAAAFgFQADgEAEgTIALAAIAABEIgLAAQgDgTgFgEQgFgFgTAAIgbAAIAABSIArAAQAWAAAHgFQAJgHAEgbIAMAAIAAA1g");
	this.shape_18.setTransform(10.3,18.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,7.3,259.90000000000003,27.3);


(lib.g_txt02AD5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAJ4IAAkSIB+AAIAAA5IhBAAIAAAyIA9AAIAAA5Ig9AAIAAA1IBCAAIAAA5gAiDJ4IgijkIAAguIA4AAIASDFIADAAIASjFIA4AAIAAAuIgiDkgAkIJ4IAAg5IALAAIAAigIgLAAIAAg5IBTAAIAAA5IgLAAIAACgIALAAIAAA5gAlIJ4IgjhrIgGAAIAABrIg9AAIAAkSIB2AAQAeALAAAjIAAA6QAAAhgZALIAgBXIAAAngAlxHcIAWAAIAEgEIAAg9IgEgDIgWAAgAn+J4IAAhrIgaAAIAABrIg9AAIAAkSIA9AAIAABuIAaAAIAAhuIA9AAIAAESgArJJ4IAAjZIgsAAIAAg5ICUAAIAAA5IgrAAIAADZgAvNJ4IAAkSIB2AAQAeALAAAjIAAC2QAAAjgeALgAuQJGIAWAAIAEgEIAAinIgEgDIgWAAgAwVJ4Igmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAmB4IAEAAIAAh4IA1AAIAAESgAy8J4IgFg2IgdAAIgEA2Ig5AAIAAguIAjjkIBSAAIAjDkIAAAugAzFIKIgIhXIgEAAIgIBXIAUAAgAAzFbIAPgtIgNAAIAAg2IA5AAIAAA2IgSAtgASzEuIAAjZIgrAAIAAg5ICUAAIAAA5IgsAAIAADZgAQGEuQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAABCIg8AAIAAg7IgEgDIgTAAIgEADIAACnIAEAEIATAAIAEgEIAAg5IA8AAIAABBQAAAjgdALgANWEuIAAkSIB+AAIAAA5IhBAAIAAAyIA9AAIAAA5Ig9AAIAAA1IBCAAIAAA5gAMOEuIgmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAnB4IADAAIAAh4IA1AAIAAESgAJnEuIgmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAnB4IADAAIAAh4IA1AAIAAESgAF/EuQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAAC2QAAAjgdALgAGeBRIAACnIAEAEIATAAIAEgEIAAinIgEgDIgTAAgADYEuQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAABCIg8AAIAAg7IgEgDIgTAAIgEADIAACnIAEAEIATAAIAEgEIAAg5IA8AAIAABBQAAAjgdALgAhREuQgegLAAgjIAAg2IA9AAIAAAuIAEAEIATAAIAEgEIAAgpIgEgGIg+gcQgNgGgFgKQgEgIAAgRIAAg6QAAgjAegLIBYAAQAeALAAAjIAAAzIg8AAIAAgsIgEgDIgTAAIgEADIAAAoIAFAGIA8AZQANAFAFALQAEAJAAARIAAA+QAAAjgeALgAjhEuIAAjZIgrAAIAAg5ICUAAIAAA5IgsAAIAADZgAmMEuQgegLAAgjIAAg2IA9AAIAAAuIAEAEIATAAIAEgEIAAgpIgEgGIg+gcQgNgGgFgKQgEgIAAgRIAAg6QAAgjAegLIBZAAQAeALAAAjIAAAzIg9AAIAAgsIgEgDIgTAAIgEADIAAAoIAFAGIA9AZQANAFAFALQAEAJAAARIAAA+QAAAjgeALgAo6EuIAAkSIB+AAIAAA5IhBAAIAAAyIA9AAIAAA5Ig9AAIAAA1IBCAAIAAA5gAp6EuIgihrIgHAAIAABrIg9AAIAAkSIB3AAQAdALAAAjIAAA6QAAAhgZALIAhBXIAAAngAqjCSIAXAAIAEgEIAAg9IgEgDIgXAAgAtyEuIAAkSIB+AAIAAA5IhBAAIAAAyIA9AAIAAA5Ig9AAIAAA1IBCAAIAAA5gAvmEuIAAjZIgrAAIAAg5ICUAAIAAA5IgsAAIAADZgAxSEuIgmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAnB4IADAAIAAh4IA1AAIAAESgA0XEuIAAg5IALAAIAAigIgLAAIAAg5IBTAAIAAA5IgLAAIAACgIALAAIAAA5gANjgbIAAkSIB9AAIAAA5IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBCAAIAAA5gAMjgbIgjhrIgGAAIAABrIg9AAIAAkSIB2AAQAeALAAAjIAAA6QAAAhgZALIAgBXIAAAngAL6i3IAWAAIAEgEIAAg9IgEgDIgWAAgAIzgbQgdgLAAgjIAAi2QAAgjAdgLIBZAAQAeALAAAjIAAC2QAAAjgeALgAJTj4IAACnIADAEIATAAIAEgEIAAinIgEgDIgTAAgAGNgbIAAkSIA9AAIAADZIA/AAIAAA5gADqgbIAAkSIB3AAQAdALAAAjIAABXQAAAjgdALIg6AAIAABfgAEnisIAXAAIAEgEIAAhIIgEgDIgXAAgACjgbIgShiIgDAAIgSBiIg4AAIAAguIAdhbIgdhbIAAguIA4AAIASBiIADAAIAShiIA4AAIAAAuIgdBbIAdBbIAAAugAhKgbIAAkSIB9AAIAAA5IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBBAAIAAA5gAkMgbQgegLAAgjIAAi2QAAgjAegLIBZAAQAdALAAAjIAAC2QAAAjgdALgAjtj4IAACnIAEAEIATAAIAEgEIAAinIgEgDIgTAAgAmegbIAAjZIgrAAIAAg5ICUAAIAAA5IgsAAIAADZgAqCgbQgegLAAgjIAAg2IA9AAIAAAuIAEAEIATAAIAEgEIAAgpIgEgGIg+gcQgNgGgFgKQgEgIAAgRIAAg6QAAgjAegLIBZAAQAeALAAAjIAAAzIg9AAIAAgsIgEgDIgTAAIgEADIAAAoIAFAGIA9AZQANAFAFALQAEAJAAARIAAA+QAAAjgeALgAtFgbIAAkSIB3AAQAdALAAAjIAAAoQAAAjgeALQAeALAAAjIAAAyQAAAjgdALgAsIhJIAXAAIAEgEIAAg8IgEgEIgXAAgAsIi7IAXAAIAEgEIAAg8IgEgEIgXAAgAvKgbQgegLAAgjIAAjkIA9AAIAADcIAEAEIAPAAIAEgEIAAjcIA9AAIAADkQAAAjgeALgAxwgbIAAkSIA9AAIAADZIA+AAIAAA5gAz6gbQgdgLAAgjIAAi2QAAgjAdgLIBZAAQAeALAAAjIAABCIg9AAIAAg7IgEgDIgTAAIgDADIAACnIADAEIATAAIAEgEIAAg5IA9AAIAABBQAAAjgeALgAGfllIAAjZIgsAAIAAg5ICUAAIAAA5IgrAAIAADZgAEzllIgmh4IgEAAIAAB4Ig1AAIAAkSIA1AAIAmB4IAEAAIAAh4IA1AAIAAESgABCllIAAkSIB9AAIAAA5IhAAAIAAAyIA8AAIAAA5Ig8AAIAAA1IBCAAIAAA5gAhkllIAAkSIB1AAQAeALAAAjIAAC2QAAAjgeALgAgnmXIAWAAIAEgEIAAinIgEgDIgWAAgAjqllQgdgLAAgjIAAjkIA9AAIAADcIADAEIAPAAIAEgEIAAjcIA9AAIAADkQAAAjgdALgAl7llIAAjZIgsAAIAAg5ICUAAIAAA5IgrAAIAADZgAomllQgegLAAgjIAAg2IA9AAIAAAuIADAEIAUAAIADgEIAAgpIgDgGIg/gcQgNgGgEgKQgEgIAAgRIAAg6QAAgjAegLIBYAAQAeALAAAjIAAAzIg9AAIAAgsIgDgDIgUAAIgDADIAAAoIAFAGIA9AZQANAFAEALQAEAJAAARIAAA+QAAAjgeALgAusllQgdgLAAgjIAAi2QAAgjAdgLIBZAAQAeALAAAjIAAC2QAAAjgeALgAuMpCIAACnIADAEIATAAIAEgEIAAinIgEgDIgTAAgAxTllQgdgLAAgjIAAglIA9AAIAAAdIADAEIATAAIAEgEIAAg6IgEgEIgiAAIAAguIAiAAIAEgEIAAg3IgEgDIgTAAIgDADIAAAeIg9AAIAAglQAAgjAdgLIBZAAQAeALAAAjIAAAvQAAAdgVANQAVANAAAdIAAAzQAAAjgeALgA0XllIAAhcQAAggAVgJIBCgeIAAg6IgEgDIgTAAIgDADIAAAoIg9AAIAAgvQAAgjAdgLIBZAAQAeALAAAjIAABFQAAARgEAIQgEALgNAGIhCAdIAAAfIBXAAIAAA5gArtmXIAAg1IgxAAIAAgqIAxAAIAAg1IAqAAIAAA1IAxAAIAAAqIgxAAIAAA1g");
	this.shape.setTransform(133.375,93.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A2+K4IABjaIgBAAIAAmBIAAAAIABmeIgBAAIAAl3MAhxAAAIAAFTIHfAAIAAFMIEtAAIAAF0IydAAIAAFdg");
	this.shape_1.setTransform(123.125,93.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24,24.3,294.3,139.29999999999998);


(lib.g_txt01AD45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AL8HjIAAmpIDDAAIAABZIhlAAIAABSIBfAAIAABZIhfAAIAAClgAIoHjIAAmpIBeAAIAAFQIBiAAIAABZgAFFHjIAAmpIDDAAIAABZIhlAAIAABMIBfAAIAABZIhfAAIAABSIBoAAIAABZgABzHjQgugRAAg3IAAhTIBeAAIAABIIAGAGIAdAAIAGgGIAAhBIgFgIIhhgsQgVgJgHgQQgFgNAAgaIAAhaQAAg2AugRICKAAQAuARAAA2IAABOIhfAAIAAhCIgGgHIgdAAIgGAHIAAA9IAIAKIBfAmQAUAIAHARQAGANAAAbIAABgQAAA3guARgAgbHjIg2ilIgKAAIAAClIhfAAIAAmpIC5AAQAtARAAA2IAABaQAAAzgoARIAzCIIAAA8gAhbDwIAjAAIAGgGIAAhdIgGgHIgjAAgAmJHjQgugRAAg3IAAlhIBeAAIAAFWIAGAGIAYAAIAGgGIAAlWIBeAAIAAFhQAAA3guARgAqMHjQgvgRAAg3IAAkaQAAg2AvgRICKAAQAuARAAA2IAAEaQAAA3guARgApcCNIAAEDIAGAGIAdAAIAGgGIAAkDIgGgHIgdAAgAt3HjIAAioIhHi6IAAhHIBZAAIAaCSIAGAAIAbiSIBYAAIAABHIhHC6IAACogAJ0g4IAAlQIhEAAIAAhZIDmAAIAABZIhEAAIAAFQgAFmg4QgugRAAg3IAAkaQAAg2AugRICKAAQAuARAAA2IAABmIheAAIAAhaIgGgHIgeAAIgGAHIAAEDIAGAGIAeAAIAGgGIAAhaIBeAAIAABlQAAA3guARgABVg4IAAmpIDDAAIAABZIhlAAIAABMIBfAAIAABZIhfAAIAABSIBoAAIAABZgAgag4Ig7i6IgGAAIAAC6IhTAAIAAmpIBTAAIA7C5IAGAAIAAi5IBSAAIAAGpgAkeg4Ig7i6IgFAAIAAC6IhTAAIAAmpIBTAAIA7C5IAFAAIAAi5IBTAAIAAGpgAqGg4QgvgRAAg3IAAkaQAAg2AvgRICKAAQAuARAAA2IAAEaQAAA3guARgApWmOIAAEDIAGAGIAdAAIAGgGIAAkDIgGgHIgdAAgAuKg4QgugRAAg3IAAkaQAAg2AugRICKAAQAuARAAA2IAABmIheAAIAAhaIgGgHIgeAAIgGAHIAAEDIAGAGIAeAAIAGgGIAAhaIBeAAIAABlQAAA3guARg");
	this.shape.setTransform(98.775,20.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.9,-27.3,191.79999999999998,96.5);


(lib.g_SFULogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWBIQgLgCgNgGQAEgIACgNQAIAHAHADQAKAFAMAAQANAAAHgGQAIgHAAgLQAAgKgLgIQgFgEgOgGQgOgGgGgDQgOgKAAgTQAAgRALgLQAMgMAVAAQAJAAAMADIANAEIgDAIIgDALQgKgHgJgCQgHgDgHAAQgJAAgGAGQgGAFAAAJQAAAKAIAHIAbAPQATAIAGAJQAFAIAAAKQAAAOgKAMQgNASgdAAgABMA/QgIgGgFgHQgDgGgBgFIgBgVIgChYIANABIAMgBIgCATIgBA/IABAWQABAFADAEQAJANAZAAQAQAAAKgGIAIgHQAEgEAAgHIABgYIAAggIgBgeIgBgQIALABIAKgBIgBBPQAAAZgDALQgEAKgLAIQgOAJgaAAQgbAAgNgJgAgqBGIgLABIACgUIgBh5IA8ABIAQgBIgBAKIAAAKIgJgBIgsgBIAAAqIAZAAQANAAALgCIgBALIABAJIgxgCIAAASQAAAcABATg");
	this.shape.setTransform(56.0499,28.3575,1.1828,1.1827);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#992932").s().p("AlRCpIAAlRIKjAAIAAFRg");
	this.shape_1.setTransform(39.9927,19.9899,1.1828,1.1827);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,40);


(lib.g_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C92539").s().p("ABYEEIAAlbIlbAAIAAisIIHAAIAAIHg");
	this.shape.setTransform(26,26);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,52,52);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgXA6QgKgGgHgKQgFgJAAgNIAAhQIABgBIABgBIAVAAIABABIABABIAABRQAAAJAGAFQAGAHAIgBQAKABAFgHQAGgFAAgJIAAhRIAAgBIACgBIAVAAIACABIAAABIAABQQAAANgGAJQgFALgLAFQgKAFgOAAQgNAAgKgFg");
	this.shape.setTransform(168.5,21.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIACAAIAAACIAAARIAAACIgCAAIg5AAIgBABIAAAcIABABIAlAAIABAAIACACIAAAQIgCABIgBABIglAAIgBABIAAAxIAAACIgCAAg");
	this.shape_1.setTransform(158.35,21.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgXA7QgLgEgGgJQgFgIAAgMIAAgDIAAgCIACgBIAUAAIACABIAAACIAAACQAAAHAHAFQAGAFALAAQAJAAAFgEQAEgEAAgGQAAgEgDgDQgCgDgFgCIgPgGQgMgEgIgFQgIgDgGgHQgGgIAAgKQAAgLAGgIQAFgIAKgFQAKgEANAAQAMAAALAFQALAFAGAIQAFAJAAALIAAADIAAACIgCAAIgUAAIgCAAIAAgCIAAgBQAAgIgGgFQgHgFgJAAQgJAAgEADQgFAEAAAGQAAAFADADQACADAGACIAQAHIAUAIQAHACAGAHQAFAHAAAMQAAAQgMAKQgMAKgVAAQgNAAgLgFg");
	this.shape_2.setTransform(147.675,21.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_3.setTransform(133.325,21.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIAAACIgCAAg");
	this.shape_4.setTransform(122.6,21.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgKA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBAAIgBgCIAAgRIABgCIABAAIBZAAIACAAIAAACIAAARIAAACIgCAAIggAAIgBABIAABjIgBACIgBAAg");
	this.shape_5.setTransform(108.65,21.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgXA6QgLgFgGgKQgFgKAAgNIAAgoQAAgNAFgJQAGgKALgFQALgGAMAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgFAKQgHAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_6.setTransform(98.1,21.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgoA+IgCAAIAAgCIAAh3IAAgCIACAAIBRAAIABAAIABACIAAARIgBACIgBAAIg5AAIgBABIAAAcIABABIAlAAIABAAIABACIAAAQIgBABIgBABIglAAIgBABIAAAdIABABIA5AAIABAAIABACIAAARIgBACIgBAAg");
	this.shape_7.setTransform(87.725,21.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_8.setTransform(76.425,21.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAaA+QAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAgBAAIgthLIAAgBIgBABIABBKIgBACIgBAAIgVAAIgCAAIAAgCIAAh3IAAgCIACAAIAUAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIAtBLIABAAIAAAAIAAhKIABgCIABAAIAVAAIACAAIAAACIAAB3IAAACIgCAAg");
	this.shape_9.setTransform(64.625,21.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgYA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFANAAQAOAAALAFQAKAGAGAKQAGALAAANIAAAkQAAAOgGALQgGAJgKAGQgLAGgOAAQgNAAgLgGgAgPgjQgGAGAAALIAAAlQAAALAGAGQAGAHAJAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgJABgGAGg");
	this.shape_10.setTransform(53.175,21.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgXA6QgLgFgFgKQgGgKAAgNIAAgoQAAgNAGgJQAFgKALgFQALgGAMAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgVACIAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgKgGgGQgFgFgKAAQgIAAgGAFQgGAGAAAKIAAApQAAAKAGAFQAGAGAIAAQAKAAAFgGQAGgFAAgKQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAVABIACABIAAABQAAAMgGAKQgGAJgKAGQgKAFgOAAQgMAAgLgGg");
	this.shape_11.setTransform(42.3,21.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_12.setTransform(20.475,20.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhFBiIBhhiIhhhhIAVgVIB2B2Ih2B3g");
	this.shape_13.setTransform(20.475,20.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AD/A6QgLgGgGgJQgFgLgBgOIAAgkQABgNAFgLQAGgKALgGQALgFANAAQAOAAALAFQALAGAFAKQAGALAAANIAAAkQAAAOgGALQgFAJgLAGQgLAGgOAAQgNAAgLgGgAEIgjQgHAGAAALIAAAlQAAALAHAGQAFAHAKAAQAKAAAGgHQAGgGAAgLIAAglQAAgLgGgGQgGgGgKgBQgKABgFAGgAoiA6QgKgGgGgJQgGgLAAgOIAAgkQAAgNAGgLQAGgKAKgGQALgFAOAAQAOAAAKAFQALAGAGAKQAFALABANIAAAkQgBAOgFALQgGAJgLAGQgKAGgOAAQgOAAgLgGgAoZgjQgGAGAAALIAAAlQAAALAGAGQAGAHAKAAQAJAAAGgHQAHgGgBgLIAAglQABgLgHgGQgGgGgJgBQgKABgGAGgAJfA6QgKgGgHgJQgFgJAAgOIAAhQIABgBIABAAIAVAAIABAAIABABIAABRQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJIAAhRIAAgBIACAAIAVAAIACAAIAAABIAABQQAAAOgGAJQgFAKgLAFQgKAFgOAAQgOAAgKgFgAGPA7QgLgFgGgIQgGgJAAgLIAAgEIABgBIACgBIAUAAIABABIABABIAAADQAAAHAHAFQAGAFAMAAQAJAAAEgEQAFgEAAgGQAAgEgDgDQgDgDgEgCIgQgHQgMgDgIgFQgJgDgFgHQgGgIAAgKQAAgMAFgHQAGgJAKgEQAKgEAMAAQAOAAAKAFQAMAFAFAIQAGAJAAALIAAADIAAACIgCAAIgVAAIgBAAIAAgCIAAgCQAAgHgHgFQgGgGgLAAQgIABgEADQgFADAAAHQAAAFADADQACACAGADIAQAHIAVAIQAHACAFAHQAGAHAAALQAAARgMAKQgNAKgUgBQgOAAgLgEgAhgA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAHAKQAFAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgFAKQgHAJgKAFQgKAGgOgBQgNAAgLgFgAqOA6QgLgGgGgJQgFgKAAgNIAAgoQAAgNAFgKQAGgKALgFQALgFANAAQAOAAAKAFQAKAFAGAKQAGAJAAAMQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAIgVACQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgKgGgGQgFgFgKgBQgJABgGAFQgGAGAAAKIAAApQAAAJAGAGQAGAGAJAAQAKAAAFgGQAGgGAAgJQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIAVABIACAAIAAACQAAAMgGAKQgGAJgKAFQgKAGgOgBQgNAAgLgFgAHpA+IgCAAIAAgCIAAh4IAAgBIACAAIBRAAIACAAIAAABIAAASIAAABIgCABIg5AAIgCABIAAAcIACABIAmAAIABAAIABACIAAAQIgBABIgBABIgmAAIgCAAIAAAyIAAACIgCAAgAChA+IgCAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBaAAIACAAIAAABIAAASIAAABIgCABIggAAIgBABIAABjIgBACIgBAAgAAVA+IgBAAIAAgCIAAhjIgBgBIgfAAIgBgBIgBgBIAAgSIABgBIABAAIBZAAIACAAIAAABIAAASIAAABIgCABIgfAAIgBABIAABjIgBACIgCAAgAjZA+IgCAAIAAgCIAAh4IAAgBIACAAIBTAAIABAAIABABIAAASIgBABIgBABIg7AAIgBABIAAAcIABABIAmAAIABAAIACACIAAAQIgCABIgBABIgmAAIgBAAIAAAdIABABIA7AAIABABIABACIAAARIgBACIgBAAgAkHA+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBAAIgthMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIAAAAIAAhLIABgBIABAAIAWAAIABAAIABABIAAB4IgBACIgBAAgAl9A+QAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAAAIguhMIgBAAIAAAAIAABLIAAACIgCAAIgVAAIgCAAIAAgCIAAh4IAAgBIACAAIAUAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABABAAIAuBLIAAAAIABAAIAAhLIAAgBIABAAIAVAAIACAAIABABIAAB4IgBACIgCAAg");
	this.shape_14.setTransform(105.4,21.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13}]},1).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Bg
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AueDNIAAmZIc9AAIAAGZg");
	this.shape_15.setTransform(92.725,20.475);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AOfDNI89AAIAAmZIc9AAg");
	this.shape_16.setTransform(92.725,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,187.5,43);


(lib.gpic5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Arrow
	this.instance = new lib.g_arrow("synched",0);
	this.instance.setTransform(83.95,91.05,1,1,89.9948,0,0,26,26.1);

	this.instance_1 = new lib.g_arrow("synched",0);
	this.instance_1.setTransform(219,253.95,1,1,-89.9948,0,0,26.1,25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Photo
	this.instance_2 = new lib.Pic5();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,480);


// stage content:
(lib.banner_320x480 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Red_Bg_as_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("EgAxAlgMAAAhK/IBjAAMAAABK/g");
	var mask_graphics_80 = new cjs.Graphics().p("EgC1AlgMAAAhK/IFrAAMAAABK/g");
	var mask_graphics_81 = new cjs.Graphics().p("EgEzAlgMAAAhK/IJnAAMAAABK/g");
	var mask_graphics_82 = new cjs.Graphics().p("EgGrAlgMAAAhK/INXAAMAAABK/g");
	var mask_graphics_83 = new cjs.Graphics().p("EgIdAlgMAAAhK/IQ7AAMAAABK/g");
	var mask_graphics_84 = new cjs.Graphics().p("EgKJAlgMAAAhK/IUTAAMAAABK/g");
	var mask_graphics_85 = new cjs.Graphics().p("EgLwAlgMAAAhK/IXhAAMAAABK/g");
	var mask_graphics_86 = new cjs.Graphics().p("EgNRAlgMAAAhK/IajAAMAAABK/g");
	var mask_graphics_87 = new cjs.Graphics().p("EgOsAlgMAAAhK/IdZAAMAAABK/g");
	var mask_graphics_88 = new cjs.Graphics().p("EgQBAlgMAAAhK/MAgDAAAMAAABK/g");
	var mask_graphics_89 = new cjs.Graphics().p("EgRQAlgMAAAhK/MAihAAAMAAABK/g");
	var mask_graphics_90 = new cjs.Graphics().p("EgSZAlgMAAAhK/MAkzAAAMAAABK/g");
	var mask_graphics_91 = new cjs.Graphics().p("EgTdAlgMAAAhK/MAm6AAAMAAABK/g");
	var mask_graphics_92 = new cjs.Graphics().p("EgUaAlgMAAAhK/MAo1AAAMAAABK/g");
	var mask_graphics_93 = new cjs.Graphics().p("EgVSAlgMAAAhK/MAqlAAAMAAABK/g");
	var mask_graphics_94 = new cjs.Graphics().p("EgWDAlgMAAAhK/MAsIAAAMAAABK/g");
	var mask_graphics_95 = new cjs.Graphics().p("EgWwAlgMAAAhK/MAtgAAAMAAABK/g");
	var mask_graphics_96 = new cjs.Graphics().p("EgXWAlgMAAAhK/MAusAAAMAAABK/g");
	var mask_graphics_97 = new cjs.Graphics().p("EgX2AlgMAAAhK/MAvtAAAMAAABK/g");
	var mask_graphics_98 = new cjs.Graphics().p("EgYQAlgMAAAhK/MAwhAAAMAAABK/g");
	var mask_graphics_99 = new cjs.Graphics().p("EgYkAlgMAAAhK/MAxJAAAMAAABK/g");
	var mask_graphics_100 = new cjs.Graphics().p("EgYzAlgMAAAhK/MAxoAAAMAAABK/g");
	var mask_graphics_101 = new cjs.Graphics().p("EgY8AlgMAAAhK/MAx5AAAMAAABK/g");
	var mask_graphics_102 = new cjs.Graphics().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:325,y:240}).wait(1).to({graphics:mask_graphics_80,x:310.975,y:240}).wait(1).to({graphics:mask_graphics_81,x:297.55,y:240}).wait(1).to({graphics:mask_graphics_82,x:284.75,y:240}).wait(1).to({graphics:mask_graphics_83,x:272.575,y:240}).wait(1).to({graphics:mask_graphics_84,x:261.05,y:240}).wait(1).to({graphics:mask_graphics_85,x:250.125,y:240}).wait(1).to({graphics:mask_graphics_86,x:239.85,y:240}).wait(1).to({graphics:mask_graphics_87,x:230.175,y:240}).wait(1).to({graphics:mask_graphics_88,x:221.125,y:240}).wait(1).to({graphics:mask_graphics_89,x:212.725,y:240}).wait(1).to({graphics:mask_graphics_90,x:204.9,y:240}).wait(1).to({graphics:mask_graphics_91,x:197.75,y:240}).wait(1).to({graphics:mask_graphics_92,x:191.2,y:240}).wait(1).to({graphics:mask_graphics_93,x:185.275,y:240}).wait(1).to({graphics:mask_graphics_94,x:179.95,y:240}).wait(1).to({graphics:mask_graphics_95,x:175.3,y:240}).wait(1).to({graphics:mask_graphics_96,x:171.25,y:240}).wait(1).to({graphics:mask_graphics_97,x:167.775,y:240}).wait(1).to({graphics:mask_graphics_98,x:165,y:240}).wait(1).to({graphics:mask_graphics_99,x:162.8,y:240}).wait(1).to({graphics:mask_graphics_100,x:161.25,y:240}).wait(1).to({graphics:mask_graphics_101,x:160.3,y:240}).wait(1).to({graphics:mask_graphics_102,x:160,y:240}).wait(252));

	// Logo
	this.instance = new lib.g_SFULogo("synched",0);
	this.instance.setTransform(0.1,108.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(275));

	// Btn
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(97.5,281.3,1,1,0,0,0,83,25.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(258).to({_off:false},0).to({x:118.5,alpha:1},22,cjs.Ease.get(0.9)).wait(74));

	// text_03_AD456
	this.instance_2 = new lib.g_txt03AD456("synched",0);
	this.instance_2.setTransform(32.05,200.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({alpha:1},28,cjs.Ease.get(1)).wait(116));

	// text_02__Ad05
	this.instance_3 = new lib.g_txt02AD5("synched",0);
	this.instance_3.setTransform(-344.95,198.5,1,1,0,0,0,-66.5,28);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(79).to({_off:false},0).to({x:-42.5},25,cjs.Ease.get(1)).wait(79).to({startPosition:0},0).to({x:-344.95},21,cjs.Ease.get(1)).to({_off:true},3).wait(147));

	// Red_Bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("EgAxAlgMAAAhK/IBjAAMAAABK/g");
	this.shape.setTransform(325,240);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0633").s().p("EgC1AlgMAAAhK/IFrAAMAAABK/g");
	this.shape_1.setTransform(310.975,240);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0633").s().p("EgEzAlgMAAAhK/IJnAAMAAABK/g");
	this.shape_2.setTransform(297.55,240);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0633").s().p("EgGrAlgMAAAhK/INXAAMAAABK/g");
	this.shape_3.setTransform(284.75,240);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0633").s().p("EgIdAlgMAAAhK/IQ7AAMAAABK/g");
	this.shape_4.setTransform(272.575,240);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0633").s().p("EgKJAlgMAAAhK/IUTAAMAAABK/g");
	this.shape_5.setTransform(261.05,240);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0633").s().p("EgLwAlgMAAAhK/IXhAAMAAABK/g");
	this.shape_6.setTransform(250.125,240);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0633").s().p("EgNRAlgMAAAhK/IajAAMAAABK/g");
	this.shape_7.setTransform(239.85,240);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0633").s().p("EgOsAlgMAAAhK/IdZAAMAAABK/g");
	this.shape_8.setTransform(230.175,240);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0633").s().p("EgQBAlgMAAAhK/MAgDAAAMAAABK/g");
	this.shape_9.setTransform(221.125,240);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0633").s().p("EgRQAlgMAAAhK/MAihAAAMAAABK/g");
	this.shape_10.setTransform(212.725,240);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0633").s().p("EgSZAlgMAAAhK/MAkzAAAMAAABK/g");
	this.shape_11.setTransform(204.9,240);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0633").s().p("EgTdAlgMAAAhK/MAm6AAAMAAABK/g");
	this.shape_12.setTransform(197.75,240);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0633").s().p("EgUaAlgMAAAhK/MAo1AAAMAAABK/g");
	this.shape_13.setTransform(191.2,240);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0633").s().p("EgVSAlgMAAAhK/MAqlAAAMAAABK/g");
	this.shape_14.setTransform(185.275,240);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0633").s().p("EgWDAlgMAAAhK/MAsIAAAMAAABK/g");
	this.shape_15.setTransform(179.95,240);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0633").s().p("EgWwAlgMAAAhK/MAtgAAAMAAABK/g");
	this.shape_16.setTransform(175.3,240);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0633").s().p("EgXWAlgMAAAhK/MAusAAAMAAABK/g");
	this.shape_17.setTransform(171.25,240);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0633").s().p("EgX2AlgMAAAhK/MAvtAAAMAAABK/g");
	this.shape_18.setTransform(167.775,240);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0633").s().p("EgYQAlgMAAAhK/MAwhAAAMAAABK/g");
	this.shape_19.setTransform(165,240);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0633").s().p("EgYkAlgMAAAhK/MAxJAAAMAAABK/g");
	this.shape_20.setTransform(162.8,240);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0633").s().p("EgYzAlgMAAAhK/MAxoAAAMAAABK/g");
	this.shape_21.setTransform(161.25,240);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0633").s().p("EgY8AlgMAAAhK/MAx5AAAMAAABK/g");
	this.shape_22.setTransform(160.3,240);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0633").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape_23.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},79).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(252));

	// Text_01___AD5
	this.instance_4 = new lib.g_txt01AD45("synched",0);
	this.instance_4.setTransform(-289.2,366.75,1,1,0,0,0,-66.5,28);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(11).to({_off:false},0).to({x:-69.45},21,cjs.Ease.get(1)).to({_off:true},72).wait(250));

	// Photo_AD5
	this.instance_5 = new lib.gpic5("single",0);
	var instance_5Filter_1 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_5.filters = [instance_5Filter_1];
	this.instance_5.cache(-2,-2,324,484);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},86).wait(250));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_1).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(250));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_5, startFrame:1, endFrame:18, x:-2, y:-2, w:324, h:484});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:324, h:484});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-59.8,240,389.8,240);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 320,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;