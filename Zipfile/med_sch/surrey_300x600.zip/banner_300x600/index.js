(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,582,316],[302,602,524,232],[828,602,160,80],[302,522,162,41],[828,684,162,41],[302,318,280,66],[302,386,280,66],[302,454,280,66],[584,0,300,600],[0,318,300,600]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_24 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.gtext12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_24();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,291,158);


(lib.g_txtSFUMedicalSchool = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_23();
	this.instance.setTransform(-261.9,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-261.9,0,262,116);


(lib.g_SFULogohorizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.instance = new lib.CachedBmp_20();
	this.instance.setTransform(89.65,19.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_21();
	this.instance_1.setTransform(89.65,19.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// icon
	this.instance_2 = new lib.CachedBmp_22();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.7,40.4);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_17();
	this.instance.setTransform(13,8.1,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_18();
	this.instance_1.setTransform(13,8.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_19();
	this.instance_2.setTransform(13,8.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("As9D/IAAn9IZ7AAIAAH9g");
	this.shape.setTransform(83,25.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("As9j+IZ7AAIAAH9I57AAg");
	this.shape_1.setTransform(83,25.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("As9D/IAAn9IZ7AAIAAH9g");
	this.shape_2.setTransform(83,25.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,168,53);


(lib.gpic2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.g_SFULogohorizontal("synched",1);
	this.instance.setTransform(40.1,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Pic
	this.instance_1 = new lib.Bitmap5();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


// stage content:
(lib.banner_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// White_Color_Mask
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.067)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.133)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_2.setTransform(150,300);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.2)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_3.setTransform(150,300);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.267)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_4.setTransform(150,300);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.333)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_5.setTransform(150,300);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.4)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_6.setTransform(150,300);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.467)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_7.setTransform(150,300);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.533)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_8.setTransform(150,300);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.6)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_9.setTransform(150,300);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.667)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_10.setTransform(150,300);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.733)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_11.setTransform(150,300);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.8)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_12.setTransform(150,300);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.867)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_13.setTransform(150,300);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.933)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_14.setTransform(150,300);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_15.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},108).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[]},5).wait(171));

	// White_Color_Mask
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_16.setTransform(150,300);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.859)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_17.setTransform(150,300);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.729)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_18.setTransform(150,300);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.608)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_19.setTransform(150,300);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.502)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_20.setTransform(150,300);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.404)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_21.setTransform(150,300);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.314)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_22.setTransform(150,300);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.239)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_23.setTransform(150,300);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.173)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_24.setTransform(150,300);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.118)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_25.setTransform(150,300);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.071)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_26.setTransform(150,300);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.035)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_27.setTransform(150,300);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.012)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_28.setTransform(150,300);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_29.setTransform(150,300);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.078)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_30.setTransform(150,300);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.153)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_31.setTransform(150,300);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.231)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_32.setTransform(150,300);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.306)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_33.setTransform(150,300);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.384)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_34.setTransform(150,300);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.463)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_35.setTransform(150,300);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.537)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_36.setTransform(150,300);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.616)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_37.setTransform(150,300);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.694)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_38.setTransform(150,300);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.769)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_39.setTransform(150,300);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.847)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_40.setTransform(150,300);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.922)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_41.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_16}]},128).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[]},1).to({state:[{t:this.shape_29}]},141).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_16}]},1).wait(3));

	// White_Color_Mask
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_42.setTransform(150,300);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.89)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_43.setTransform(150,300);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.788)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_44.setTransform(150,300);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.694)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_45.setTransform(150,300);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.604)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_46.setTransform(150,300);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.518)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_47.setTransform(150,300);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.443)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_48.setTransform(150,300);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.369)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_49.setTransform(150,300);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.306)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_50.setTransform(150,300);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.247)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_51.setTransform(150,300);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.192)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_52.setTransform(150,300);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.149)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_53.setTransform(150,300);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.106)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_54.setTransform(150,300);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.075)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_55.setTransform(150,300);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.047)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_56.setTransform(150,300);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.024)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_57.setTransform(150,300);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.008)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_58.setTransform(150,300);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_59.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).wait(281));

	// Red_Bg__mask_ (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_18 = new cjs.Graphics().p("A3bAyIAAhjMAu3AAAIAABjg");
	var mask_graphics_19 = new cjs.Graphics().p("A3bCtIAAlZMAu3AAAIAAFZg");
	var mask_graphics_20 = new cjs.Graphics().p("A3bEeIAAo8MAu3AAAIAAI8g");
	var mask_graphics_21 = new cjs.Graphics().p("A3bGIIAAsPMAu3AAAIAAMPg");
	var mask_graphics_22 = new cjs.Graphics().p("A3bHpIAAvRMAu3AAAIAAPRg");
	var mask_graphics_23 = new cjs.Graphics().p("A3bJCIAAyDMAu3AAAIAASDg");
	var mask_graphics_24 = new cjs.Graphics().p("A3bKSIAA0jMAu3AAAIAAUjg");
	var mask_graphics_25 = new cjs.Graphics().p("A3bLaIAA2zMAu3AAAIAAWzg");
	var mask_graphics_26 = new cjs.Graphics().p("A3bMZIAA4xMAu3AAAIAAYxg");
	var mask_graphics_27 = new cjs.Graphics().p("A3bNQIAA6fMAu3AAAIAAafg");
	var mask_graphics_28 = new cjs.Graphics().p("A3bN+IAA77MAu3AAAIAAb7g");
	var mask_graphics_29 = new cjs.Graphics().p("A3bOkIAA9IMAu3AAAIAAdIg");
	var mask_graphics_30 = new cjs.Graphics().p("A3bPCIAA+DMAu3AAAIAAeDg");
	var mask_graphics_31 = new cjs.Graphics().p("A3bPXIAA+tMAu3AAAIAAetg");
	var mask_graphics_32 = new cjs.Graphics().p("A3bPkIAA/HMAu3AAAIAAfHg");
	var mask_graphics_33 = new cjs.Graphics().p("A3bPoIAA/PMAu3AAAIAAfPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_graphics_18,x:150,y:-6}).wait(1).to({graphics:mask_graphics_19,x:150,y:7.65}).wait(1).to({graphics:mask_graphics_20,x:150,y:20.4}).wait(1).to({graphics:mask_graphics_21,x:150,y:32.15}).wait(1).to({graphics:mask_graphics_22,x:150,y:43}).wait(1).to({graphics:mask_graphics_23,x:150,y:52.875}).wait(1).to({graphics:mask_graphics_24,x:150,y:61.85}).wait(1).to({graphics:mask_graphics_25,x:150,y:69.825}).wait(1).to({graphics:mask_graphics_26,x:150,y:76.925}).wait(1).to({graphics:mask_graphics_27,x:150,y:83.05}).wait(1).to({graphics:mask_graphics_28,x:150,y:88.225}).wait(1).to({graphics:mask_graphics_29,x:150,y:92.45}).wait(1).to({graphics:mask_graphics_30,x:150,y:95.75}).wait(1).to({graphics:mask_graphics_31,x:150,y:98.125}).wait(1).to({graphics:mask_graphics_32,x:150,y:99.525}).wait(1).to({graphics:mask_graphics_33,x:150,y:100}).wait(266));

	// SFU_Logo
	this.instance = new lib.g_SFULogohorizontal("single",0);
	this.instance.setTransform(40.1,0.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).to({_off:true},106).wait(175));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:149.9994,y:299.9822}).wait(298));

	// text
	this.instance_1 = new lib.g_txtSFUMedicalSchool("synched",0);
	this.instance_1.setTransform(399.5,166,1,1,0,0,0,-162.3,77);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(33).to({_off:false},0).to({x:140.7},13,cjs.Ease.get(1)).to({_off:true},78).wait(175));

	// Red_Bg
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#CC0633").s().p("A3bAyIAAhjMAu3AAAIAABjg");
	this.shape_60.setTransform(150,-6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#CC0633").s().p("A3bCtIAAlZMAu3AAAIAAFZg");
	this.shape_61.setTransform(150,7.65);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#CC0633").s().p("A3bEeIAAo8MAu3AAAIAAI8g");
	this.shape_62.setTransform(150,20.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#CC0633").s().p("A3bGIIAAsPMAu3AAAIAAMPg");
	this.shape_63.setTransform(150,32.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#CC0633").s().p("A3bHpIAAvRMAu3AAAIAAPRg");
	this.shape_64.setTransform(150,43);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#CC0633").s().p("A3bJCIAAyDMAu3AAAIAASDg");
	this.shape_65.setTransform(150,52.875);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#CC0633").s().p("A3bKSIAA0jMAu3AAAIAAUjg");
	this.shape_66.setTransform(150,61.85);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#CC0633").s().p("A3bLaIAA2zMAu3AAAIAAWzg");
	this.shape_67.setTransform(150,69.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CC0633").s().p("A3bMZIAA4xMAu3AAAIAAYxg");
	this.shape_68.setTransform(150,76.925);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CC0633").s().p("A3bNQIAA6fMAu3AAAIAAafg");
	this.shape_69.setTransform(150,83.05);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#CC0633").s().p("A3bN+IAA77MAu3AAAIAAb7g");
	this.shape_70.setTransform(150,88.225);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#CC0633").s().p("A3bOkIAA9IMAu3AAAIAAdIg");
	this.shape_71.setTransform(150,92.45);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#CC0633").s().p("A3bPCIAA+DMAu3AAAIAAeDg");
	this.shape_72.setTransform(150,95.75);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#CC0633").s().p("A3bPXIAA+tMAu3AAAIAAetg");
	this.shape_73.setTransform(150,98.125);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#CC0633").s().p("A3bPkIAA/HMAu3AAAIAAfHg");
	this.shape_74.setTransform(150,99.525);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#CC0633").s().p("A3bPoIAA/PMAu3AAAIAAfPg");
	this.shape_75.setTransform(150,100);

	var maskedShapeInstanceList = [this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_60}]},18).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[]},91).wait(175));

	// Photo_B_W
	this.instance_2 = new lib.gpic2("synched",0);
	this.instance_2.setTransform(150,179.5,1,1,0,0,0,150,179.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true},123).wait(175));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_128 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(128).to({graphics:mask_2_graphics_128,x:150,y:300}).wait(171));

	// CTA
	this.instance_3 = new lib.btn_CTA();
	this.instance_3.setTransform(150,554.5,1,1,0,0,0,83,25.5);
	this.instance_3._off = true;
	var instance_3Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_1];
	this.instance_3.cache(-3,-3,172,57);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(193).to({_off:false},0).to({y:544.5},16,cjs.Ease.get(0.9)).to({_off:true},88).wait(2));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_1).wait(193).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.9)).wait(2));

	// SFU_Logo
	this.instance_4 = new lib.g_SFULogohorizontal("single",1);
	this.instance_4.setTransform(40.1,-40.9,1,1,0,0,0,0.1,0.1);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(181).to({_off:false},0).to({y:0.1},13,cjs.Ease.get(1)).to({_off:true},103).wait(2));

	// text
	this.instance_5 = new lib.gtext12("synched",0);
	this.instance_5.setTransform(-280,73.5);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(167).to({_off:false},0).to({x:-3.95},14,cjs.Ease.get(1)).to({_off:true},116).wait(2));

	// Red_Bg
	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#CC0633").s().p("AgqMGIAA4LIAeAAIAAHmIA3AAIAAI4IghAAIAAHtg");
	this.shape_76.setTransform(-7.15,149.35);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#CC0633").s().p("AiAMGIAA4LIBNAAIAAHmIC0AAIAAI4IglAAIAAHtg");
	this.shape_77.setTransform(2.175,149.35);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CC0633").s().p("AjTMGIAA4LIB6AAIAAHmIEtAAIAAI4IgoAAIAAHtg");
	this.shape_78.setTransform(11.2,149.35);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#CC0633").s().p("AkjMGIAA4LICnAAIAAHmIGgAAIAAI4IgsAAIAAHtg");
	this.shape_79.setTransform(19.9,149.35);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#CC0633").s().p("AlwMGIAA4LIDQAAIAAHmIISAAIAAI4IgwAAIAAHtg");
	this.shape_80.setTransform(28.3,149.35);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#CC0633").s().p("Am7MGIAA4LID5AAIAAHmIJ+AAIAAI4IgzAAIAAHtg");
	this.shape_81.setTransform(36.4,149.35);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#CC0633").s().p("AoCMGIAA4LIEgAAIAAHmILlAAIAAI4Ig2AAIAAHtg");
	this.shape_82.setTransform(44.175,149.35);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#CC0633").s().p("ApHMGIAA4LIFGAAIAAHmINJAAIAAI4Ig5AAIAAHtg");
	this.shape_83.setTransform(51.625,149.35);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#CC0633").s().p("AqJMGIAA4LIFrAAIAAHmIOoAAIAAI4Ig8AAIAAHtg");
	this.shape_84.setTransform(58.8,149.35);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#CC0633").s().p("ArIMGIAA4LIGNAAIAAHmIQEAAIAAI4Ig/AAIAAHtg");
	this.shape_85.setTransform(65.675,149.35);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#CC0633").s().p("AsEMGIAA4LIGuAAIAAHmIRcAAIAAI4IhDAAIAAHtg");
	this.shape_86.setTransform(72.2,149.35);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#CC0633").s().p("As+MGIAA4LIHOAAIAAHmISvAAIAAI4IhFAAIAAHtg");
	this.shape_87.setTransform(78.425,149.35);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#CC0633").s().p("At0MGIAA4LIHrAAIAAHmIT+AAIAAI4IhGAAIAAHtg");
	this.shape_88.setTransform(84.325,149.35);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#CC0633").s().p("AuoMGIAA4LIIIAAIAAHmIVJAAIAAI4IhJAAIAAHtg");
	this.shape_89.setTransform(89.95,149.35);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#CC0633").s().p("AvZMGIAA4LIIjAAIAAHmIWQAAIAAI4IhMAAIAAHtg");
	this.shape_90.setTransform(95.275,149.35);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#CC0633").s().p("AwGMGIAA4LII7AAIAAHmIXSAAIAAI4IhNAAIAAHtg");
	this.shape_91.setTransform(100.25,149.35);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#CC0633").s().p("AwyMGIAA4LIJUAAIAAHmIYRAAIAAI4IhQAAIAAHtg");
	this.shape_92.setTransform(104.925,149.35);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#CC0633").s().p("AxaMGIAA4LIJqAAIAAHmIZLAAIAAI4IhRAAIAAHtg");
	this.shape_93.setTransform(109.3,149.35);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#CC0633").s().p("Ax/MGIAA4LIJ+AAIAAHmIaBAAIAAI4IhSAAIAAHtg");
	this.shape_94.setTransform(113.35,149.35);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#CC0633").s().p("AyiMGIAA4LIKRAAIAAHmIa0AAIAAI4IhVAAIAAHtg");
	this.shape_95.setTransform(117.1,149.35);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#CC0633").s().p("AzBMGIAA4LIKhAAIAAHmIbiAAIAAI4IhVAAIAAHtg");
	this.shape_96.setTransform(120.55,149.35);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#CC0633").s().p("AzfMGIAA4LIKyAAIAAHmIcNAAIAAI4IhYAAIAAHtg");
	this.shape_97.setTransform(123.7,149.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#CC0633").s().p("Az4MGIAA4LILAAAIAAHmIcyAAIAAI4IhZAAIAAHtg");
	this.shape_98.setTransform(126.5,149.35);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#CC0633").s().p("A0QMGIAA4LILNAAIAAHmIdUAAIAAI4IhaAAIAAHtg");
	this.shape_99.setTransform(129.025,149.35);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#CC0633").s().p("A0kMGIAA4LILYAAIAAHmIdxAAIAAI4IhaAAIAAHtg");
	this.shape_100.setTransform(131.225,149.35);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#CC0633").s().p("A01MGIAA4LILhAAIAAHmIeKAAIAAI4IhbAAIAAHtg");
	this.shape_101.setTransform(133.125,149.35);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#CC0633").s().p("A1EMGIAA4LILpAAIAAHmIegAAIAAI4IhcAAIAAHtg");
	this.shape_102.setTransform(134.7,149.35);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#CC0633").s().p("A1QMGIAA4LILwAAIAAHmIexAAIAAI4IhdAAIAAHtg");
	this.shape_103.setTransform(135.975,149.35);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#CC0633").s().p("A1ZMGIAA4LIL1AAIAAHmIe9AAIAAI4IhcAAIAAHtg");
	this.shape_104.setTransform(136.95,149.35);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#CC0633").s().p("A1eMGIAA4LIL3AAIAAHmIfGAAIAAI4IhcAAIAAHtg");
	this.shape_105.setTransform(137.6,149.35);

	var maskedShapeInstanceList = [this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_76}]},152).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[]},116).wait(2));

	// Photo_B_W
	this.instance_6 = new lib.Bitmap4();
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(128).to({_off:false},0).to({_off:true},169).wait(2));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_3, startFrame:193, endFrame:193, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:194, endFrame:209, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:210, endFrame:297, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:297, endFrame:299, x:-3, y:-3, w:172, h:57});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,150,300);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;