(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,0,376,210],[0,252,377,168],[379,252,160,80],[743,310,162,41],[743,353,162,41],[541,252,200,56],[743,252,200,56],[541,310,200,56],[378,0,300,250],[680,0,300,250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_8 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.gtext12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,188,105);


(lib.g_txtSFUMedicalSchool = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(-133.05,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-133,0,188.5,84);


(lib.g_SFULogohorizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.instance = new lib.CachedBmp_4();
	this.instance.setTransform(89.65,19.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_5();
	this.instance_1.setTransform(89.65,19.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// icon
	this.instance_2 = new lib.CachedBmp_6();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170.7,40.4);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(0,2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(0,2,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_3();
	this.instance_2.setTransform(0,2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AnzCgIAAk/IPnAAIAAE/g");
	this.shape.setTransform(50,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AnzifIPnAAIAAE/IvnAAg");
	this.shape_1.setTransform(50,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AnzCgIAAk/IPnAAIAAE/g");
	this.shape_2.setTransform(50,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,102,34);


(lib.gpic2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.g_SFULogohorizontal("synched",1);
	this.instance.setTransform(40.1,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Bitmap7();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


// stage content:
(lib.banner_300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// White_Color_Mask
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.067)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_1.setTransform(150,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.133)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_2.setTransform(150,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.2)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_3.setTransform(150,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.267)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_4.setTransform(150,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.333)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_5.setTransform(150,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.4)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_6.setTransform(150,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.467)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_7.setTransform(150,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.533)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_8.setTransform(150,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.6)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_9.setTransform(150,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.667)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_10.setTransform(150,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.733)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_11.setTransform(150,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.8)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_12.setTransform(150,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.867)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_13.setTransform(150,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.933)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_14.setTransform(150,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_15.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},131).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[]},2).wait(181));

	// White_Color_Mask
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_16.setTransform(150,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.878)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_17.setTransform(150,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.761)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_18.setTransform(150,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.655)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_19.setTransform(150,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.557)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_20.setTransform(150,125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.467)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_21.setTransform(150,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.384)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_22.setTransform(150,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.31)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_23.setTransform(150,125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.243)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_24.setTransform(150,125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.184)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_25.setTransform(150,125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.133)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_26.setTransform(150,125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.09)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_27.setTransform(150,125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.055)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_28.setTransform(150,125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.027)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_29.setTransform(150,125);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.012)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_30.setTransform(150,125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_31.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_16}]},152).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[]},1).wait(161));

	// White_Color_Mask
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_32.setTransform(150,125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.071)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_33.setTransform(150,125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.141)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_34.setTransform(150,125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.216)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_35.setTransform(150,125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.286)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_36.setTransform(150,125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.357)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_37.setTransform(150,125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.427)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_38.setTransform(150,125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.502)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_39.setTransform(150,125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.573)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_40.setTransform(150,125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.643)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_41.setTransform(150,125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.714)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_42.setTransform(150,125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.784)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_43.setTransform(150,125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.859)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_44.setTransform(150,125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.929)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_45.setTransform(150,125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_46.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_32}]},313).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).wait(2));

	// Red_Bg__mask_ (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("A3bAyIAAhjMAu3AAAIAABjg");
	var mask_graphics_21 = new cjs.Graphics().p("A3bBIIAAiPMAu3AAAIAACPg");
	var mask_graphics_22 = new cjs.Graphics().p("A3bBdIAAi5MAu3AAAIAAC5g");
	var mask_graphics_23 = new cjs.Graphics().p("A3bBxIAAjhMAu3AAAIAADhg");
	var mask_graphics_24 = new cjs.Graphics().p("A3bCDIAAkFMAu3AAAIAAEFg");
	var mask_graphics_25 = new cjs.Graphics().p("A3bCUIAAknMAu3AAAIAAEng");
	var mask_graphics_26 = new cjs.Graphics().p("A3bCjIAAlFMAu3AAAIAAFFg");
	var mask_graphics_27 = new cjs.Graphics().p("A3bCxIAAlhMAu3AAAIAAFhg");
	var mask_graphics_28 = new cjs.Graphics().p("A3bC/IAAl8MAu3AAAIAAF8g");
	var mask_graphics_29 = new cjs.Graphics().p("A3bDKIAAmTMAu3AAAIAAGTg");
	var mask_graphics_30 = new cjs.Graphics().p("A3bDUIAAmnMAu3AAAIAAGng");
	var mask_graphics_31 = new cjs.Graphics().p("A3bDdIAAm5MAu3AAAIAAG5g");
	var mask_graphics_32 = new cjs.Graphics().p("A3bDkIAAnHMAu3AAAIAAHHg");
	var mask_graphics_33 = new cjs.Graphics().p("A3bDqIAAnTMAu3AAAIAAHTg");
	var mask_graphics_34 = new cjs.Graphics().p("A3bDvIAAndMAu3AAAIAAHdg");
	var mask_graphics_35 = new cjs.Graphics().p("A3bDyIAAnjMAu3AAAIAAHjg");
	var mask_graphics_36 = new cjs.Graphics().p("A3bD1IAAnpMAu3AAAIAAHpg");
	var mask_graphics_37 = new cjs.Graphics().p("A3bD1IAAnpMAu3AAAIAAHpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:150,y:-6}).wait(1).to({graphics:mask_graphics_21,x:150,y:-2.525}).wait(1).to({graphics:mask_graphics_22,x:150,y:0.75}).wait(1).to({graphics:mask_graphics_23,x:150,y:3.825}).wait(1).to({graphics:mask_graphics_24,x:150,y:6.65}).wait(1).to({graphics:mask_graphics_25,x:150,y:9.3}).wait(1).to({graphics:mask_graphics_26,x:150,y:11.725}).wait(1).to({graphics:mask_graphics_27,x:150,y:13.95}).wait(1).to({graphics:mask_graphics_28,x:150,y:15.95}).wait(1).to({graphics:mask_graphics_29,x:150,y:17.75}).wait(1).to({graphics:mask_graphics_30,x:150,y:19.325}).wait(1).to({graphics:mask_graphics_31,x:150,y:20.7}).wait(1).to({graphics:mask_graphics_32,x:150,y:21.85}).wait(1).to({graphics:mask_graphics_33,x:150,y:22.825}).wait(1).to({graphics:mask_graphics_34,x:150,y:23.55}).wait(1).to({graphics:mask_graphics_35,x:150,y:24.075}).wait(1).to({graphics:mask_graphics_36,x:150,y:24.4}).wait(1).to({graphics:mask_graphics_37,x:150,y:24.5}).wait(292));

	// SFU_Logo
	this.instance = new lib.g_SFULogohorizontal("single",0);
	this.instance.setTransform(40.1,0.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},127).wait(182));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	mask_1.setTransform(150,125.0015);

	// text
	this.instance_1 = new lib.g_txtSFUMedicalSchool("synched",0);
	this.instance_1.setTransform(-63.45,198.5,1,1,0,0,0,-66.5,28);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).to({x:63.55},14,cjs.Ease.get(1)).to({_off:true},89).wait(182));

	// Red_bg_for_txt
	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#CC0633").s().p("AgLFkIABrHIAAAAIAWAAIAAF+IgMAAIAAFJg");
	this.shape_47.setTransform(-3.9,214.275);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#CC0633").s().p("AhKFoIABrOICUAAIAAGCIg+AAIAAFMg");
	this.shape_48.setTransform(2.775,213.95);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#CC0633").s().p("AiHFrIABrVIEPAAIAAGFIhvAAIAAFQg");
	this.shape_49.setTransform(9.2,213.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#CC0633").s().p("AjCFtIABrZIGEAAIAAGHIidAAIAAFSg");
	this.shape_50.setTransform(15.425,213.375);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#CC0633").s().p("Aj7FwIABrfIH2AAIAAGKIjJAAIAAFVg");
	this.shape_51.setTransform(21.4,213.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#CC0633").s().p("AkyFzIABrlIJjAAIAAGNIj0AAIAAFYg");
	this.shape_52.setTransform(27.15,212.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#CC0633").s().p("AlmF2IABrqILMAAIAAGPIkeAAIAAFbg");
	this.shape_53.setTransform(32.65,212.55);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#CC0633").s().p("AmYF4IABrvIMwAAIAAGSIlFAAIAAFdg");
	this.shape_54.setTransform(37.9,212.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#CC0633").s().p("AnIF6IABrzIOPAAIAAGUIlqAAIAAFfg");
	this.shape_55.setTransform(42.95,212.075);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#CC0633").s().p("An2F9IABr5IPsAAIAAGWImPAAIAAFjg");
	this.shape_56.setTransform(47.75,211.85);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#CC0633").s().p("AohF/IABr9IRCAAIAAGZImxAAIAAFkg");
	this.shape_57.setTransform(52.325,211.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#CC0633").s().p("ApKGBIABsBISUAAIAAGbInRAAIAAFmg");
	this.shape_58.setTransform(56.65,211.425);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#CC0633").s().p("ApxGDIABsEIThAAIAAGcInvAAIAAFog");
	this.shape_59.setTransform(60.75,211.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#CC0633").s().p("AqVGFIABsJIUqAAIAAGeIoMAAIAAFrg");
	this.shape_60.setTransform(64.625,211.05);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#CC0633").s().p("Aq4GGIABsLIVwAAIAAGfIooAAIAAFsg");
	this.shape_61.setTransform(68.25,210.875);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#CC0633").s().p("ArYGIIABsPIWwAAIAAGhIpAAAIAAFug");
	this.shape_62.setTransform(71.65,210.725);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#CC0633").s().p("Ar2GJIABsRIXsAAIAAGiIpYAAIAAFvg");
	this.shape_63.setTransform(74.8,210.575);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#CC0633").s().p("AsSGLIABsUIYkAAIAAGjIpuAAIAAFxg");
	this.shape_64.setTransform(77.75,210.45);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#CC0633").s().p("AssGMIABsXIZYAAIAAGlIqDAAIAAFyg");
	this.shape_65.setTransform(80.45,210.325);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#CC0633").s().p("AtDGNIABsZIaGAAIAAGmIqVAAIAAFzg");
	this.shape_66.setTransform(82.875,210.2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#CC0633").s().p("AtYGOIABsbIawAAIAAGnIqlAAIAAF0g");
	this.shape_67.setTransform(85.1,210.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CC0633").s().p("AtrGPIABsdIbWAAIAAGoIq0AAIAAF1g");
	this.shape_68.setTransform(87.1,210);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CC0633").s().p("At7GQIABsfIb3AAIAAGpIrBAAIAAF2g");
	this.shape_69.setTransform(88.85,209.925);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#CC0633").s().p("AuKGRIABsgIcUAAIAAGpIrNAAIAAF3g");
	this.shape_70.setTransform(90.4,209.85);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#CC0633").s().p("AuWGRIABshIcsAAIAAGqIrWAAIAAF3g");
	this.shape_71.setTransform(91.675,209.775);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#CC0633").s().p("AugGSIABsjIdAAAIAAGrIreAAIAAF4g");
	this.shape_72.setTransform(92.725,209.75);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#CC0633").s().p("AuoGSIABsjIdQAAIAAGrIrkAAIAAF4g");
	this.shape_73.setTransform(93.55,209.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#CC0633").s().p("AutGSIAAsjIdbAAIAAGrIroAAIAAF4g");
	this.shape_74.setTransform(94.15,209.675);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#CC0633").s().p("AuxGTIABslIdiAAIAAGsIrrAAIAAF5g");
	this.shape_75.setTransform(94.475,209.65);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#CC0633").s().p("AuyGTIABslIABAAIdjAAIAAGsIrsAAIAAF5g");
	this.shape_76.setTransform(94.6,209.65);

	var maskedShapeInstanceList = [this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_47}]},29).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[]},89).wait(182));

	// Red_Bg
	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#CC0633").s().p("A3bAyIAAhjMAu3AAAIAABjg");
	this.shape_77.setTransform(150,-6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CC0633").s().p("A3bBIIAAiPMAu3AAAIAACPg");
	this.shape_78.setTransform(150,-2.525);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#CC0633").s().p("A3bBdIAAi5MAu3AAAIAAC5g");
	this.shape_79.setTransform(150,0.75);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#CC0633").s().p("A3bBxIAAjhMAu3AAAIAADhg");
	this.shape_80.setTransform(150,3.825);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#CC0633").s().p("A3bCDIAAkFMAu3AAAIAAEFg");
	this.shape_81.setTransform(150,6.65);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#CC0633").s().p("A3bCUIAAknMAu3AAAIAAEng");
	this.shape_82.setTransform(150,9.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#CC0633").s().p("A3bCjIAAlFMAu3AAAIAAFFg");
	this.shape_83.setTransform(150,11.725);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#CC0633").s().p("A3bCxIAAlhMAu3AAAIAAFhg");
	this.shape_84.setTransform(150,13.95);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#CC0633").s().p("A3bC/IAAl8MAu3AAAIAAF8g");
	this.shape_85.setTransform(150,15.95);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#CC0633").s().p("A3bDKIAAmTMAu3AAAIAAGTg");
	this.shape_86.setTransform(150,17.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#CC0633").s().p("A3bDUIAAmnMAu3AAAIAAGng");
	this.shape_87.setTransform(150,19.325);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#CC0633").s().p("A3bDdIAAm5MAu3AAAIAAG5g");
	this.shape_88.setTransform(150,20.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#CC0633").s().p("A3bDkIAAnHMAu3AAAIAAHHg");
	this.shape_89.setTransform(150,21.85);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#CC0633").s().p("A3bDqIAAnTMAu3AAAIAAHTg");
	this.shape_90.setTransform(150,22.825);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#CC0633").s().p("A3bDvIAAndMAu3AAAIAAHdg");
	this.shape_91.setTransform(150,23.55);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#CC0633").s().p("A3bDyIAAnjMAu3AAAIAAHjg");
	this.shape_92.setTransform(150,24.075);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#CC0633").s().p("A3bD1IAAnpMAu3AAAIAAHpg");
	this.shape_93.setTransform(150,24.4);

	var maskedShapeInstanceList = [this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_77}]},20).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93,p:{y:24.4}}]},1).to({state:[{t:this.shape_93,p:{y:24.5}}]},1).to({state:[]},110).wait(182));

	// Photo_B_W
	this.instance_2 = new lib.gpic2("synched",0);
	this.instance_2.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_2._off = true;
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-2,-2,304,254);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({startPosition:0},18,cjs.Ease.get(1)).to({_off:true},128).wait(182));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(1).to(new cjs.ColorFilter(1,1,1,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(1)).wait(182));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_152 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(152).to({graphics:mask_2_graphics_152,x:150,y:125}).wait(177));

	// CTA
	this.instance_3 = new lib.btn_CTA();
	this.instance_3.setTransform(278.5,237,1,1,0,0,0,83,25.5);
	this.instance_3._off = true;
	var instance_3Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_2];
	this.instance_3.cache(-3,-3,106,38);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(213).to({_off:false},0).to({y:243.3},16,cjs.Ease.get(0.9)).to({_off:true},99).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_2).wait(213).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.9)).wait(1));

	// SFU_Logo
	this.instance_4 = new lib.g_SFULogohorizontal("single",1);
	this.instance_4.setTransform(40.1,-40.9,1,1,0,0,0,0.1,0.1);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(194).to({_off:false},0).to({y:0.1},13,cjs.Ease.get(1)).to({_off:true},121).wait(1));

	// text
	this.instance_5 = new lib.gtext12("synched",0);
	this.instance_5.setTransform(-172.5,148.5);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(180).to({_off:false},0).to({x:-2.5},30,cjs.Ease.get(1)).to({_off:true},118).wait(1));

	// Red_Bg
	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#CC0633").s().p("AgZH6IACvzIAUAAIAAFAIAdAAIAAFAIgTAAIAAFzg");
	this.shape_94.setTransform(-3.425,199.15);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#CC0633").s().p("AhRH6IABvzIA0AAIAAFAIBuAAIAAFEIgVAAIAAFvg");
	this.shape_95.setTransform(2.6,199.15);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#CC0633").s().p("AiHH6IABvzIBSAAIAAFAIC8AAIAAFHIgXAAIAAFsg");
	this.shape_96.setTransform(8.4,199.15);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#CC0633").s().p("Ai8H6IABvzIBwAAIAAFAIEIAAIAAFJIgaAAIAAFqg");
	this.shape_97.setTransform(14,199.15);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#CC0633").s().p("AjvH6IACvzICLAAIAAFAIFSAAIAAFNIgdAAIAAFmg");
	this.shape_98.setTransform(19.425,199.15);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#CC0633").s().p("AkgH6IACvzICmAAIAAFAIGYAAIAAFPIgeAAIAAFkg");
	this.shape_99.setTransform(24.65,199.15);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#CC0633").s().p("AlOH6IABvzIDAAAIAAFAIHcAAIAAFSIggAAIAAFhg");
	this.shape_100.setTransform(29.65,199.15);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#CC0633").s().p("Al8H6IACvzIDZAAIAAFAIIeAAIAAFVIgjAAIAAFeg");
	this.shape_101.setTransform(34.475,199.15);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#CC0633").s().p("AmnH6IABvzIDxAAIAAFAIJdAAIAAFXIgkAAIAAFcg");
	this.shape_102.setTransform(39.125,199.15);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#CC0633").s().p("AnQH6IABvzIEHAAIAAFAIKZAAIAAFZIgmAAIAAFag");
	this.shape_103.setTransform(43.55,199.15);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#CC0633").s().p("An4H6IABvzIEeAAIAAFAILSAAIAAFbIgoAAIAAFYg");
	this.shape_104.setTransform(47.775,199.15);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#CC0633").s().p("AoeH6IABvzIEzAAIAAFAIMJAAIAAFeIgqAAIAAFVg");
	this.shape_105.setTransform(51.825,199.15);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#CC0633").s().p("ApCH6IACvzIFGAAIAAFAIM9AAIAAFgIgsAAIAAFTg");
	this.shape_106.setTransform(55.65,199.15);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#CC0633").s().p("ApkH6IABvzIFaAAIAAFAINuAAIAAFhIgtAAIAAFSg");
	this.shape_107.setTransform(59.3,199.15);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#CC0633").s().p("AqFH6IACvzIFrAAIAAFAIOdAAIAAFjIguAAIAAFQg");
	this.shape_108.setTransform(62.75,199.15);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#CC0633").s().p("AqjH6IACvzIF7AAIAAFAIPKAAIAAFlIgwAAIAAFOg");
	this.shape_109.setTransform(66,199.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#CC0633").s().p("ArAH6IACvzIGMAAIAAFAIPzAAIAAFnIgxAAIAAFMg");
	this.shape_110.setTransform(69.05,199.15);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#CC0633").s().p("AraH6IABvzIGbAAIAAFAIQZAAIAAFpIgyAAIAAFKg");
	this.shape_111.setTransform(71.925,199.15);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#CC0633").s().p("ArzH6IABvzIGpAAIAAFAIQ9AAIAAFqIgzAAIAAFJg");
	this.shape_112.setTransform(74.55,199.15);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#CC0633").s().p("AsKH6IABvzIG1AAIAAFAIRfAAIAAFrIg0AAIAAFIg");
	this.shape_113.setTransform(77.025,199.15);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#CC0633").s().p("AsfH6IABvzIHBAAIAAFAIR+AAIAAFsIg2AAIAAFHg");
	this.shape_114.setTransform(79.3,199.15);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#CC0633").s().p("AszH6IACvzIHLAAIAAFAISaAAIAAFtIg3AAIAAFGg");
	this.shape_115.setTransform(81.375,199.15);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#CC0633").s().p("AtEH6IABvzIHVAAIAAFAISzAAIAAFuIg3AAIAAFFg");
	this.shape_116.setTransform(83.225,199.15);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#CC0633").s().p("AtUH6IABvzIHeAAIAAFAITKAAIAAFvIg4AAIAAFEg");
	this.shape_117.setTransform(84.9,199.15);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#CC0633").s().p("AtiH6IACvzIHlAAIAAFAITeAAIAAFwIg5AAIAAFDg");
	this.shape_118.setTransform(86.375,199.15);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#CC0633").s().p("AtuH6IACvzIHsAAIAAFAITvAAIAAFxIg5AAIAAFCg");
	this.shape_119.setTransform(87.675,199.15);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#CC0633").s().p("At4H6IABvzIHyAAIAAFAIT+AAIAAFxIg6AAIAAFCg");
	this.shape_120.setTransform(88.75,199.15);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#CC0633").s().p("AuAH6IABvzIH3AAIAAFAIUJAAIAAFyIg6AAIAAFBg");
	this.shape_121.setTransform(89.625,199.15);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#CC0633").s().p("AuHH6IACvzIH6AAIAAFAIUTAAIAAFyIg7AAIAAFBg");
	this.shape_122.setTransform(90.325,199.15);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#CC0633").s().p("AuLH6IABvzIH8AAIAAFAIUaAAIAAFzIg6AAIAAFAg");
	this.shape_123.setTransform(90.825,199.15);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#CC0633").s().p("AuOH6IACvzIH9AAIAAFAIUeAAIAAFzIg7AAIAAFAg");
	this.shape_124.setTransform(91.1,199.15);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#CC0633").s().p("AuPH6IACvzIH+AAIAAFAIUfAAIAAFzIg6AAIAAFAg");
	this.shape_125.setTransform(91.2,199.15);

	var maskedShapeInstanceList = [this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_94}]},165).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[]},132).wait(1));

	// Photo_B_W
	this.instance_6 = new lib.Bitmap6();
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(152).to({_off:false},0).to({_off:true},176).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-2, y:-2, w:304, h:254});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:304, h:254});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:19, x:-2, y:-2, w:304, h:254});
	this.filterCacheList.push({instance: this.instance_3, startFrame:213, endFrame:213, x:-3, y:-3, w:106, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-3, y:-3, w:106, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:214, endFrame:229, x:-3, y:-3, w:106, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:230, endFrame:328, x:-3, y:-3, w:106, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:328, endFrame:329, x:-3, y:-3, w:106, h:38});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;