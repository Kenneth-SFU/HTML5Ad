(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"banner_970x250_atlas_1", frames: [[0,252,862,268],[864,252,696,308],[1562,354,200,100],[1844,490,202,51],[1562,252,425,100],[1764,354,280,66],[1764,422,280,66],[1562,490,280,66],[0,0,970,250],[972,0,970,250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_32 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10copy = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["banner_970x250_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.gtext12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_32();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,431,134);


(lib.g_txtSFUMedicalSchool = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(-347.8,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-347.8,0,348,154);


(lib.g_SFULogohorizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.instance = new lib.CachedBmp_28();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_29();
	this.instance_1.setTransform(111.65,24.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// Ico
	this.instance_2 = new lib.CachedBmp_30();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.7,50.3);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_25();
	this.instance.setTransform(13,8.1,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_26();
	this.instance_1.setTransform(13,8.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(13,8.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("As9D/IAAn9IZ7AAIAAH9g");
	this.shape.setTransform(83,25.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("As9j+IZ7AAIAAH9I57AAg");
	this.shape_1.setTransform(83,25.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("As9D/IAAn9IZ7AAIAAH9g");
	this.shape_2.setTransform(83,25.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,168,53);


(lib.g_study_dr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.g_SFULogohorizontal("single",1);
	this.instance.setTransform(40,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// B_W
	this.instance_1 = new lib.Bitmap15();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);


// stage content:
(lib.banner_970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {school:1};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// transition
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape.setTransform(485,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.937)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_1.setTransform(485,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.878)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_2.setTransform(485,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.824)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_3.setTransform(485,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.769)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_4.setTransform(485,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.714)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_5.setTransform(485,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.663)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_6.setTransform(485,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.612)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_7.setTransform(485,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.565)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_8.setTransform(485,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.518)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_9.setTransform(485,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.475)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_10.setTransform(485,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.431)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_11.setTransform(485,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.392)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_12.setTransform(485,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.353)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_13.setTransform(485,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.318)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_14.setTransform(485,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.282)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_15.setTransform(485,125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.251)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_16.setTransform(485,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.22)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_17.setTransform(485,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.192)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_18.setTransform(485,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.165)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_19.setTransform(485,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.137)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_20.setTransform(485,125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.118)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_21.setTransform(485,125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.094)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_22.setTransform(485,125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.075)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_23.setTransform(485,125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.059)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_24.setTransform(485,125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.043)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_25.setTransform(485,125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.027)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_26.setTransform(485,125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.016)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_27.setTransform(485,125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.008)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_28.setTransform(485,125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_29.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[]},1).wait(279));

	// Transition
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(51,51,51,0)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_30.setTransform(485,125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(70,70,70,0.094)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_31.setTransform(485,125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(88,88,88,0.18)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_32.setTransform(485,125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(105,105,105,0.263)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_33.setTransform(485,125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(121,121,121,0.345)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_34.setTransform(485,125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(136,136,136,0.42)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_35.setTransform(485,125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(151,151,151,0.49)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_36.setTransform(485,125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(164,164,164,0.553)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_37.setTransform(485,125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(177,177,177,0.616)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_38.setTransform(485,125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(188,188,188,0.675)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_39.setTransform(485,125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(199,199,199,0.725)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_40.setTransform(485,125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(209,209,209,0.773)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_41.setTransform(485,125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(218,218,218,0.82)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_42.setTransform(485,125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(226,226,226,0.859)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_43.setTransform(485,125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(233,233,233,0.89)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_44.setTransform(485,125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(239,239,239,0.922)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_45.setTransform(485,125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(244,244,244,0.949)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_46.setTransform(485,125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(249,249,249,0.969)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_47.setTransform(485,125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(252,252,252,0.988)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_48.setTransform(485,125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_49.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_30}]},288).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).wait(2));

	// Transition
	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(51,51,51,0)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_50.setTransform(485,125);
	this.shape_50._off = true;

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(75,75,75,0.118)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_51.setTransform(485,125);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(97,97,97,0.227)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_52.setTransform(485,125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(118,118,118,0.329)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_53.setTransform(485,125);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(137,137,137,0.424)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_54.setTransform(485,125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(155,155,155,0.51)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_55.setTransform(485,125);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(172,172,172,0.592)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_56.setTransform(485,125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(187,187,187,0.667)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_57.setTransform(485,125);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(200,200,200,0.733)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_58.setTransform(485,125);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(213,213,213,0.792)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_59.setTransform(485,125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(223,223,223,0.843)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_60.setTransform(485,125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(233,233,233,0.89)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_61.setTransform(485,125);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(240,240,240,0.929)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_62.setTransform(485,125);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(247,247,247,0.961)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_63.setTransform(485,125);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(252,252,252,0.984)").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_64.setTransform(485,125);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");
	this.shape_65.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_50}]},130).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[]},1).wait(151));
	this.timeline.addTween(cjs.Tween.get(this.shape_50).wait(130).to({_off:false},0).wait(12).to({_off:true},1).wait(166));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_52 = new cjs.Graphics().p("A/PTiMAAAgnDMA+fAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_graphics_52,x:200,y:125}).wait(257));

	// Text_SFU_Medical_School
	this.instance = new lib.g_txtSFUMedicalSchool("synched",0);
	this.instance.setTransform(565.05,179,1,1,0,0,0,-162.3,77);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(52).to({_off:false},0).to({x:240.75},18,cjs.Ease.get(1)).to({_off:true},88).wait(151));

	// Red_Bg__Animate__Mask_ (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_34 = new cjs.Graphics().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AkPTiMAAAgnDIIfAAMAAAAnDg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AnhTiMAAAgnDIPDAAMAAAAnDg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AqlTiMAAAgnDIVKAAMAAAAnDg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AtbTiMAAAgnDIa3AAMAAAAnDg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AwETiMAAAgnDMAgIAAAMAAAAnDg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AyfTiMAAAgnDMAk/AAAMAAAAnDg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A0sTiMAAAgnDMApZAAAMAAAAnDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A2sTiMAAAgnDMAtaAAAMAAAAnDg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A4fTiMAAAgnDMAw/AAAMAAAAnDg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A6FTiMAAAgnDMA0KAAAMAAAAnDg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A7cTiMAAAgnDMA25AAAMAAAAnDg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A8mTiMAAAgnDMA5NAAAMAAAAnDg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A9jTiMAAAgnDMA7HAAAMAAAAnDg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A+STiMAAAgnDMA8lAAAMAAAAnDg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A+0TiMAAAgnDMA9pAAAMAAAAnDg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A/ITiMAAAgnDMA+RAAAMAAAAnDg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A/PTiMAAAgnDMA+fAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(34).to({graphics:mask_1_graphics_34,x:-5,y:125}).wait(1).to({graphics:mask_1_graphics_35,x:18.4,y:125}).wait(1).to({graphics:mask_1_graphics_36,x:40.4,y:125}).wait(1).to({graphics:mask_1_graphics_37,x:60.95,y:125}).wait(1).to({graphics:mask_1_graphics_38,x:80.125,y:125}).wait(1).to({graphics:mask_1_graphics_39,x:97.85,y:125}).wait(1).to({graphics:mask_1_graphics_40,x:114.175,y:125}).wait(1).to({graphics:mask_1_graphics_41,x:129.075,y:125}).wait(1).to({graphics:mask_1_graphics_42,x:142.55,y:125}).wait(1).to({graphics:mask_1_graphics_43,x:154.6,y:125}).wait(1).to({graphics:mask_1_graphics_44,x:165.25,y:125}).wait(1).to({graphics:mask_1_graphics_45,x:174.475,y:125}).wait(1).to({graphics:mask_1_graphics_46,x:182.275,y:125}).wait(1).to({graphics:mask_1_graphics_47,x:188.65,y:125}).wait(1).to({graphics:mask_1_graphics_48,x:193.625,y:125}).wait(1).to({graphics:mask_1_graphics_49,x:197.15,y:125}).wait(1).to({graphics:mask_1_graphics_50,x:199.275,y:125}).wait(1).to({graphics:mask_1_graphics_51,x:200,y:125}).wait(258));

	// SFU_Logo
	this.instance_1 = new lib.g_SFULogohorizontal("single",0);
	this.instance_1.setTransform(40,0.1,1,1,0,0,0,0.1,0.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({_off:true},124).wait(151));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_1 = new cjs.Graphics().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_1,x:485,y:125.025}).wait(308));

	// Red_Bg__Animate_
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#CC0633").s().p("AgxTiMAAAgnDIBjAAMAAAAnDg");
	this.shape_66.setTransform(-5,125);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#CC0633").s().p("AkPTiMAAAgnDIIfAAMAAAAnDg");
	this.shape_67.setTransform(18.4,125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CC0633").s().p("AnhTiMAAAgnDIPDAAMAAAAnDg");
	this.shape_68.setTransform(40.4,125);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CC0633").s().p("AqlTiMAAAgnDIVKAAMAAAAnDg");
	this.shape_69.setTransform(60.95,125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#CC0633").s().p("AtbTiMAAAgnDIa3AAMAAAAnDg");
	this.shape_70.setTransform(80.125,125);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#CC0633").s().p("AwETiMAAAgnDMAgIAAAMAAAAnDg");
	this.shape_71.setTransform(97.85,125);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#CC0633").s().p("AyfTiMAAAgnDMAk/AAAMAAAAnDg");
	this.shape_72.setTransform(114.175,125);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#CC0633").s().p("A0sTiMAAAgnDMApZAAAMAAAAnDg");
	this.shape_73.setTransform(129.075,125);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#CC0633").s().p("A2sTiMAAAgnDMAtaAAAMAAAAnDg");
	this.shape_74.setTransform(142.55,125);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#CC0633").s().p("A4fTiMAAAgnDMAw/AAAMAAAAnDg");
	this.shape_75.setTransform(154.6,125);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#CC0633").s().p("A6FTiMAAAgnDMA0KAAAMAAAAnDg");
	this.shape_76.setTransform(165.25,125);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#CC0633").s().p("A7cTiMAAAgnDMA25AAAMAAAAnDg");
	this.shape_77.setTransform(174.475,125);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CC0633").s().p("A8mTiMAAAgnDMA5NAAAMAAAAnDg");
	this.shape_78.setTransform(182.275,125);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#CC0633").s().p("A9jTiMAAAgnDMA7HAAAMAAAAnDg");
	this.shape_79.setTransform(188.65,125);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#CC0633").s().p("A+STiMAAAgnDMA8lAAAMAAAAnDg");
	this.shape_80.setTransform(193.625,125);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#CC0633").s().p("A+0TiMAAAgnDMA9pAAAMAAAAnDg");
	this.shape_81.setTransform(197.15,125);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#CC0633").s().p("A/ITiMAAAgnDMA+RAAAMAAAAnDg");
	this.shape_82.setTransform(199.275,125);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#CC0633").s().p("A/PTiMAAAgnDMA+fAAAMAAAAnDg");
	this.shape_83.setTransform(200,125);

	var maskedShapeInstanceList = [this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_66}]},34).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[]},107).wait(151));

	// Photo
	this.instance_2 = new lib.g_study_dr("single",0);
	this.instance_2.setTransform(485,125.5,1,1,0,0,0,485,125.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true},157).wait(151));

	// Mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_162 = new cjs.Graphics().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(162).to({graphics:mask_3_graphics_162,x:485,y:125}).wait(147));

	// CTA
	this.instance_3 = new lib.btn_CTA();
	this.instance_3.setTransform(858,212.5,1,1,0,0,0,83,25.5);
	this.instance_3._off = true;
	var instance_3Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_1];
	this.instance_3.cache(-3,-3,172,57);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(198).to({_off:false},0).to({y:202.5},16,cjs.Ease.get(0.9)).to({_off:true},93).wait(2));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_1).wait(198).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.9)).wait(2));

	// SFU_Logo
	this.instance_4 = new lib.g_SFULogohorizontal("single",1);
	this.instance_4.setTransform(40,-48.95,1,1,0,0,0,0.1,0);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(183).to({_off:false},0).to({regY:0.1,y:1.1},17,cjs.Ease.get(1)).to({_off:true},107).wait(2));

	// Text
	this.instance_5 = new lib.gtext12("synched",0);
	this.instance_5.setTransform(-440,98);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(195).to({_off:false},0).to({x:-4.25},19,cjs.Ease.get(0.9)).to({_off:true},93).wait(2));

	// REd_Bg
	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#CC0633").s().p("AhPKjIAA1FIBZAAIAAJhIBGAAIAALkg");
	this.shape_84.setTransform(-12,161);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#CC0633").s().p("AjTKjIAA1FIE0AAIAAJhIB0AAIAALkg");
	this.shape_85.setTransform(2.5,161);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#CC0633").s().p("AlUKjIAA1FIIJAAIAAJhICgAAIAALkg");
	this.shape_86.setTransform(16.575,161);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#CC0633").s().p("AnPKjIAA1FILWAAIAAJhIDJAAIAALkg");
	this.shape_87.setTransform(30.15,161);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#CC0633").s().p("ApHKjIAA1FIOcAAIAAJhIDzAAIAALkg");
	this.shape_88.setTransform(43.225,161);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#CC0633").s().p("Aq6KjIAA1FIRbAAIAAJhIEaAAIAALkg");
	this.shape_89.setTransform(55.85,161);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#CC0633").s().p("AspKjIAA1FIUTAAIAAJhIFAAAIAALkg");
	this.shape_90.setTransform(67.975,161);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#CC0633").s().p("AuTKjIAA1FIXDAAIAAJhIFkAAIAALkg");
	this.shape_91.setTransform(79.625,161);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#CC0633").s().p("Av5KjIAA1FIZsAAIAAJhIGHAAIAALkg");
	this.shape_92.setTransform(90.825,161);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#CC0633").s().p("AxbKjIAA1FIcOAAIAAJhIGpAAIAALkg");
	this.shape_93.setTransform(101.55,161);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#CC0633").s().p("Ay5KjIAA1FIeqAAIAAJhIHJAAIAALkg");
	this.shape_94.setTransform(111.775,161);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#CC0633").s().p("A0RKjIAA1FMAg8AAAIAAJhIHnAAIAALkg");
	this.shape_95.setTransform(121.55,161);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#CC0633").s().p("A1mKjIAA1FMAjJAAAIAAJhIIEAAIAALkg");
	this.shape_96.setTransform(130.825,161);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#CC0633").s().p("A23KjIAA1FMAlPAAAIAAJhIIgAAIAALkg");
	this.shape_97.setTransform(139.625,161);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#CC0633").s().p("A4DKjIAA1FMAnNAAAIAAJhII6AAIAALkg");
	this.shape_98.setTransform(147.975,161);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#CC0633").s().p("A5KKjIAA1FMApDAAAIAAJhIJTAAIAALkg");
	this.shape_99.setTransform(155.8,161);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#CC0633").s().p("A6OKjIAA1FMAqzAAAIAAJhIJqAAIAALkg");
	this.shape_100.setTransform(163.175,161);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#CC0633").s().p("A7NKjIAA1FMAscAAAIAAJhIJ/AAIAALkg");
	this.shape_101.setTransform(170.075,161);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#CC0633").s().p("A8HKjIAA1FMAt8AAAIAAJhIKTAAIAALkg");
	this.shape_102.setTransform(176.525,161);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#CC0633").s().p("A8+KjIAA1FMAvXAAAIAAJhIKmAAIAALkg");
	this.shape_103.setTransform(182.475,161);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#CC0633").s().p("A9wKjIAA1FMAwpAAAIAAJhIK3AAIAALkg");
	this.shape_104.setTransform(187.95,161);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#CC0633").s().p("A+dKjIAA1FMAx1AAAIAAJhILGAAIAALkg");
	this.shape_105.setTransform(192.925,161);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#CC0633").s().p("A/HKjIAA1FMAy6AAAIAAJhILVAAIAALkg");
	this.shape_106.setTransform(197.45,161);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#CC0633").s().p("A/sKjIAA1FMAz3AAAIAAJhILiAAIAALkg");
	this.shape_107.setTransform(201.5,161);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#CC0633").s().p("EggMAKjIAA1FMA0sAAAIAAJhILtAAIAALkg");
	this.shape_108.setTransform(205.1,161);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#CC0633").s().p("EggoAKjIAA1FMA1bAAAIAAJhIL2AAIAALkg");
	this.shape_109.setTransform(208.175,161);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#CC0633").s().p("EghAAKjIAA1FMA2DAAAIAAJhIL+AAIAALkg");
	this.shape_110.setTransform(210.8,161);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#CC0633").s().p("EghUAKjIAA1FMA2kAAAIAAJhIMFAAIAALkg");
	this.shape_111.setTransform(212.925,161);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#CC0633").s().p("EghjAKjIAA1FMA28AAAIAAJhIMLAAIAALkg");
	this.shape_112.setTransform(214.6,161);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#CC0633").s().p("EghuAKjIAA1FMA3PAAAIAAJhIMOAAIAALkg");
	this.shape_113.setTransform(215.8,161);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#CC0633").s().p("Egh0AKjIAA1FMA3ZAAAIAAJhIMQAAIAALkg");
	this.shape_114.setTransform(216.525,161);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#CC0633").s().p("Egh3AKjIAA1FMA3dAAAIAAJhIMSAAIAALkg");
	this.shape_115.setTransform(216.75,161);

	var maskedShapeInstanceList = [this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_84}]},183).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[]},93).wait(2));

	// Mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_162 = new cjs.Graphics().p("EhLxAAyIAAhjMCXjAAAIAABjg");
	var mask_4_graphics_163 = new cjs.Graphics().p("EhLxAChIAAlCMCXjAAAIAAFCg");
	var mask_4_graphics_164 = new cjs.Graphics().p("EhLxAEMIAAoXMCXjAAAIAAIXg");
	var mask_4_graphics_165 = new cjs.Graphics().p("EhLxAFwIAArgMCXjAAAIAALgg");
	var mask_4_graphics_166 = new cjs.Graphics().p("EhLxAHPIAAueMCXjAAAIAAOeg");
	var mask_4_graphics_167 = new cjs.Graphics().p("EhLxAIqIAAxSMCXjAAAIAARSg");
	var mask_4_graphics_168 = new cjs.Graphics().p("EhLxAJ+IAAz7MCXjAAAIAAT7g");
	var mask_4_graphics_169 = new cjs.Graphics().p("EhLxALNIAA2ZMCXjAAAIAAWZg");
	var mask_4_graphics_170 = new cjs.Graphics().p("EhLxAMWIAA4rMCXjAAAIAAYrg");
	var mask_4_graphics_171 = new cjs.Graphics().p("EhLxANaIAA6zMCXjAAAIAAazg");
	var mask_4_graphics_172 = new cjs.Graphics().p("EhLxAOZIAA8xMCXjAAAIAAcxg");
	var mask_4_graphics_173 = new cjs.Graphics().p("EhLxAPSIAA+jMCXjAAAIAAejg");
	var mask_4_graphics_174 = new cjs.Graphics().p("EhLxAQGMAAAggLMCXjAAAMAAAAgLg");
	var mask_4_graphics_175 = new cjs.Graphics().p("EhLxAQ0MAAAghnMCXjAAAMAAAAhng");
	var mask_4_graphics_176 = new cjs.Graphics().p("EhLxARdMAAAgi4MCXjAAAMAAAAi4g");
	var mask_4_graphics_177 = new cjs.Graphics().p("EhLxASAMAAAgj/MCXjAAAMAAAAj/g");
	var mask_4_graphics_178 = new cjs.Graphics().p("EhLxASeMAAAgk7MCXjAAAMAAAAk7g");
	var mask_4_graphics_179 = new cjs.Graphics().p("EhLxAS2MAAAglsMCXjAAAMAAAAlsg");
	var mask_4_graphics_180 = new cjs.Graphics().p("EhLxATJMAAAgmRMCXjAAAMAAAAmRg");
	var mask_4_graphics_181 = new cjs.Graphics().p("EhLxATXMAAAgmtMCXjAAAMAAAAmtg");
	var mask_4_graphics_182 = new cjs.Graphics().p("EhLxATfMAAAgm9MCXjAAAMAAAAm9g");
	var mask_4_graphics_183 = new cjs.Graphics().p("EhLxATiMAAAgnDMCXjAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(162).to({graphics:mask_4_graphics_162,x:485,y:-5}).wait(1).to({graphics:mask_4_graphics_163,x:485,y:7.1}).wait(1).to({graphics:mask_4_graphics_164,x:485,y:18.575}).wait(1).to({graphics:mask_4_graphics_165,x:485,y:29.5}).wait(1).to({graphics:mask_4_graphics_166,x:485,y:39.8}).wait(1).to({graphics:mask_4_graphics_167,x:485,y:49.55}).wait(1).to({graphics:mask_4_graphics_168,x:485,y:58.675}).wait(1).to({graphics:mask_4_graphics_169,x:485,y:67.225}).wait(1).to({graphics:mask_4_graphics_170,x:485,y:75.175}).wait(1).to({graphics:mask_4_graphics_171,x:485,y:82.55}).wait(1).to({graphics:mask_4_graphics_172,x:485,y:89.325}).wait(1).to({graphics:mask_4_graphics_173,x:485,y:95.525}).wait(1).to({graphics:mask_4_graphics_174,x:485,y:101.125}).wait(1).to({graphics:mask_4_graphics_175,x:485,y:106.125}).wait(1).to({graphics:mask_4_graphics_176,x:485,y:110.55}).wait(1).to({graphics:mask_4_graphics_177,x:485,y:114.4}).wait(1).to({graphics:mask_4_graphics_178,x:485,y:117.65}).wait(1).to({graphics:mask_4_graphics_179,x:485,y:120.3}).wait(1).to({graphics:mask_4_graphics_180,x:485,y:122.35}).wait(1).to({graphics:mask_4_graphics_181,x:485,y:123.825}).wait(1).to({graphics:mask_4_graphics_182,x:485,y:124.725}).wait(1).to({graphics:mask_4_graphics_183,x:485,y:125}).wait(126));

	// Pic_Dad_Girl
	this.instance_6 = new lib.Bitmap10copy();
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(162).to({_off:false},0).to({_off:true},145).wait(2));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_3, startFrame:198, endFrame:198, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:199, endFrame:214, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:215, endFrame:307, x:-3, y:-3, w:172, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:307, endFrame:309, x:-3, y:-3, w:172, h:57});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,970,250);
// library properties:
lib.properties = {
	id: 'B8909188F943443AB461DBFA97228CEF',
	width: 970,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/banner_970x250_atlas_1.png", id:"banner_970x250_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B8909188F943443AB461DBFA97228CEF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;