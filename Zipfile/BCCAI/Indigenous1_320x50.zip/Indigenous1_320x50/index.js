(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[450,242,435,106],[0,122,511,106],[0,230,448,106],[513,134,500,106],[528,0,451,132],[322,350,260,56],[584,350,260,56],[322,408,260,56],[0,0,526,120],[0,338,320,80]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_32 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.g_title_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_32();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,217.5,53);


(lib.g_title_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,255.5,53);


(lib.g_title_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_30();
	this.instance.setTransform(-223.9,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-223.9,0,224,53);


(lib.g_title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(-250.05,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,0,250,53);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.instance = new lib.CachedBmp_28();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyvHCIAAuDMAlfAAAIAAODg");
	this.shape.setTransform(120,37.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-7.5,240,90);


(lib.g_pic02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Project_Support
	this.instance = new lib.Bitmap6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,80);


(lib.g_pic01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(0,0,0.67,0.67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,352.4,80.4);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_25();
	this.instance.setTransform(0,1.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_26();
	this.instance_1.setTransform(0,1.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(0,1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(2));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape.setTransform(65,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AqJifIUTAAIAAE/I0TAAg");
	this.shape_1.setTransform(65,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_2.setTransform(65,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,132,34);


// stage content:
(lib.Indigenous1_320x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E6E6E6").ss(1,1,1).p("A4/j5MAx/AAAIAAHzMgx/AAAg");
	this.shape.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(555));

	// Mask_Color
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_1.setTransform(160,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.102)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_2.setTransform(160,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.2)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_3.setTransform(160,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.29)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_4.setTransform(160,25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_5.setTransform(160,25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.459)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_6.setTransform(160,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.533)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_7.setTransform(160,25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.6)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_8.setTransform(160,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.667)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_9.setTransform(160,25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.722)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_10.setTransform(160,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.776)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_11.setTransform(160,25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.824)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_12.setTransform(160,25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.863)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_13.setTransform(160,25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.902)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_14.setTransform(160,25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.929)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_15.setTransform(160,25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.957)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_16.setTransform(160,25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.976)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_17.setTransform(160,25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.988)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_18.setTransform(160,25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.996)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_19.setTransform(160,25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_20.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},242).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},272).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).wait(2));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4/D6IAAnzMAx/AAAIAAHzg");
	mask.setTransform(160,25);

	// btn_CTA
	this.instance = new lib.btn_CTA();
	this.instance.setTransform(65,-1);
	this.instance._off = true;
	var instanceFilter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-3,-3,136,38);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(474).to({_off:false},0).to({y:9},19,cjs.Ease.get(1)).to({_off:true},61).wait(1));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(474).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(1)).wait(1));

	// Text_4
	this.instance_1 = new lib.g_title_4("synched",0);
	this.instance_1.setTransform(-29.95,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_1._off = true;
	var instance_1Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-2,-2,222,57);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(387).to({_off:false},0).to({x:108.55},19,cjs.Ease.get(0.8)).wait(44).to({startPosition:0},0).to({x:-79.95},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(90));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(387).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(44).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(90));

	// Text_4_Bg
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhjD7IAAnwIAAgFIDHAAIAAAFIAAENIh3AAIAADjg");
	this.shape_21.setTransform(-10,25.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AitD7IAAn1IFbAAIAAESIjPAAIAADjg");
	this.shape_22.setTransform(-1.05,25.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Aj0D7IAAn1IHpAAIAAESIkkAAIAADjg");
	this.shape_23.setTransform(7.5,25.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ak4D7IAAn1IJxAAIAAESIl1AAIAADjg");
	this.shape_24.setTransform(15.725,25.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Al5D7IAAn1ILzAAIAAESInDAAIAADjg");
	this.shape_25.setTransform(23.625,25.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Am4D7IAAn1INxAAIAAESIoOAAIAADjg");
	this.shape_26.setTransform(31.125,25.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AnzD7IAAn1IPnAAIAAESIpVAAIAADjg");
	this.shape_27.setTransform(38.3,25.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AosD7IAAn1IRZAAIAAESIqZAAIAADjg");
	this.shape_28.setTransform(45.125,25.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AphD7IAAn1ITDAAIAAESIrYAAIAADjg");
	this.shape_29.setTransform(51.6,25.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AqUD7IAAn1IUpAAIAAESIsWAAIAADjg");
	this.shape_30.setTransform(57.725,25.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ArED7IAAn1IWJAAIAAESItPAAIAADjg");
	this.shape_31.setTransform(63.5,25.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("ArwD7IAAn1IXhAAIAAESIuEAAIAADjg");
	this.shape_32.setTransform(68.875,25.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AsaD7IAAn1IY1AAIAAESIu2AAIAADjg");
	this.shape_33.setTransform(73.95,25.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AtBD7IAAn1IaDAAIAAESIvlAAIAADjg");
	this.shape_34.setTransform(78.675,25.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AtlD7IAAn1IbLAAIAAESIwQAAIAADjg");
	this.shape_35.setTransform(83.025,25.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AuGD7IAAn1IcOAAIAAESIw4AAIAADjg");
	this.shape_36.setTransform(87,25.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AulD7IAAn1IdLAAIAAESIxcAAIAADjg");
	this.shape_37.setTransform(90.675,25.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AvAD7IAAn1IeBAAIAAESIx9AAIAADjg");
	this.shape_38.setTransform(93.95,25.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AvYD7IAAn1IeyAAIAAESIyaAAIAADjg");
	this.shape_39.setTransform(96.9,25.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AvuD7IAAn1IfdAAIAAESIy0AAIAADjg");
	this.shape_40.setTransform(99.5,25.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AwBD7IAAn1MAgDAAAIAAESIzKAAIAADjg");
	this.shape_41.setTransform(101.75,25.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AwQD7IAAn1MAghAAAIAAESIzdAAIAADjg");
	this.shape_42.setTransform(103.65,25.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AwdD7IAAn1MAg7AAAIAAESIzsAAIAADjg");
	this.shape_43.setTransform(105.2,25.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AwnD7IAAnwIAAgFMAhPAAAIAAAFIAAENIz4AAIAADjg");
	this.shape_44.setTransform(106.375,25.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Au9D7IAAn1Id8AAIAAESIx6AAIAADjg");
	this.shape_45.setTransform(93.65,25.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AtaD7IAAn1Ia1AAIAAESIwDAAIAADjg");
	this.shape_46.setTransform(81.65,25.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("Ar9D7IAAn1IX7AAIAAESIuTAAIAADjg");
	this.shape_47.setTransform(70.375,25.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AqlD7IAAn1IVLAAIAAESIsqAAIAADjg");
	this.shape_48.setTransform(59.825,25.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("ApUD7IAAn1ISpAAIAAESIrJAAIAADjg");
	this.shape_49.setTransform(50,25.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AoJD7IAAn1IQTAAIAAESIpvAAIAADjg");
	this.shape_50.setTransform(40.925,25.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AnDD7IAAn1IOHAAIAAESIocAAIAADjg");
	this.shape_51.setTransform(32.55,25.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AmED7IAAn1IMJAAIAAESInQAAIAADjg");
	this.shape_52.setTransform(24.9,25.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AlLD7IAAn1IKXAAIAAESImMAAIAADjg");
	this.shape_53.setTransform(18,25.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AkYD7IAAn1IIxAAIAAESIlPAAIAADjg");
	this.shape_54.setTransform(11.825,25.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AjqD7IAAn1IHVAAIAAESIkYAAIAADjg");
	this.shape_55.setTransform(6.35,25.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AjDD7IAAn1IGHAAIAAESIjpAAIAADjg");
	this.shape_56.setTransform(1.625,25.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AiiD7IAAn1IFFAAIAAESIjCAAIAADjg");
	this.shape_57.setTransform(-2.375,25.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AiHD7IAAn1IEPAAIAAESIiiAAIAADjg");
	this.shape_58.setTransform(-5.625,25.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AhyD7IAAn1IDlAAIAAESIiIAAIAADjg");
	this.shape_59.setTransform(-8.2,25.1);

	var maskedShapeInstanceList = [this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_21}]},378).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_44}]},56).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_21}]},1).to({state:[]},1).wait(81));

	// Text_3
	this.instance_2 = new lib.g_title_3("synched",0);
	this.instance_2.setTransform(-29.95,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_2._off = true;
	var instance_2Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_3];
	this.instance_2.cache(-2,-2,260,57);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(287).to({_off:false},0).to({x:108.55},19,cjs.Ease.get(0.8)).wait(51).to({startPosition:0},0).to({x:-79.95},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(183));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_3).wait(287).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(51).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(183));

	// Text_3_Bg
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgRD7IAAnwIAAgFIARAAIAAAFIAADhIARAAIAAEPg");
	this.shape_60.setTransform(-3.25,25.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AhxD7IAAn1ICLAAIAADmIBYAAIAAEPg");
	this.shape_61.setTransform(6.775,25.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AjND7IAAn1IEBAAIAADmICaAAIAAEPg");
	this.shape_62.setTransform(16.375,25.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AkmD7IAAn1IFyAAIAADmIDbAAIAAEPg");
	this.shape_63.setTransform(25.6,25.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Al7D7IAAn1IHeAAIAADmIEZAAIAAEPg");
	this.shape_64.setTransform(34.45,25.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AnMD7IAAn1IJGAAIAADmIFTAAIAAEPg");
	this.shape_65.setTransform(42.875,25.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AoZD7IAAn1IKoAAIAADmIGLAAIAAEPg");
	this.shape_66.setTransform(50.925,25.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("ApjD7IAAn1IMGAAIAADmIHBAAIAAEPg");
	this.shape_67.setTransform(58.55,25.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AqpD7IAAn1INgAAIAADmIHzAAIAAEPg");
	this.shape_68.setTransform(65.825,25.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("ArrD7IAAn1IO0AAIAADmIIjAAIAAEPg");
	this.shape_69.setTransform(72.675,25.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AspD7IAAn1IQDAAIAADmIJQAAIAAEPg");
	this.shape_70.setTransform(79.15,25.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AtjD7IAAn1IRNAAIAADmIJ6AAIAAEPg");
	this.shape_71.setTransform(85.225,25.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AuaD7IAAn1ISTAAIAADmIKiAAIAAEPg");
	this.shape_72.setTransform(90.875,25.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AvMD7IAAn1ITTAAIAADmILHAAIAAEPg");
	this.shape_73.setTransform(96.15,25.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Av7D7IAAn1IUPAAIAADmILpAAIAAEPg");
	this.shape_74.setTransform(101.05,25.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AwnD7IAAn1IVHAAIAADmIMIAAIAAEPg");
	this.shape_75.setTransform(105.525,25.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AxOD7IAAn1IV5AAIAADmIMkAAIAAEPg");
	this.shape_76.setTransform(109.65,25.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AxyD7IAAn1IWmAAIAADmIM/AAIAAEPg");
	this.shape_77.setTransform(113.325,25.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AyRD7IAAn1IXOAAIAADmINWAAIAAEPg");
	this.shape_78.setTransform(116.65,25.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AytD7IAAn1IXyAAIAADmINpAAIAAEPg");
	this.shape_79.setTransform(119.55,25.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AzGD7IAAn1IYRAAIAADmIN8AAIAAEPg");
	this.shape_80.setTransform(122.075,25.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AzaD7IAAn1IYrAAIAADmIOKAAIAAEPg");
	this.shape_81.setTransform(124.2,25.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AzrD7IAAn1IZAAAIAADmIOXAAIAAEPg");
	this.shape_82.setTransform(125.925,25.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("Az4D7IAAnwIAAgFIZRAAIAAAFIAADhIOgAAIAAEPg");
	this.shape_83.setTransform(127.25,25.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AxuD7IAAn1IWhAAIAADmIM8AAIAAEPg");
	this.shape_84.setTransform(112.975,25.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AvtD7IAAn1IT9AAIAADmILeAAIAAEPg");
	this.shape_85.setTransform(99.525,25.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AtzD7IAAn1IRhAAIAADmIKGAAIAAEPg");
	this.shape_86.setTransform(86.875,25.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AsBD7IAAn1IPQAAIAADmIIzAAIAAEPg");
	this.shape_87.setTransform(75.05,25.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AqYD7IAAn1INKAAIAADmIHnAAIAAEPg");
	this.shape_88.setTransform(64.05,25.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("Ao1D7IAAn1ILMAAIAADmIGgAAIAAEPg");
	this.shape_89.setTransform(53.85,25.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AnbD7IAAn1IJZAAIAADmIFeAAIAAEPg");
	this.shape_90.setTransform(44.475,25.1);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AmJD7IAAn1IHxAAIAADmIEiAAIAAEPg");
	this.shape_91.setTransform(35.9,25.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("Ak+D7IAAn1IGRAAIAADmIDtAAIAAEPg");
	this.shape_92.setTransform(28.15,25.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Aj8D7IAAn1IE9AAIAADmIC8AAIAAEPg");
	this.shape_93.setTransform(21.225,25.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AjBD7IAAn1IDyAAIAADmICRAAIAAEPg");
	this.shape_94.setTransform(15.1,25.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AiOD7IAAn1ICwAAIAADmIBtAAIAAEPg");
	this.shape_95.setTransform(9.8,25.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AhjD7IAAn1IB6AAIAADmIBNAAIAAEPg");
	this.shape_96.setTransform(5.325,25.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Ag/D7IAAn1IBMAAIAADmIAzAAIAAEPg");
	this.shape_97.setTransform(1.65,25.1);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgkD7IAAn1IAqAAIAADmIAfAAIAAEPg");
	this.shape_98.setTransform(-1.2,25.1);

	var maskedShapeInstanceList = [this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_60}]},278).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},60).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_60}]},1).to({state:[]},1).wait(177));

	// Photo_02
	this.instance_3 = new lib.g_pic02("single",0);
	this.instance_3.setTransform(0,-5);
	this.instance_3._off = true;
	var instance_3Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_4];
	this.instance_3.cache(-2,-2,324,84);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(263).to({_off:false},0).to({y:-25},39,cjs.Ease.get(0.8)).to({_off:true},252).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_4).wait(263).to(new cjs.ColorFilter(1,1,1,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 39,cjs.Ease.get(0.8)).wait(1));

	// Text_2
	this.instance_4 = new lib.g_title_2("synched",0);
	this.instance_4.setTransform(661.35,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_4._off = true;
	var instance_4Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_5];
	this.instance_4.cache(-226,-2,228,57);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(175).to({_off:false},0).to({x:433.3},21,cjs.Ease.get(0.8)).wait(46).to({startPosition:0},0).to({x:661.35},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(298));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_5).wait(175).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 21,cjs.Ease.get(0.8)).wait(46).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(298));

	// Text_2_Bg
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgED7IAAjoIhfAAIAAkIIAAgFIDHAAIAAAFIAAHwg");
	this.shape_99.setTransform(330,25.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgLD7IAAjoIilAAIAAkNIFhAAIAAH1g");
	this.shape_100.setTransform(320.8,25.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgTD7IAAjoIjmAAIAAkNIHzAAIAAH1g");
	this.shape_101.setTransform(311.975,25.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgZD7IAAjoIknAAIAAkNIKBAAIAAH1g");
	this.shape_102.setTransform(303.525,25.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AggD7IAAjoIljAAIAAkNIMHAAIAAH1g");
	this.shape_103.setTransform(295.4,25.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgmD7IAAjoImeAAIAAkNIOJAAIAAH1g");
	this.shape_104.setTransform(287.675,25.1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgsD7IAAjoInVAAIAAkNIQDAAIAAH1g");
	this.shape_105.setTransform(280.3,25.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgxD7IAAjoIoLAAIAAkNIR5AAIAAH1g");
	this.shape_106.setTransform(273.275,25.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Ag2D7IAAjoIo9AAIAAkNITnAAIAAH1g");
	this.shape_107.setTransform(266.6,25.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("Ag8D7IAAjoIprAAIAAkNIVPAAIAAH1g");
	this.shape_108.setTransform(260.325,25.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AhAD7IAAjoIqZAAIAAkNIWzAAIAAH1g");
	this.shape_109.setTransform(254.375,25.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AhFD7IAAjoIrCAAIAAkNIYPAAIAAH1g");
	this.shape_110.setTransform(248.825,25.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AhJD7IAAjoIrqAAIAAkNIZmAAIAAH1g");
	this.shape_111.setTransform(243.6,25.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AhND7IAAjoIsOAAIAAkNIa3AAIAAH1g");
	this.shape_112.setTransform(238.775,25.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AhQD7IAAjoIswAAIAAkNIcBAAIAAH1g");
	this.shape_113.setTransform(234.275,25.1);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AhTD7IAAjoItQAAIAAkNIdHAAIAAH1g");
	this.shape_114.setTransform(230.175,25.1);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AhWD7IAAjoItsAAIAAkNIeFAAIAAH1g");
	this.shape_115.setTransform(226.425,25.1);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AhZD7IAAjoIuFAAIAAkNIe9AAIAAH1g");
	this.shape_116.setTransform(223.025,25.1);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AhbD7IAAjoIudAAIAAkNIfxAAIAAH1g");
	this.shape_117.setTransform(220,25.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AheD7IAAjoIuwAAIAAkNMAgdAAAIAAH1g");
	this.shape_118.setTransform(217.325,25.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AhfD7IAAjoIvCAAIAAkNMAhDAAAIAAH1g");
	this.shape_119.setTransform(215,25.1);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AhgD7IAAjoIvRAAIAAkNMAhjAAAIAAH1g");
	this.shape_120.setTransform(213.05,25.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AhiD7IAAjoIvcAAIAAkNMAh9AAAIAAH1g");
	this.shape_121.setTransform(211.475,25.1);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AhjD7IAAjoIvlAAIAAkIIAAgFMAiSAAAIAAAFIAAHwg");
	this.shape_122.setTransform(210.25,25.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AhZD7IAAjoIuDAAIAAkNIe4AAIAAH1g");
	this.shape_123.setTransform(223.35,25.1);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AhPD7IAAjoIsmAAIAAkNIbrAAIAAH1g");
	this.shape_124.setTransform(235.7,25.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AhGD7IAAjoIrOAAIAAkNIYpAAIAAH1g");
	this.shape_125.setTransform(247.3,25.1);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("Ag9D7IAAjoIp9AAIAAkNIV0AAIAAH1g");
	this.shape_126.setTransform(258.15,25.1);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("Ag1D7IAAjoIowAAIAAkNITLAAIAAH1g");
	this.shape_127.setTransform(268.25,25.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgtD7IAAjoInrAAIAAkNIQxAAIAAH1g");
	this.shape_128.setTransform(277.6,25.1);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgnD7IAAjoImpAAIAAkNIOhAAIAAH1g");
	this.shape_129.setTransform(286.225,25.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AghD7IAAjoIltAAIAAkNIMdAAIAAH1g");
	this.shape_130.setTransform(294.075,25.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgbD7IAAjoIk4AAIAAkNIKnAAIAAH1g");
	this.shape_131.setTransform(301.2,25.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgWD7IAAjoIkIAAIAAkNII9AAIAAH1g");
	this.shape_132.setTransform(307.55,25.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgSD7IAAjoIjdAAIAAkNIHfAAIAAH1g");
	this.shape_133.setTransform(313.175,25.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgOD7IAAjoIi5AAIAAkNIGPAAIAAH1g");
	this.shape_134.setTransform(318.025,25.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgLD7IAAjoIiZAAIAAkNIFJAAIAAH1g");
	this.shape_135.setTransform(322.15,25.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgID7IAAjoIiAAAIAAkNIERAAIAAH1g");
	this.shape_136.setTransform(325.5,25.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgGD7IAAjoIhtAAIAAkNIDnAAIAAH1g");
	this.shape_137.setTransform(328.125,25.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("Ag7D7IAAjoIw1AAIAAkIIAAgFMAjiAAAIAAAFIAAHwg");
	this.shape_138.setTransform(329.9806,25.1,0.0879,1);

	var maskedShapeInstanceList = [this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_99}]},171).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_122}]},52).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[]},1).wait(292));

	// Text_1
	this.instance_5 = new lib.g_title_1("synched",0);
	this.instance_5.setTransform(681.35,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_5._off = true;
	var instance_5Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_6];
	this.instance_5.cache(-252,-2,254,57);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79).to({_off:false},0).to({x:433.3},21,cjs.Ease.get(0.8)).wait(49).to({startPosition:0},0).to({x:681.35},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(391));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_6).wait(79).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 21,cjs.Ease.get(0.8)).wait(49).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(391));

	// Text_1_A_Bg
	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgqD7IAAjoIg5AAIAAkIIAAgFIDHAAIAAAFIAAHwg");
	this.shape_139.setTransform(332.4,25.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AhPD7IAAjoIhrAAIAAkNIF1AAIAAH1g");
	this.shape_140.setTransform(322.05,25.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AhzD7IAAjoIiaAAIAAkNIIaAAIAAH1g");
	this.shape_141.setTransform(312.1,25.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AiVD7IAAjoIjHAAIAAkNIK5AAIAAH1g");
	this.shape_142.setTransform(302.55,25.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("Ai2D7IAAjoIjzAAIAAkNINTAAIAAH1g");
	this.shape_143.setTransform(293.4,25.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AjVD7IAAjoIkcAAIAAkNIPjAAIAAH1g");
	this.shape_144.setTransform(284.675,25.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AjzD7IAAjoIlEAAIAAkNIRuAAIAAH1g");
	this.shape_145.setTransform(276.35,25.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AkPD7IAAjoIlpAAIAAkNITyAAIAAH1g");
	this.shape_146.setTransform(268.45,25.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AkqD7IAAjoImNAAIAAkNIVvAAIAAH1g");
	this.shape_147.setTransform(260.925,25.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AlDD7IAAjoImvAAIAAkNIXlAAIAAH1g");
	this.shape_148.setTransform(253.825,25.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AlbD7IAAjoInPAAIAAkNIZVAAIAAH1g");
	this.shape_149.setTransform(247.15,25.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AlyD7IAAjoInsAAIAAkNIa9AAIAAH1g");
	this.shape_150.setTransform(240.875,25.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AmHD7IAAjoIoJAAIAAkNIchAAIAAH1g");
	this.shape_151.setTransform(235,25.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AmbD7IAAjoIoiAAIAAkNId7AAIAAH1g");
	this.shape_152.setTransform(229.55,25.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AmsD7IAAjoIo7AAIAAkNIfPAAIAAH1g");
	this.shape_153.setTransform(224.475,25.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("Am9D7IAAjoIpRAAIAAkNMAgdAAAIAAH1g");
	this.shape_154.setTransform(219.85,25.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AnMD7IAAjoIplAAIAAkNMAhjAAAIAAH1g");
	this.shape_155.setTransform(215.6,25.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AnaD7IAAjoIp3AAIAAkNMAijAAAIAAH1g");
	this.shape_156.setTransform(211.775,25.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AnmD7IAAjoIqIAAIAAkNMAjdAAAIAAH1g");
	this.shape_157.setTransform(208.35,25.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AnxD7IAAjoIqWAAIAAkNMAkPAAAIAAH1g");
	this.shape_158.setTransform(205.325,25.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("An6D7IAAjoIqjAAIAAkNMAk7AAAIAAH1g");
	this.shape_159.setTransform(202.75,25.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AoCD7IAAjoIqtAAIAAkNMAlfAAAIAAH1g");
	this.shape_160.setTransform(200.55,25.1);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AoJD7IAAjoIq1AAIAAkNMAl9AAAIAAH1g");
	this.shape_161.setTransform(198.775,25.1);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AoND7IAAjoIq8AAIAAkIIAAgFMAmTAAAIAAAFIAAHwg");
	this.shape_162.setTransform(197.375,25.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AnZD7IAAjoIp1AAIAAkNMAidAAAIAAH1g");
	this.shape_163.setTransform(212.15,25.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AmnD7IAAjoIozAAIAAkNIe1AAIAAH1g");
	this.shape_164.setTransform(226.075,25.1);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("Al4D7IAAjoIn1AAIAAkNIbbAAIAAH1g");
	this.shape_165.setTransform(239.15,25.1);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AlMD7IAAjoIm7AAIAAkNIYPAAIAAH1g");
	this.shape_166.setTransform(251.375,25.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AkjD7IAAjoImFAAIAAkNIVRAAIAAH1g");
	this.shape_167.setTransform(262.775,25.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("Aj9D7IAAjoIlTAAIAAkNIShAAIAAH1g");
	this.shape_168.setTransform(273.325,25.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AjbD7IAAjoIkkAAIAAkNIP/AAIAAH1g");
	this.shape_169.setTransform(283.025,25.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("Ai7D7IAAjoIj6AAIAAkNINrAAIAAH1g");
	this.shape_170.setTransform(291.9,25.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AieD7IAAjoIjUAAIAAkNILlAAIAAH1g");
	this.shape_171.setTransform(299.9,25.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AiFD7IAAjoIixAAIAAkNIJtAAIAAH1g");
	this.shape_172.setTransform(307.075,25.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AhuD7IAAjoIiUAAIAAkNIIEAAIAAH1g");
	this.shape_173.setTransform(313.4,25.1);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AhaD7IAAjoIh6AAIAAkNIGoAAIAAH1g");
	this.shape_174.setTransform(318.9,25.1);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AhKD7IAAjoIhjAAIAAkNIFbAAIAAH1g");
	this.shape_175.setTransform(323.55,25.1);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("Ag8D7IAAjoIhRAAIAAkNIEbAAIAAH1g");
	this.shape_176.setTransform(327.325,25.1);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AgxD7IAAjoIhEAAIAAkNIDrAAIAAH1g");
	this.shape_177.setTransform(330.3,25.1);

	var maskedShapeInstanceList = [this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149,this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.shape_164,this.shape_165,this.shape_166,this.shape_167,this.shape_168,this.shape_169,this.shape_170,this.shape_171,this.shape_172,this.shape_173,this.shape_174,this.shape_175,this.shape_176,this.shape_177];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_139}]},75).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_162}]},55).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_139}]},1).to({state:[]},1).wait(385));

	// Logo_SOC
	this.instance_6 = new lib.g_SFU_SOC_Logo("single",0);
	this.instance_6.setTransform(0.05,-41,0.6,0.6,0,0,0,0.1,-0.1);
	var instance_6Filter_7 = new cjs.ColorFilter(0,0,0,1,255,255,255,0);
	this.instance_6.filters = [instance_6Filter_7];
	this.instance_6.cache(-2,-9,244,94);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regY:0.1,y:4.55},24,cjs.Ease.get(1)).wait(24).to({startPosition:0},0).to({regX:0,x:-173.95,y:5.45},26,cjs.Ease.get(1)).to({_off:true},82).wait(399));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_7).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(1)).wait(24).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 26,cjs.Ease.get(1)).wait(399));

	// Photo00__bak
	this.instance_7 = new lib.g_pic01("single",0);
	this.instance_7.setTransform(144,-30);
	var instance_7Filter_8 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_7.filters = [instance_7Filter_8];
	this.instance_7.cache(-2,-2,356,84);

	this.ikNode_1 = new lib.g_pic01("single",0);
	this.ikNode_1.name = "ikNode_1";
	this.ikNode_1.setTransform(144,-10);
	this.ikNode_1._off = true;

	var maskedShapeInstanceList = [this.instance_7,this.ikNode_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true,y:-10},24,cjs.Ease.get(0.8)).wait(531));
	this.timeline.addTween(cjs.Tween.get(this.ikNode_1).to({_off:false},24,cjs.Ease.get(0.8)).wait(24).to({startPosition:0},0).to({x:-30},26,cjs.Ease.get(1)).to({_off:true},188).wait(293));
	this.timeline.addTween(cjs.Tween.get(instance_7Filter_8).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 24,cjs.Ease.get(0.8)).wait(531));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance, startFrame:474, endFrame:474, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance, startFrame:0, endFrame:0, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance, startFrame:475, endFrame:493, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance, startFrame:494, endFrame:554, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance, startFrame:554, endFrame:555, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:387, endFrame:387, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_1, startFrame:388, endFrame:406, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_1, startFrame:450, endFrame:450, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_1, startFrame:451, endFrame:464, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:287, endFrame:287, x:-2, y:-2, w:260, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:260, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:288, endFrame:306, x:-2, y:-2, w:260, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:357, endFrame:357, x:-2, y:-2, w:260, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:358, endFrame:371, x:-2, y:-2, w:260, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:263, endFrame:263, x:-2, y:-2, w:324, h:84});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:324, h:84});
	this.filterCacheList.push({instance: this.instance_3, startFrame:264, endFrame:302, x:-2, y:-2, w:324, h:84});
	this.filterCacheList.push({instance: this.instance_4, startFrame:175, endFrame:175, x:-226, y:-2, w:228, h:57});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-226, y:-2, w:228, h:57});
	this.filterCacheList.push({instance: this.instance_4, startFrame:176, endFrame:196, x:-226, y:-2, w:228, h:57});
	this.filterCacheList.push({instance: this.instance_4, startFrame:242, endFrame:242, x:-226, y:-2, w:228, h:57});
	this.filterCacheList.push({instance: this.instance_4, startFrame:243, endFrame:256, x:-226, y:-2, w:228, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:79, endFrame:79, x:-252, y:-2, w:254, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-252, y:-2, w:254, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:80, endFrame:100, x:-252, y:-2, w:254, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:149, endFrame:149, x:-252, y:-2, w:254, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:150, endFrame:163, x:-252, y:-2, w:254, h:57});
	this.filterCacheList.push({instance: this.instance_6, startFrame:1, endFrame:24, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:25, endFrame:48, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:49, endFrame:74, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:75, endFrame:156, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:156, endFrame:555, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_7, startFrame:1, endFrame:24, x:-2, y:-2, w:356, h:84});
	this.filterCacheList.push({instance: this.instance_7, startFrame:0, endFrame:0, x:-2, y:-2, w:356, h:84});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(159,24,162,27);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 320,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;