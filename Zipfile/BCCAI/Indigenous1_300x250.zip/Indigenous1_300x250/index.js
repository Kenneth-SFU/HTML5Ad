(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[630,0,298,172],[0,504,590,120],[302,374,517,120],[302,252,577,120],[347,0,281,229],[630,174,260,56],[592,496,260,56],[592,554,260,56],[0,0,345,250],[0,252,300,250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_40 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.iStock1331256321 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.iStock1421334722 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.g_title_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,149,86);


(lib.g_title_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_39();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,295,60);


(lib.g_title_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_38();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,258.5,60);


(lib.g_title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,288.5,60);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(-4.2,0,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AtjKBIAA0BIbHAAIAAUBg");
	this.shape.setTransform(61.6,64.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.2,0,173.6,128.2);


(lib.g_pic02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Project_Support
	this.instance = new lib.iStock1421334722();
	this.instance.setTransform(0,0,1,1,0,0,180);

	this.instance_1 = new lib.iStock1421334722();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300,0,600,250);


(lib.g_pic01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.iStock1331256321();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,345,250);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_33();
	this.instance.setTransform(0,1.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_34();
	this.instance_1.setTransform(0,1.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_35();
	this.instance_2.setTransform(0,1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(2));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape.setTransform(65,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AqJifIUTAAIAAE/I0TAAg");
	this.shape_1.setTransform(65,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_2.setTransform(65,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,132,34);


// stage content:
(lib.Indigenous1_300x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E6E6E6").ss(1,1,1).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(450));

	// Mask_Color
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_1.setTransform(150,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.102)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_2.setTransform(150,125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.2)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_3.setTransform(150,125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.29)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_4.setTransform(150,125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.376)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_5.setTransform(150,125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.459)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_6.setTransform(150,125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.533)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_7.setTransform(150,125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.6)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_8.setTransform(150,125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.667)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_9.setTransform(150,125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.722)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_10.setTransform(150,125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.776)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_11.setTransform(150,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.824)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_12.setTransform(150,125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.863)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_13.setTransform(150,125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.902)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_14.setTransform(150,125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.929)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_15.setTransform(150,125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.957)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_16.setTransform(150,125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.976)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_17.setTransform(150,125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.988)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_18.setTransform(150,125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.996)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_19.setTransform(150,125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_20.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},190).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},219).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).wait(2));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	mask.setTransform(150,125);

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("single",1);
	this.instance.setTransform(19.95,0,0.8,0.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(231).to({_off:false},0).to({alpha:1},19).to({_off:true},199).wait(1));

	// btn_CTA
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(170,218);
	this.instance_1._off = true;
	var instance_1Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_1];
	this.instance_1.cache(-3,-3,136,38);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(350).to({_off:false},0).to({y:208},14,cjs.Ease.get(1)).to({_off:true},85).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_1).wait(350).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(1)).wait(1));

	// Text_4
	this.instance_2 = new lib.g_title_4("synched",0);
	this.instance_2.setTransform(-29.95,178.8,1,1,0,0,0,111.3,31.4);
	this.instance_2._off = true;
	var instance_2Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_2];
	this.instance_2.cache(-2,-2,153,90);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(333).to({_off:false},0).to({x:108.55},16,cjs.Ease.get(0.8)).to({_off:true},100).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_2).wait(333).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.8)).wait(1));

	// Text_4_Bg
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgSGgIAAs6IAAgFIAbAAIAAAFIAAEEIAKAAIAAEwIgWAAIAAEGg");
	this.shape_21.setTransform(-3.125,188.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhjGgIAAs/ICMAAIAAEJIA7AAIAAEwIhIAAIAAEGg");
	this.shape_22.setTransform(5.625,188.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AiwGgIAAs/ID3AAIAAEJIBqAAIAAEwIh3AAIAAEGg");
	this.shape_23.setTransform(13.825,188.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Aj3GgIAAs/IFaAAIAAEJICVAAIAAEwIiiAAIAAEGg");
	this.shape_24.setTransform(21.475,188.65);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ak6GgIAAs/IG3AAIAAEJIC+AAIAAEwIjKAAIAAEGg");
	this.shape_25.setTransform(28.6,188.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Al3GgIAAs/IIMAAIAAEJIDjAAIAAEwIjvAAIAAEGg");
	this.shape_26.setTransform(35.2,188.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AmwGgIAAs/IJcAAIAAEJIEFAAIAAEwIkSAAIAAEGg");
	this.shape_27.setTransform(41.275,188.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AnkGgIAAs/IKkAAIAAEJIElAAIAAEwIkyAAIAAEGg");
	this.shape_28.setTransform(46.825,188.65);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AoTGgIAAs/ILlAAIAAEJIFBAAIAAEwIlNAAIAAEGg");
	this.shape_29.setTransform(51.8,188.65);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("Ao8GgIAAs/IMfAAIAAEJIFaAAIAAEwIlnAAIAAEGg");
	this.shape_30.setTransform(56.275,188.65);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AphGgIAAs/INSAAIAAEJIFxAAIAAEwIl9AAIAAEGg");
	this.shape_31.setTransform(60.2,188.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AqAGgIAAs/IN9AAIAAEJIGEAAIAAEwImQAAIAAEGg");
	this.shape_32.setTransform(63.6,188.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AqbGgIAAs/IOjAAIAAEJIGUAAIAAEwImhAAIAAEGg");
	this.shape_33.setTransform(66.475,188.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AqxGgIAAs/IPBAAIAAEJIGiAAIAAEwImuAAIAAEGg");
	this.shape_34.setTransform(68.8,188.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("ArCGgIAAs/IPZAAIAAEJIGsAAIAAEwIm4AAIAAEGg");
	this.shape_35.setTransform(70.6,188.65);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("ArOGgIAAs6IAAgFIPqAAIAAAFIAAEEIGzAAIAAEwInAAAIAAEGg");
	this.shape_36.setTransform(71.875,188.65);

	var maskedShapeInstanceList = [this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_21}]},325).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[]},109).wait(1));

	// Text_3
	this.instance_3 = new lib.g_title_3("synched",0);
	this.instance_3.setTransform(-29.95,203.8,1,1,0,0,0,111.3,31.4);
	this.instance_3._off = true;
	var instance_3Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_3];
	this.instance_3.cache(-2,-2,299,64);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(240).to({_off:false},0).to({x:108.55},16,cjs.Ease.get(0.8)).wait(47).to({startPosition:0},0).to({x:-116.45},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(132));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_3).wait(240).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.8)).wait(47).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(132));

	// Text_3_Bg
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgUEdIAAo0IAAgFIARAAIAAAFIAAECIAYAAIAAEyg");
	this.shape_37.setTransform(-2.875,200.525);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("Ai9EdIAAo5IDoAAIAAEHICTAAIAAEyg");
	this.shape_38.setTransform(14.575,200.525);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AlbEdIAAo5IGyAAIAAEHIEFAAIAAEyg");
	this.shape_39.setTransform(30.95,200.525);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AnvEdIAAo5IJvAAIAAEHIFwAAIAAEyg");
	this.shape_40.setTransform(46.25,200.525);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Ap5EdIAAo5IMgAAIAAEHIHTAAIAAEyg");
	this.shape_41.setTransform(60.475,200.525);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("Ar4EdIAAo5IPCAAIAAEHIIvAAIAAEyg");
	this.shape_42.setTransform(73.65,200.525);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AttEdIAAo5IRYAAIAAEHIKDAAIAAEyg");
	this.shape_43.setTransform(85.775,200.525);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AvYEdIAAo5ITgAAIAAEHILRAAIAAEyg");
	this.shape_44.setTransform(96.825,200.525);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Aw5EdIAAo5IVcAAIAAEHIMWAAIAAEyg");
	this.shape_45.setTransform(106.8,200.525);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AyPEdIAAo5IXKAAIAAEHINVAAIAAEyg");
	this.shape_46.setTransform(115.725,200.525);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AzbEdIAAo5IYrAAIAAEHIOMAAIAAEyg");
	this.shape_47.setTransform(123.575,200.525);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("A0cEdIAAo5IZ+AAIAAEHIO7AAIAAEyg");
	this.shape_48.setTransform(130.375,200.525);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("A1UEdIAAo5IbGAAIAAEHIPiAAIAAEyg");
	this.shape_49.setTransform(136.1,200.525);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("A2AEdIAAo5Ib/AAIAAEHIQCAAIAAEyg");
	this.shape_50.setTransform(140.75,200.525);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("A2jEdIAAo5IcrAAIAAEHIQdAAIAAEyg");
	this.shape_51.setTransform(144.35,200.525);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("A28EdIAAo0IAAgFIdLAAIAAAFIAAECIQuAAIAAEyg");
	this.shape_52.setTransform(146.875,200.525);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("A0dEdIAAo5IaAAAIAAEHIO7AAIAAEyg");
	this.shape_53.setTransform(130.5,200.525);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AyIEdIAAo5IXBAAIAAEHINQAAIAAEyg");
	this.shape_54.setTransform(115.05,200.525);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Av8EdIAAo5IUOAAIAAEHILrAAIAAEyg");
	this.shape_55.setTransform(100.55,200.525);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("At5EdIAAo5IRnAAIAAEHIKMAAIAAEyg");
	this.shape_56.setTransform(86.975,200.525);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Ar/EdIAAo5IPKAAIAAEHII1AAIAAEyg");
	this.shape_57.setTransform(74.35,200.525);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AqNEdIAAo5IM6AAIAAEHIHhAAIAAEyg");
	this.shape_58.setTransform(62.65,200.525);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AolEdIAAo5IK0AAIAAEHIGXAAIAAEyg");
	this.shape_59.setTransform(51.875,200.525);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AnHEdIAAo5II8AAIAAEHIFSAAIAAEyg");
	this.shape_60.setTransform(42.05,200.525);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AlwEdIAAo5IHNAAIAAEHIEVAAIAAEyg");
	this.shape_61.setTransform(33.15,200.525);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AkkEdIAAo5IFsAAIAAEHIDdAAIAAEyg");
	this.shape_62.setTransform(25.2,200.525);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AjgEdIAAo5IEVAAIAAEHICsAAIAAEyg");
	this.shape_63.setTransform(18.175,200.525);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AilEdIAAo5IDKAAIAAEHICBAAIAAEyg");
	this.shape_64.setTransform(12.1,200.525);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AhzEdIAAo5ICJAAIAAEHIBeAAIAAEyg");
	this.shape_65.setTransform(6.95,200.525);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AhKEdIAAo5IBVAAIAAEHIBAAAIAAEyg");
	this.shape_66.setTransform(2.75,200.525);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgrEdIAAo5IAtAAIAAEHIAqAAIAAEyg");
	this.shape_67.setTransform(-0.525,200.525);

	var maskedShapeInstanceList = [this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_37}]},232).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_52}]},60).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_37}]},1).to({state:[]},1).wait(126));

	// Photo_02
	this.instance_4 = new lib.g_pic02("single",0);
	this.instance_4.setTransform(10,0);
	this.instance_4._off = true;
	var instance_4Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_4];
	this.instance_4.cache(-302,-2,604,254);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(211).to({_off:false},0).to({x:0},20,cjs.Ease.get(0.8)).to({_off:true},218).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_4).wait(211).to(new cjs.ColorFilter(1,1,1,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 20,cjs.Ease.get(0.8)).wait(1));

	// Logo_SOC
	this.instance_5 = new lib.g_SFU_SOC_Logo("single",1);
	this.instance_5.setTransform(19.95,-92.5,0.8,0.8);
	this.instance_5._off = true;
	var instance_5Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_5];
	this.instance_5.cache(-27,-2,178,132);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(34).to({_off:false},0).to({y:0},19,cjs.Ease.get(0.8)).to({_off:true},157).wait(240));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_5).wait(34).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(240));

	// Text_2
	this.instance_6 = new lib.g_title_2("synched",0);
	this.instance_6.setTransform(-29.95,203.8,1,1,0,0,0,111.3,31.4);
	this.instance_6._off = true;
	var instance_6Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_6.filters = [instance_6Filter_6];
	this.instance_6.cache(-2,-2,263,64);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(127).to({_off:false},0).to({x:108.55},16,cjs.Ease.get(0.8)).wait(47).to({startPosition:0},0).to({x:-116.45},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(245));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_6).wait(127).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.8)).wait(47).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(245));

	// Text_2_Bg
	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgiEdIAAo0IAAgFIBFAAIAAAFIAAEuIgpAAIAAEGg");
	this.shape_68.setTransform(-4.5,200.525);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AixEdIAAo5IFjAAIAAEzIisAAIAAEGg");
	this.shape_69.setTransform(10.725,200.525);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Ak3EdIAAo5IJvAAIAAEzIkmAAIAAEGg");
	this.shape_70.setTransform(25.025,200.525);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("Am1EdIAAo5INrAAIAAEzImYAAIAAEGg");
	this.shape_71.setTransform(38.375,200.525);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AopEdIAAo5IRTAAIAAEzIoCAAIAAEGg");
	this.shape_72.setTransform(50.825,200.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AqVEdIAAo5IUrAAIAAEzIpkAAIAAEGg");
	this.shape_73.setTransform(62.325,200.525);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Ar4EdIAAo5IXxAAIAAEzIq+AAIAAEGg");
	this.shape_74.setTransform(72.9,200.525);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AtTEdIAAo5IanAAIAAEzIsRAAIAAEGg");
	this.shape_75.setTransform(82.55,200.525);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AulEdIAAo5IdLAAIAAEzItbAAIAAEGg");
	this.shape_76.setTransform(91.275,200.525);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AvuEdIAAo5IfdAAIAAEzIueAAIAAEGg");
	this.shape_77.setTransform(99.075,200.525);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AwvEdIAAo5MAheAAAIAAEzIvXAAIAAEGg");
	this.shape_78.setTransform(105.9,200.525);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AxmEdIAAo5MAjNAAAIAAEzIwKAAIAAEGg");
	this.shape_79.setTransform(111.825,200.525);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AyVEdIAAo5MAkrAAAIAAEzIw1AAIAAEGg");
	this.shape_80.setTransform(116.825,200.525);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("Ay8EdIAAo5MAl5AAAIAAEzIxZAAIAAEGg");
	this.shape_81.setTransform(120.9,200.525);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AzZEdIAAo5MAmzAAAIAAEzIxzAAIAAEGg");
	this.shape_82.setTransform(124.025,200.525);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AzuEdIAAo0IAAgFMAndAAAIAAAFIAAEuIyGAAIAAEGg");
	this.shape_83.setTransform(126.25,200.525);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AxnEdIAAo5MAjPAAAIAAEzIwLAAIAAEGg");
	this.shape_84.setTransform(111.95,200.525);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AvpEdIAAo5IfTAAIAAEzIuZAAIAAEGg");
	this.shape_85.setTransform(98.475,200.525);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AtxEdIAAo5IbkAAIAAEzIstAAIAAEGg");
	this.shape_86.setTransform(85.8,200.525);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AsDEdIAAo5IYHAAIAAEzIrIAAIAAEGg");
	this.shape_87.setTransform(73.95,200.525);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AqbEdIAAo5IU3AAIAAEzIpqAAIAAEGg");
	this.shape_88.setTransform(62.925,200.525);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("Ao7EdIAAo5IR3AAIAAEzIoSAAIAAEGg");
	this.shape_89.setTransform(52.7,200.525);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AnjEdIAAo5IPHAAIAAEzInDAAIAAEGg");
	this.shape_90.setTransform(43.3,200.525);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AmSEdIAAo5IMlAAIAAEzIl5AAIAAEGg");
	this.shape_91.setTransform(34.725,200.525);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AlJEdIAAo5IKTAAIAAEzIk3AAIAAEGg");
	this.shape_92.setTransform(26.975,200.525);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AkIEdIAAo5IIRAAIAAEzIj7AAIAAEGg");
	this.shape_93.setTransform(20.025,200.525);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AjOEdIAAo5IGdAAIAAEzIjHAAIAAEGg");
	this.shape_94.setTransform(13.9,200.525);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AidEdIAAo5IE7AAIAAEzIiaAAIAAEGg");
	this.shape_95.setTransform(8.575,200.525);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AhzEdIAAo5IDnAAIAAEzIh0AAIAAEGg");
	this.shape_96.setTransform(4.075,200.525);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AhQEdIAAo5IChAAIAAEzIhTAAIAAEGg");
	this.shape_97.setTransform(0.4,200.525);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("Ag1EdIAAo5IBrAAIAAEzIg7AAIAAEGg");
	this.shape_98.setTransform(-2.45,200.525);

	var maskedShapeInstanceList = [this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_68}]},119).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},60).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_68}]},1).to({state:[]},1).wait(239));

	// Text_1
	this.instance_7 = new lib.g_title_1("synched",0);
	this.instance_7.setTransform(-29.95,203.8,1,1,0,0,0,111.3,31.4);
	this.instance_7._off = true;
	var instance_7Filter_7 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_7.filters = [instance_7Filter_7];
	this.instance_7.cache(-2,-2,293,64);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(32).to({_off:false},0).to({x:108.55},19,cjs.Ease.get(0.8)).wait(47).to({startPosition:0},0).to({x:-116.45},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(337));
	this.timeline.addTween(cjs.Tween.get(instance_7Filter_7).wait(32).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(47).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(337));

	// Text_1_Bg
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgiEdIAAo0IAAgFIBFAAIAAAFIAAEuIgpAAIAAEGg");
	this.shape_99.setTransform(-4.5,200.525);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AifEdIAAo5IE/AAIAAEzIhtAAIAAEGg");
	this.shape_100.setTransform(8.775,200.525);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AkXEdIAAo5IIvAAIAAEzIitAAIAAEGg");
	this.shape_101.setTransform(21.425,200.525);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AmIEdIAAo5IMRAAIAAEzIjpAAIAAEGg");
	this.shape_102.setTransform(33.425,200.525);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AnzEdIAAo5IPoAAIAAEzIkiAAIAAEGg");
	this.shape_103.setTransform(44.8,200.525);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("ApZEdIAAo5ISzAAIAAEzIlYAAIAAEGg");
	this.shape_104.setTransform(55.525,200.525);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("Aq4EdIAAo5IVxAAIAAEzImKAAIAAEGg");
	this.shape_105.setTransform(65.625,200.525);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AsREdIAAo5IYjAAIAAEzIm5AAIAAEGg");
	this.shape_106.setTransform(75.075,200.525);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AtlEdIAAo5IbLAAIAAEzInmAAIAAEGg");
	this.shape_107.setTransform(83.925,200.525);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AuyEdIAAo5IdlAAIAAEzIoPAAIAAEGg");
	this.shape_108.setTransform(92.1,200.525);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("Av5EdIAAo5If0AAIAAEzIo2AAIAAEGg");
	this.shape_109.setTransform(99.65,200.525);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("Aw7EdIAAo5MAh3AAAIAAEzIpYAAIAAEGg");
	this.shape_110.setTransform(106.575,200.525);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("Ax2EdIAAo5MAjtAAAIAAEzIp4AAIAAEGg");
	this.shape_111.setTransform(112.85,200.525);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AyrEdIAAo5MAlXAAAIAAEzIqTAAIAAEGg");
	this.shape_112.setTransform(118.475,200.525);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AzaEdIAAo5MAm2AAAIAAEzIqtAAIAAEGg");
	this.shape_113.setTransform(123.5,200.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("A0EEdIAAo5MAoJAAAIAAEzIrDAAIAAEGg");
	this.shape_114.setTransform(127.875,200.525);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("A0nEdIAAo5MApPAAAIAAEzIrVAAIAAEGg");
	this.shape_115.setTransform(131.625,200.525);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("A1FEdIAAo5MAqKAAAIAAEzIrkAAIAAEGg");
	this.shape_116.setTransform(134.7,200.525);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("A1cEdIAAo5MAq5AAAIAAEzIryAAIAAEGg");
	this.shape_117.setTransform(137.175,200.525);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("A1tEdIAAo0IAAgFMArbAAAIAAAFIAAEuIr6AAIAAEGg");
	this.shape_118.setTransform(139,200.525);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AzZEdIAAo5MAmzAAAIAAEzIqsAAIAAEGg");
	this.shape_119.setTransform(123.325,200.525);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AxNEdIAAo5MAibAAAIAAEzIphAAIAAEGg");
	this.shape_120.setTransform(108.5,200.525);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AvKEdIAAo5IeVAAIAAEzIocAAIAAEGg");
	this.shape_121.setTransform(94.625,200.525);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AtPEdIAAo5IafAAIAAEzInaAAIAAEGg");
	this.shape_122.setTransform(81.6,200.525);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("ArdEdIAAo5IW6AAIAAEzImdAAIAAEGg");
	this.shape_123.setTransform(69.5,200.525);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("ApzEdIAAo5ITnAAIAAEzIlmAAIAAEGg");
	this.shape_124.setTransform(58.275,200.525);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AoSEdIAAo5IQkAAIAAEzIkxAAIAAEGg");
	this.shape_125.setTransform(47.95,200.525);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("Am4EdIAAo5INyAAIAAEzIkDAAIAAEGg");
	this.shape_126.setTransform(38.55,200.525);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AloEdIAAo5ILRAAIAAEzIjYAAIAAEGg");
	this.shape_127.setTransform(30.05,200.525);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AkgEdIAAo5IJBAAIAAEzIixAAIAAEGg");
	this.shape_128.setTransform(22.4,200.525);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AjgEdIAAo5IHCAAIAAEzIiQAAIAAEGg");
	this.shape_129.setTransform(15.7,200.525);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AiqEdIAAo5IFVAAIAAEzIhzAAIAAEGg");
	this.shape_130.setTransform(9.85,200.525);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("Ah7EdIAAo5ID3AAIAAEzIhZAAIAAEGg");
	this.shape_131.setTransform(4.9,200.525);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AhVEdIAAo5ICrAAIAAEzIhGAAIAAEGg");
	this.shape_132.setTransform(0.875,200.525);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("Ag3EdIAAo5IBvAAIAAEzIg1AAIAAEGg");
	this.shape_133.setTransform(-2.25,200.525);

	var maskedShapeInstanceList = [this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_99}]},23).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_118}]},60).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_99}]},1).to({state:[]},1).wait(331));

	// Photo00__bak
	this.instance_8 = new lib.g_pic01("single",0);
	this.instance_8.setTransform(-44,0);
	var instance_8Filter_8 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_8.filters = [instance_8Filter_8];
	this.instance_8.cache(-2,-2,349,254);

	this.ikNode_1 = new lib.g_pic01("single",0);
	this.ikNode_1.name = "ikNode_1";

	var maskedShapeInstanceList = [this.instance_8,this.ikNode_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8}]}).to({state:[{t:this.ikNode_1}]},22).to({state:[]},188).wait(240));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true,x:0},22,cjs.Ease.get(0.8)).wait(428));
	this.timeline.addTween(cjs.Tween.get(instance_8Filter_8).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 22,cjs.Ease.get(0.8)).wait(428));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_1, startFrame:350, endFrame:350, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:351, endFrame:364, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:365, endFrame:449, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:449, endFrame:450, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_2, startFrame:333, endFrame:333, x:-2, y:-2, w:153, h:90});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:153, h:90});
	this.filterCacheList.push({instance: this.instance_2, startFrame:334, endFrame:349, x:-2, y:-2, w:153, h:90});
	this.filterCacheList.push({instance: this.instance_3, startFrame:240, endFrame:240, x:-2, y:-2, w:299, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:299, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:241, endFrame:256, x:-2, y:-2, w:299, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:303, endFrame:303, x:-2, y:-2, w:299, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:304, endFrame:317, x:-2, y:-2, w:299, h:64});
	this.filterCacheList.push({instance: this.instance_4, startFrame:211, endFrame:211, x:-302, y:-2, w:604, h:254});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-302, y:-2, w:604, h:254});
	this.filterCacheList.push({instance: this.instance_4, startFrame:212, endFrame:231, x:-302, y:-2, w:604, h:254});
	this.filterCacheList.push({instance: this.instance_5, startFrame:34, endFrame:34, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_5, startFrame:35, endFrame:53, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_5, startFrame:54, endFrame:210, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_5, startFrame:210, endFrame:450, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_6, startFrame:127, endFrame:127, x:-2, y:-2, w:263, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-2, w:263, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:128, endFrame:143, x:-2, y:-2, w:263, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:190, endFrame:190, x:-2, y:-2, w:263, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:191, endFrame:204, x:-2, y:-2, w:263, h:64});
	this.filterCacheList.push({instance: this.instance_7, startFrame:32, endFrame:32, x:-2, y:-2, w:293, h:64});
	this.filterCacheList.push({instance: this.instance_7, startFrame:0, endFrame:0, x:-2, y:-2, w:293, h:64});
	this.filterCacheList.push({instance: this.instance_7, startFrame:33, endFrame:51, x:-2, y:-2, w:293, h:64});
	this.filterCacheList.push({instance: this.instance_7, startFrame:98, endFrame:98, x:-2, y:-2, w:293, h:64});
	this.filterCacheList.push({instance: this.instance_7, startFrame:99, endFrame:112, x:-2, y:-2, w:293, h:64});
	this.filterCacheList.push({instance: this.instance_8, startFrame:1, endFrame:22, x:-2, y:-2, w:349, h:254});
	this.filterCacheList.push({instance: this.instance_8, startFrame:0, endFrame:0, x:-2, y:-2, w:349, h:254});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149,124,152,127);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FAFAFA",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;