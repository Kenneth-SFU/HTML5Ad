(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[442,166,435,106],[0,134,440,106],[0,242,401,106],[0,0,452,132],[725,274,260,56],[725,332,260,56],[403,336,260,56],[403,274,320,60],[454,0,320,164]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_7 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Pic01 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Pic02 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.g_title_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,217.5,53);


(lib.g_title_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_6();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,220,53);


(lib.g_title_1_A = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_8();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200.5,53);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.instance = new lib.CachedBmp_4();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyvHCIAAuDMAlfAAAIAAODg");
	this.shape.setTransform(120,37.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-7.5,240,90);


(lib.g_pic04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Tomato
	this.instance = new lib.Pic02();
	this.instance.setTransform(2,0,1,1,0,0,180);

	this.instance_1 = new lib.Pic02();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-318,0,638,164);


(lib.g_pic00 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Pic01();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,320,60);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(0,1.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(0,1.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_3();
	this.instance_2.setTransform(0,1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(2));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape.setTransform(65,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AqJifIUTAAIAAE/I0TAAg");
	this.shape_1.setTransform(65,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_2.setTransform(65,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,132,34);


// stage content:
(lib.Farmer_320x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4/D6IAAnzMAx/AAAIAAHzg");
	mask.setTransform(160,25);

	// Mask_Color
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape.setTransform(160,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.102)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_1.setTransform(160,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.2)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_2.setTransform(160,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.29)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_3.setTransform(160,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.376)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_4.setTransform(160,25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.459)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_5.setTransform(160,25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.533)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_6.setTransform(160,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.6)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_7.setTransform(160,25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.667)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_8.setTransform(160,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.722)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_9.setTransform(160,25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.776)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_10.setTransform(160,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.824)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_11.setTransform(160,25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.863)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_12.setTransform(160,25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.902)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_13.setTransform(160,25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.929)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_14.setTransform(160,25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.957)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_15.setTransform(160,25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.976)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_16.setTransform(160,25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.988)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_17.setTransform(160,25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.996)").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_18.setTransform(160,25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_19.setTransform(160,25);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},533).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).wait(2));

	// Mask_Color
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_20.setTransform(160,30);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.102)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_21.setTransform(160,30);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.2)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_22.setTransform(160,30);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.29)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_23.setTransform(160,30);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.376)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_24.setTransform(160,30);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.459)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_25.setTransform(160,30);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.533)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_26.setTransform(160,30);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.6)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_27.setTransform(160,30);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.667)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_28.setTransform(160,30);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.722)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_29.setTransform(160,30);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.776)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_30.setTransform(160,30);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.824)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_31.setTransform(160,30);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.863)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_32.setTransform(160,30);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.902)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_33.setTransform(160,30);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.929)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_34.setTransform(160,30);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.957)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_35.setTransform(160,30);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.976)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_36.setTransform(160,30);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.988)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_37.setTransform(160,30);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.996)").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_38.setTransform(160,30);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("A4/EsIAApXMAx/AAAIAAJXg");
	this.shape_39.setTransform(160,30);

	var maskedShapeInstanceList = [this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},159).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[]},1).to({state:[]},374).wait(1));

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("single",0);
	this.instance.setTransform(0.05,-51,0.6,0.6,0,0,0,0.1,-0.1);
	this.instance._off = true;
	var instanceFilter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-2,-9,244,94);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).to({regY:0.1,y:4.55},19,cjs.Ease.get(1)).wait(36).to({startPosition:0},0).to({regX:0,x:-193.45,y:5.45},14,cjs.Ease.get(-0.5)).to({_off:true},1).wait(468));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(16).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(1)).wait(36).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(-0.5)).wait(468));

	// btn_CTA
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(0,9);
	this.instance_1._off = true;
	var instance_1Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-3,-3,136,38);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(470).to({_off:false},0).to({x:30},14,cjs.Ease.get(1)).to({_off:true},69).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(470).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(1)).wait(1));

	// Text_3
	this.instance_2 = new lib.g_title_3("synched",0);
	this.instance_2.setTransform(-52.45,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_2._off = true;
	var instance_2Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_3];
	this.instance_2.cache(-2,-2,222,57);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(372).to({_off:false},0).to({x:108.55},16,cjs.Ease.get(0.8)).wait(47).to({startPosition:0},0).to({x:-52.45},16,cjs.Ease.get(0.8)).to({_off:true},1).wait(102));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_3).wait(372).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.8)).wait(47).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 16,cjs.Ease.get(0.8)).wait(102));

	// Text_3_Bg
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgTD6IAAnzIAnAAIAAELIgVAAIAADog");
	this.shape_40.setTransform(-3,25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AhjD6IAAnzIDHAAIAAELIh1AAIAADog");
	this.shape_41.setTransform(5.375,24.975);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AiwD7IAAn0IFhAAIAAEMIjRAAIAADog");
	this.shape_42.setTransform(13.425,24.95);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Aj5D7IAAn0IHzAAIAAEMIkoAAIAADog");
	this.shape_43.setTransform(21.125,24.95);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AlAD7IAAn1IKBAAIAAENIl9AAIAADog");
	this.shape_44.setTransform(28.525,24.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AmDD7IAAn1IMHAAIAAENInNAAIAADog");
	this.shape_45.setTransform(35.575,24.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AnDD7IAAn1IOHAAIAAENIoZAAIAADog");
	this.shape_46.setTransform(42.3,24.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AoAD7IAAn1IQBAAIAAENIpiAAIAADog");
	this.shape_47.setTransform(48.675,24.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("Ao6D7IAAn1IR1AAIAAENIqnAAIAADog");
	this.shape_48.setTransform(54.75,24.875);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("ApxD8IAAn2ITjAAIAAEOIrpAAIAADog");
	this.shape_49.setTransform(60.5,24.85);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AqlD8IAAn2IVKAAIAAEOIsmAAIAADog");
	this.shape_50.setTransform(65.9,24.85);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("ArVD8IAAn3IWrAAIAAEPItgAAIAADog");
	this.shape_51.setTransform(70.975,24.825);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AsCD8IAAn3IYFAAIAAEPIuWAAIAADog");
	this.shape_52.setTransform(75.725,24.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AssD8IAAn3IZZAAIAAEPIvIAAIAADog");
	this.shape_53.setTransform(80.125,24.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AtTD8IAAn3IanAAIAAEPIv2AAIAADog");
	this.shape_54.setTransform(84.225,24.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("At3D8IAAn3IbvAAIAAEPIwhAAIAADog");
	this.shape_55.setTransform(87.975,24.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AuXD8IAAn3IcvAAIAAEPIxIAAIAADog");
	this.shape_56.setTransform(91.4,24.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Au1D8IAAn3IdrAAIAAEPIxrAAIAADog");
	this.shape_57.setTransform(94.475,24.775);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AvPD8IAAn3IegAAIAAEPIyMAAIAADog");
	this.shape_58.setTransform(97.25,24.775);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AvnD8IAAn3IfPAAIAAEPIynAAIAADog");
	this.shape_59.setTransform(99.675,24.775);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("Av7D9IAAn5If3AAIAAERIy/AAIAADog");
	this.shape_60.setTransform(101.8,24.75);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AwMD9IAAn5MAgZAAAIAAERIzTAAIAADog");
	this.shape_61.setTransform(103.575,24.75);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AwaD9IAAn5MAg1AAAIAAERIzjAAIAADog");
	this.shape_62.setTransform(105,24.75);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AwkD9IAAn5MAhJAAAIAAERIzwAAIAADog");
	this.shape_63.setTransform(106.125,24.75);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AvED8IAAn3IeJAAIAAEPIx9AAIAADog");
	this.shape_64.setTransform(96.025,24.775);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AtoD8IAAn3IbRAAIAAEPIwQAAIAADog");
	this.shape_65.setTransform(86.425,24.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AsRD8IAAn3IYjAAIAAEPIunAAIAADog");
	this.shape_66.setTransform(77.3,24.825);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("Aq/D8IAAn3IV+AAIAAEPItFAAIAADog");
	this.shape_67.setTransform(68.65,24.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AonD7IAAn1IRQAAIAAENIqSAAIAADog");
	this.shape_68.setTransform(52.8,24.875);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AnjD7IAAn1IPHAAIAAENIo/AAIAADog");
	this.shape_69.setTransform(45.625,24.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AmjD7IAAn1INHAAIAAENInzAAIAADog");
	this.shape_70.setTransform(38.875,24.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AlnD7IAAn1ILPAAIAAENImrAAIAADog");
	this.shape_71.setTransform(32.675,24.925);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AkxD7IAAn1IJjAAIAAENIlrAAIAADog");
	this.shape_72.setTransform(26.925,24.925);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("Aj+D7IAAn0IH9AAIAAEMIkuAAIAADog");
	this.shape_73.setTransform(21.675,24.95);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AjRD7IAAn0IGjAAIAAEMIj4AAIAADog");
	this.shape_74.setTransform(16.875,24.95);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AioD6IAAnzIFRAAIAAELIjIAAIAADog");
	this.shape_75.setTransform(12.6,24.975);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AiDD6IAAnzIEHAAIAAELIibAAIAADog");
	this.shape_76.setTransform(8.8,24.975);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AhkD6IAAnzIDJAAIAAELIh2AAIAADog");
	this.shape_77.setTransform(5.475,24.975);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AhJD6IAAnzICTAAIAAELIhWAAIAADog");
	this.shape_78.setTransform(2.625,24.975);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgyD6IAAnzIBlAAIAAELIg7AAIAADog");
	this.shape_79.setTransform(0.275,25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AggD6IAAnzIBBAAIAAELIglAAIAADog");
	this.shape_80.setTransform(-1.625,25);

	var maskedShapeInstanceList = [this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_40}]},361).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49,p:{x:60.5}}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},60).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_49,p:{x:60.475}}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_40}]},1).to({state:[]},1).wait(90));

	// Text_2
	this.instance_3 = new lib.g_title_2("synched",0);
	this.instance_3.setTransform(-52.45,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_3._off = true;
	var instance_3Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_4];
	this.instance_3.cache(-2,-2,224,57);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(245).to({_off:false},0).to({x:108.55},29,cjs.Ease.get(0.8)).wait(55).to({startPosition:0},0).to({x:-52.45},16,cjs.Ease.get(0.8)).to({_off:true},1).wait(208));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_4).wait(245).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 29,cjs.Ease.get(0.8)).wait(55).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 16,cjs.Ease.get(0.8)).wait(208));

	// Text_2_Bg
	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgRD6IAAnzIAPAAIAADmIATAAIAAENg");
	this.shape_81.setTransform(-3.25,25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AhFD6IAAnzIBwAAIAADmIAbAAIAAENg");
	this.shape_82.setTransform(2.2,25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("Ah3D6IAAnzIDOAAIAADnIAhAAIAAEMg");
	this.shape_83.setTransform(7.525,24.975);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AipD6IAAnzIErAAIAADnIAoAAIAAEMg");
	this.shape_84.setTransform(12.7,24.975);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AjZD7IAAn0IGGAAIAADnIAtAAIAAENg");
	this.shape_85.setTransform(17.75,24.95);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AkID7IAAn0IHeAAIAADnIAzAAIAAENg");
	this.shape_86.setTransform(22.65,24.95);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("Ak2D7IAAn1IIzAAIAADoIA6AAIAAENg");
	this.shape_87.setTransform(27.45,24.925);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AliD7IAAn1IKGAAIAADoIA/AAIAAENg");
	this.shape_88.setTransform(32.075,24.925);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AmND7IAAn1ILWAAIAADoIBFAAIAAENg");
	this.shape_89.setTransform(36.575,24.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("Am2D7IAAn1IMjAAIAADoIBKAAIAAENg");
	this.shape_90.setTransform(40.95,24.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AnfD7IAAn1INwAAIAADoIBPAAIAAENg");
	this.shape_91.setTransform(45.175,24.9);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AoGD7IAAn1IO5AAIAADpIBUAAIAAEMg");
	this.shape_92.setTransform(49.275,24.875);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AosD7IAAn1IQAAAIAADpIBZAAIAAEMg");
	this.shape_93.setTransform(53.225,24.875);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("ApQD7IAAn1IREAAIAADpIBdAAIAAEMg");
	this.shape_94.setTransform(57.05,24.875);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("ApzD8IAAn2ISFAAIAADpIBiAAIAAENg");
	this.shape_95.setTransform(60.725,24.85);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AqVD8IAAn2ITFAAIAADpIBmAAIAAENg");
	this.shape_96.setTransform(64.275,24.85);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Aq2D8IAAn2IUCAAIAADpIBrAAIAAENg");
	this.shape_97.setTransform(67.675,24.85);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("ArVD8IAAn3IU8AAIAADqIBvAAIAAENg");
	this.shape_98.setTransform(70.95,24.825);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("ArzD8IAAn3IV0AAIAADqIBzAAIAAENg");
	this.shape_99.setTransform(74.1,24.825);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AsQD8IAAn3IWqAAIAADqIB2AAIAAENg");
	this.shape_100.setTransform(77.1,24.825);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AsrD8IAAn3IXeAAIAADqIB5AAIAAENg");
	this.shape_101.setTransform(79.95,24.8);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AtFD8IAAn3IYOAAIAADqIB9AAIAAENg");
	this.shape_102.setTransform(82.7,24.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AteD8IAAn3IY9AAIAADqICAAAIAAENg");
	this.shape_103.setTransform(85.275,24.8);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("At1D8IAAn3IZoAAIAADqICDAAIAAENg");
	this.shape_104.setTransform(87.725,24.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AuMD8IAAn3IaSAAIAADqICGAAIAAENg");
	this.shape_105.setTransform(90.05,24.8);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AugD8IAAn3Ia5AAIAADrICIAAIAAEMg");
	this.shape_106.setTransform(92.225,24.775);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Au0D8IAAn3IbeAAIAADrICLAAIAAEMg");
	this.shape_107.setTransform(94.275,24.775);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AvGD8IAAn3Ib/AAIAADrICOAAIAAEMg");
	this.shape_108.setTransform(96.2,24.775);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AvXD8IAAn3IcfAAIAADrICQAAIAAEMg");
	this.shape_109.setTransform(97.975,24.775);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AvnD8IAAn3Ic9AAIAADrICRAAIAAEMg");
	this.shape_110.setTransform(99.6,24.775);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("Av1D8IAAn3IdXAAIAADrICUAAIAAEMg");
	this.shape_111.setTransform(101.1,24.775);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AwCD9IAAn5IdwAAIAADsICVAAIAAENg");
	this.shape_112.setTransform(102.475,24.75);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AwOD9IAAn5IeGAAIAADsICWAAIAAENg");
	this.shape_113.setTransform(103.7,24.75);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AwYD9IAAn5IeZAAIAADsICYAAIAAENg");
	this.shape_114.setTransform(104.8,24.75);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AwhD9IAAn5IeqAAIAADsICZAAIAAENg");
	this.shape_115.setTransform(105.75,24.75);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AwpD9IAAn5Ie5AAIAADsICaAAIAAENg");
	this.shape_116.setTransform(106.55,24.75);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AwwD9IAAn5IfFAAIAADsICbAAIAAENg");
	this.shape_117.setTransform(107.25,24.75);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AvOD8IAAn3IcOAAIAADrICPAAIAAEMg");
	this.shape_118.setTransform(97.025,24.775);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AtxD8IAAn3IZgAAIAADqICDAAIAAENg");
	this.shape_119.setTransform(87.3,24.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AsYD8IAAn3IW7AAIAADqIB3AAIAAENg");
	this.shape_120.setTransform(78.05,24.825);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("ArFD8IAAn3IUeAAIAADqIBtAAIAAENg");
	this.shape_121.setTransform(69.3,24.825);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("Ap2D8IAAn2ISLAAIAADpIBiAAIAAENg");
	this.shape_122.setTransform(61.025,24.85);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AnmD7IAAn1IN9AAIAADoIBQAAIAAENg");
	this.shape_123.setTransform(45.975,24.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AmmD7IAAn1IMFAAIAADoIBIAAIAAENg");
	this.shape_124.setTransform(39.175,24.9);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AlpD7IAAn1IKTAAIAADoIBAAAIAAENg");
	this.shape_125.setTransform(32.875,24.925);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AkyD7IAAn1IIsAAIAADoIA5AAIAAENg");
	this.shape_126.setTransform(27.05,24.925);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("Aj/D7IAAn0IHMAAIAADnIAzAAIAAENg");
	this.shape_127.setTransform(21.725,24.95);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AjRD7IAAn0IF2AAIAADnIAtAAIAAENg");
	this.shape_128.setTransform(16.875,24.95);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AioD6IAAnzIEpAAIAADnIAoAAIAAEMg");
	this.shape_129.setTransform(12.55,24.975);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AiCD6IAAnzIDjAAIAADnIAjAAIAAEMg");
	this.shape_130.setTransform(8.7,24.975);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AhiD6IAAnzICnAAIAADnIAeAAIAAEMg");
	this.shape_131.setTransform(5.325,24.975);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AhHD6IAAnzIB0AAIAADnIAbAAIAAEMg");
	this.shape_132.setTransform(2.45,24.975);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgwD6IAAnzIBJAAIAADmIAYAAIAAENg");
	this.shape_133.setTransform(0.05,25);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgeD6IAAnzIAnAAIAADmIAWAAIAAENg");
	this.shape_134.setTransform(-1.85,25);

	var maskedShapeInstanceList = [this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_81}]},234).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93,p:{x:53.225}}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},68).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_93,p:{x:53.25}}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_81}]},1).to({state:[]},2).wait(195));

	// Photo_4
	this.instance_4 = new lib.g_pic04("synched",0);
	this.instance_4._off = true;
	var instance_4Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_5];
	this.instance_4.cache(-320,-2,642,168);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(179).to({_off:false},0).to({y:-102},52,cjs.Ease.get(0.9)).wait(12).to({startPosition:0},0).to({x:47.5},38,cjs.Ease.get(0.9)).to({_off:true},272).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_5).wait(179).to(new cjs.ColorFilter(1,1,1,1,180,180,180,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 52,cjs.Ease.get(0.9)).wait(12).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 38,cjs.Ease.get(0.9)).wait(1));

	// Text_1_A
	this.instance_5 = new lib.g_title_1_A("synched",0);
	this.instance_5.setTransform(-29.95,31.4,1,1,0,0,0,111.3,31.4);
	this.instance_5._off = true;
	var instance_5Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_6];
	this.instance_5.cache(-2,-2,205,57);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(94).to({_off:false},0).to({x:108.55},19,cjs.Ease.get(0.8)).wait(46).to({startPosition:0},0).to({x:-29.95},14,cjs.Ease.get(0.8)).to({_off:true},1).wait(380));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_6).wait(94).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(46).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(380));

	// Text_1_A_Bg
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgRD7IAAnwIAAgFIARAAIAAAFIAADhIARAAIAAEPg");
	this.shape_135.setTransform(-3.25,25.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AhbD7IAAn1IChAAIAADmIAWAAIAAEPg");
	this.shape_136.setTransform(4.625,25.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AijD7IAAn1IEtAAIAADmIAaAAIAAEPg");
	this.shape_137.setTransform(12.175,25.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AjoD7IAAn1IGyAAIAADmIAfAAIAAEPg");
	this.shape_138.setTransform(19.425,25.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AkqD7IAAn1IIzAAIAADmIAiAAIAAEPg");
	this.shape_139.setTransform(26.35,25.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AlpD7IAAn1IKtAAIAADmIAmAAIAAEPg");
	this.shape_140.setTransform(32.975,25.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AmlD7IAAn1IMhAAIAADmIAqAAIAAEPg");
	this.shape_141.setTransform(39.3,25.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AneD7IAAn1IOQAAIAADmIAtAAIAAEPg");
	this.shape_142.setTransform(45.3,25.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AoUD7IAAn1IP4AAIAADmIAxAAIAAEPg");
	this.shape_143.setTransform(51,25.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("ApID7IAAn1IRdAAIAADmIA0AAIAAEPg");
	this.shape_144.setTransform(56.375,25.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("Ap4D7IAAn1IS6AAIAADmIA3AAIAAEPg");
	this.shape_145.setTransform(61.475,25.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AqlD7IAAn1IURAAIAADmIA6AAIAAEPg");
	this.shape_146.setTransform(66.225,25.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("ArQD7IAAn1IVkAAIAADmIA9AAIAAEPg");
	this.shape_147.setTransform(70.675,25.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("Ar3D7IAAn1IWwAAIAADmIA/AAIAAEPg");
	this.shape_148.setTransform(74.825,25.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AscD7IAAn1IX3AAIAADmIBCAAIAAEPg");
	this.shape_149.setTransform(78.675,25.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("As9D7IAAn1IY4AAIAADmIBDAAIAAEPg");
	this.shape_150.setTransform(82.2,25.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AtcD7IAAn1IZzAAIAADmIBGAAIAAEPg");
	this.shape_151.setTransform(85.425,25.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("At4D7IAAn1IapAAIAADmIBIAAIAAEPg");
	this.shape_152.setTransform(88.325,25.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AuQD7IAAn1IbZAAIAADmIBIAAIAAEPg");
	this.shape_153.setTransform(90.925,25.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AumD7IAAn1IcDAAIAADmIBKAAIAAEPg");
	this.shape_154.setTransform(93.2,25.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("Au5D7IAAn1IcoAAIAADmIBLAAIAAEPg");
	this.shape_155.setTransform(95.175,25.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AvID7IAAn1IdGAAIAADmIBLAAIAAEPg");
	this.shape_156.setTransform(96.85,25.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AvWD7IAAn1IdfAAIAADmIBOAAIAAEPg");
	this.shape_157.setTransform(98.2,25.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AvgD7IAAnwIAAgFIdzAAIAAAFIAADhIBOAAIAAEPg");
	this.shape_158.setTransform(99.25,25.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("At1D7IAAn1IakAAIAADmIBHAAIAAEPg");
	this.shape_159.setTransform(88.05,25.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AsQD7IAAn1IXgAAIAADmIBBAAIAAEPg");
	this.shape_160.setTransform(77.475,25.1);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AqyD7IAAn1IUqAAIAADmIA7AAIAAEPg");
	this.shape_161.setTransform(67.55,25.1);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("ApZD7IAAn1IR+AAIAADmIA2AAIAAEPg");
	this.shape_162.setTransform(58.25,25.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AoHD7IAAn1IPfAAIAADmIAwAAIAAEPg");
	this.shape_163.setTransform(49.625,25.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("Am7D7IAAn1INLAAIAADmIAsAAIAAEPg");
	this.shape_164.setTransform(41.6,25.1);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("Al1D7IAAn1ILEAAIAADmIAnAAIAAEPg");
	this.shape_165.setTransform(34.225,25.1);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("Ak1D7IAAn1IJIAAIAADmIAjAAIAAEPg");
	this.shape_166.setTransform(27.5,25.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("Aj7D7IAAn1IHXAAIAADmIAgAAIAAEPg");
	this.shape_167.setTransform(21.425,25.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AjHD7IAAn1IFzAAIAADmIAcAAIAAEPg");
	this.shape_168.setTransform(15.975,25.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AiaD7IAAn1IEbAAIAADmIAaAAIAAEPg");
	this.shape_169.setTransform(11.175,25.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AhyD7IAAn1IDNAAIAADmIAYAAIAAEPg");
	this.shape_170.setTransform(7,25.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AhQD7IAAn1ICMAAIAADmIAVAAIAAEPg");
	this.shape_171.setTransform(3.475,25.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("Ag1D7IAAn1IBXAAIAADmIAUAAIAAEPg");
	this.shape_172.setTransform(0.6,25.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AggD7IAAn1IAuAAIAADmIATAAIAAEPg");
	this.shape_173.setTransform(-1.625,25.1);

	var maskedShapeInstanceList = [this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149,this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160,this.shape_161,this.shape_162,this.shape_163,this.shape_164,this.shape_165,this.shape_166,this.shape_167,this.shape_168,this.shape_169,this.shape_170,this.shape_171,this.shape_172,this.shape_173];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_135}]},85).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_158}]},55).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_135}]},1).to({state:[]},1).wait(374));

	// Photo00
	this.instance_6 = new lib.g_pic00("single",0);
	var instance_6Filter_7 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_6.filters = [instance_6Filter_7];
	this.instance_6.cache(-2,-2,324,64);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({startPosition:0},16,cjs.Ease.get(0.8)).wait(78).to({startPosition:0},0).to({x:20},19,cjs.Ease.get(0.9)).to({_off:true},66).wait(375));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_7).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 16,cjs.Ease.get(0.8)).wait(78).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.9)).wait(375));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance, startFrame:16, endFrame:16, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:0, endFrame:0, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:17, endFrame:35, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:36, endFrame:71, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:72, endFrame:85, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:86, endFrame:86, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance, startFrame:553, endFrame:554, x:-2, y:-9, w:244, h:94});
	this.filterCacheList.push({instance: this.instance_1, startFrame:470, endFrame:470, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:471, endFrame:484, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:485, endFrame:553, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:553, endFrame:554, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_2, startFrame:372, endFrame:372, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:373, endFrame:388, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:435, endFrame:435, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_2, startFrame:436, endFrame:451, x:-2, y:-2, w:222, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:245, endFrame:245, x:-2, y:-2, w:224, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:224, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:246, endFrame:274, x:-2, y:-2, w:224, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:329, endFrame:329, x:-2, y:-2, w:224, h:57});
	this.filterCacheList.push({instance: this.instance_3, startFrame:330, endFrame:345, x:-2, y:-2, w:224, h:57});
	this.filterCacheList.push({instance: this.instance_4, startFrame:179, endFrame:179, x:-320, y:-2, w:642, h:168});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-320, y:-2, w:642, h:168});
	this.filterCacheList.push({instance: this.instance_4, startFrame:180, endFrame:231, x:-320, y:-2, w:642, h:168});
	this.filterCacheList.push({instance: this.instance_4, startFrame:243, endFrame:243, x:-320, y:-2, w:642, h:168});
	this.filterCacheList.push({instance: this.instance_4, startFrame:244, endFrame:281, x:-320, y:-2, w:642, h:168});
	this.filterCacheList.push({instance: this.instance_5, startFrame:94, endFrame:94, x:-2, y:-2, w:205, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:205, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:95, endFrame:113, x:-2, y:-2, w:205, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:159, endFrame:159, x:-2, y:-2, w:205, h:57});
	this.filterCacheList.push({instance: this.instance_5, startFrame:160, endFrame:173, x:-2, y:-2, w:205, h:57});
	this.filterCacheList.push({instance: this.instance_6, startFrame:1, endFrame:16, x:-2, y:-2, w:324, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-2, w:324, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:94, endFrame:94, x:-2, y:-2, w:324, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:95, endFrame:113, x:-2, y:-2, w:324, h:64});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(160,25,160,25);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 320,
	height: 50,
	fps: 24,
	color: "#FAFAFA",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;