(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[0,824,294,168],[302,474,281,220],[0,602,252,220],[254,696,140,114],[296,812,185,40],[396,696,185,40],[396,738,185,40],[0,0,300,600],[302,0,300,472]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_15 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.g_title_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_15();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,294,168);


(lib.g_title_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_14();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,281,220);


(lib.g_title_1_A = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AMkPkIAAhUIBaAAIAABUgAIJPkQgvgRAAg3IAAhVIBgAAIAABJIAGAGIAeAAIAGgGIAAhCIgGgIIhjgsQgUgKgHgRQgGgMAAgbIAAhcQAAg3AvgRICMAAQAvARAAA3IAABQIhgAAIAAhEIgGgGIgeAAIgGAGIAAA/IAIAKIBhAmQAUAJAHARQAGANAAAbIAABjQAAA3gvARgAEHPkQgvgRAAg3IAAhVIBgAAIAABJIAGAGIAeAAIAGgGIAAhCIgGgIIhjgsQgUgKgHgRQgGgMAAgbIAAhcQAAg3AvgRICMAAQAvARAAA3IAABQIhgAAIAAhEIgGgGIgeAAIgGAGIAAA/IAHAKIBhAmQAVAJAHARQAGANAAAbIAABjQAAA3gvARgAgLPkIAAmwIDFAAIAABaIhmAAIAABOIBgAAIAABaIhgAAIAABUIBpAAIAABagAh9PkIg8i9IgGAAIAAC9IhUAAIAAmwIBUAAIA8C8IAGAAIAAi8IBUAAIAAGwgAm1PkIAAhaIASAAIAAj8IgSAAIAAhaICEAAIAABaIgSAAIAAD8IASAAIAABagAqLPkQgvgRAAg3IAAhVIBgAAIAABJIAGAGIAeAAIAGgGIAAhCIgFgIIhjgsQgVgKgHgRQgGgMAAgbIAAhcQAAg3AvgRICMAAQAvARAAA3IAABQIhgAAIAAhEIgGgGIgeAAIgGAGIAAA/IAIAKIBgAmQAVAJAHARQAGANAAAbIAABjQAAA3gvARgAuKPkQgvgRAAg3IAAloIBgAAIAAFcIAGAGIAYAAIAGgGIAAlcIBgAAIAAFoQAAA3guARgAzBPkIAAmwIC7AAQAvARAAA3IAABAQAAA4gwAQQAwARAAA3IAABQQAAA3gvARgAxhOcIAkAAIAGgGIAAhgIgGgGIgkAAgAxhLoIAkAAIAGgGIAAhgIgGgGIgkAAgAMoNgIAAgwQAAgaAFgNQAHgOATgMIAigSIAAhVIgGgGIgeAAIgGAGIAAA/IhgAAIAAhLQAAg3AvgRICMAAQAvARAAA3IAABcQAAAagGANQgHARgUAKIgyAVIAAAxgAN7HcIAAj2IgDAAIgeBgIhIAAIgehgIgDAAIAAD2IhaAAIAAmwIBpAAIAzCWIAGAAIAziWIBpAAIAAGwgAIyHcIg3ioIgKAAIAACoIhhAAIAAmwIC8AAQAuARAAA3IAABcQABA0goASIAzCKIAAA8gAHxDmIAkAAIAGgGIAAhgIgGgGIgkAAgAEfHcIgHhUIguAAIgHBUIhaAAIAAhIIA2loICDAAIA3FoIAABIgAEQEuIgMiJIgGAAIgMCJIAeAAgAhVHcIAAmwIDFAAIAABaIhlAAIAABUIBgAAIAABaIhgAAIAACogAkTHcIg3ioIgLAAIAACoIhgAAIAAmwIC7AAQAvARAAA3IAABcQAAA0goASIAzCKIAAA8gAlVDmIAkAAIAGgGIAAhgIgGgGIgkAAgAqIHcQgvgRAAg3IAAloIBgAAIAAFcIAGAGIAYAAIAGgGIAAlcIBgAAIAAFoQAAA3guARgAuQHcQgvgRAAg3IAAkgQAAg3AvgRICMAAQAvARAAA3IAAEgQAAA3gvARgAtfCAIAAEIIAGAGIAeAAIAGgGIAAkIIgGgGIgeAAgAx/HcIAAiqIhIi9IAAhJIBaAAIAbCUIAGAAIAbiUIBaAAIAABJIhIC9IAACqgAFxgrIgTkGIgGAAIgSEGIh2AAIgwllIAAhLIBVAAIASEAIAHAAIASkAIB2AAIATEAIAGAAIASkAIBVAAIAABLIgvFlgAgygrQgugRAAg3IAAkgQAAg3AugRICMAAQAuARABA3IAAEgQgBA3guARgAAAmHIAAEIIAEAGIAfAAIAFgGIAAkIIgFgGIgfAAgAjFgrIg3ioIgLAAIAACoIhgAAIAAmwIC7AAQAvARAAA3IAABcQAAA0goASIAzCJIAAA9gAkHkhIAkAAIAGgGIAAhgIgGgGIgkAAgApAgrQgvgRAAg3IAAkgQAAg3AvgRICMAAQAvARAAA3IAABIIhgAAIAAg8IgGgGIgeAAIgGAGIAAEIIAGAGIAeAAIAGgGIAAhOIgYAAIAAhaIB4AAIAAC0QAAA3gvARgAuigrQgvgRAAg3IAAkgQAAg3AvgRICMAAQAvARAAA3IAAEgQAAA3gvARgAtxmHIAAEIIAGAGIAeAAIAGgGIAAkIIgGgGIgeAAgAyIgrIAAlWIhFAAIAAhaIDqAAIAABaIhFAAIAAFWgAPkozIAAmwIC7AAQAvARAAA3IAAEgQAAA3gvARgAREqBIAkAAIAGgGIAAkIIgGgGIgkAAgANyozIg8i9IgGAAIAAC9IhUAAIAAmwIBUAAIA8C8IAGAAIAAi8IBUAAIAAGwgAJqozIgHhUIguAAIgHBUIhaAAIAAhJIA3lnICCAAIA3FnIAABJgAJbrhIgMiIIgGAAIgMCIIAeAAgAFcozIAAioIgqAAIAACoIhgAAIAAmwIBgAAIAACuIAqAAIAAiuIBgAAIAAGwgAAGozIgGhUIguAAIgHBUIhaAAIAAhJIA3lnICBAAIA3FnIAABJgAgIrhIgMiIIgGAAIgMCIIAeAAgAnrozIAAmwIC7AAQAvARAAA3IAAEgQAAA3gvARgAmLqBIAkAAIAGgGIAAkIIgGgGIgkAAgArSozIAAmwIDGAAIAABaIhmAAIAABOIBgAAIAABaIhgAAIAABUIBpAAIAABagAu5ozIAAmwIDGAAIAABaIhmAAIAABOIBgAAIAABaIhgAAIAABUIBpAAIAABagAwrozIg8i9IgGAAIAAC9IhUAAIAAmwIBUAAIA8C8IAGAAIAAi8IBUAAIAAGwg");
	this.shape.setTransform(125.3,106.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Text
	this.instance = new lib.CachedBmp_13();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,252,220);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.instance = new lib.CachedBmp_12();
	this.instance.setTransform(-4.2,0);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AtjKBIAA0BIbHAAIAAUBg");
	this.shape.setTransform(61.6,64.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.2,0,173.6,128.2);


(lib.g_pic04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Tomato
	this.instance = new lib.Bitmap9();
	this.instance.setTransform(0,944,1,1,0,180,0);

	this.instance_1 = new lib.Bitmap9();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,944);


(lib.g_pic00 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap6();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(0,1.5);

	this.instance_1 = new lib.CachedBmp_10();
	this.instance_1.setTransform(0,1.5);

	this.instance_2 = new lib.CachedBmp_11();
	this.instance_2.setTransform(0,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(2));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AucDkIAAnHIc5AAIAAHHg");
	this.shape.setTransform(92.5,22.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AucjjIc5AAIAAHHI85AAg");
	this.shape_1.setTransform(92.5,22.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AucDkIAAnHIc5AAIAAHHg");
	this.shape_2.setTransform(92.5,22.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,187,47.6);


// stage content:
(lib.Farmer_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	mask.setTransform(150,299.9992);

	// Mask_Color
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.102)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.2)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_2.setTransform(150,300);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.29)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_3.setTransform(150,300);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.376)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_4.setTransform(150,300);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.459)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_5.setTransform(150,300);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.533)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_6.setTransform(150,300);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.6)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_7.setTransform(150,300);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.667)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_8.setTransform(150,300);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.722)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_9.setTransform(150,300);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.776)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_10.setTransform(150,300);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.824)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_11.setTransform(150,300);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.863)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_12.setTransform(150,300);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.902)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_13.setTransform(150,300);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.929)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_14.setTransform(150,300);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.957)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_15.setTransform(150,300);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.976)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_16.setTransform(150,300);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.988)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_17.setTransform(150,300);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.996)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_18.setTransform(150,300);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_19.setTransform(150,300);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},326).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).wait(2));

	// Mask_Color
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_20.setTransform(150,300);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.102)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_21.setTransform(150,300);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.2)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_22.setTransform(150,300);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.29)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_23.setTransform(150,300);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.376)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_24.setTransform(150,300);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.459)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_25.setTransform(150,300);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.533)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_26.setTransform(150,300);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.6)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_27.setTransform(150,300);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.667)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_28.setTransform(150,300);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.722)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_29.setTransform(150,300);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.776)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_30.setTransform(150,300);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.824)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_31.setTransform(150,300);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.863)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_32.setTransform(150,300);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.902)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_33.setTransform(150,300);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.929)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_34.setTransform(150,300);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.957)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_35.setTransform(150,300);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.976)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_36.setTransform(150,300);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.988)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_37.setTransform(150,300);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.996)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_38.setTransform(150,300);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_39.setTransform(150,300);

	var maskedShapeInstanceList = [this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},108).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[]},1).to({state:[]},218).wait(1));

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("single",1);
	this.instance.setTransform(19.95,-92.5,0.8,0.8);
	this.instance._off = true;
	var instanceFilter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-27,-2,178,132);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({_off:false},0).to({y:0},23,cjs.Ease.get(0.8)).to({_off:true},81).wait(17).to({_off:false,alpha:0},0).to({alpha:1},19,cjs.Ease.get(0.9)).to({_off:true},182).wait(1));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(24).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 23,cjs.Ease.get(0.8)).wait(17).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 0).wait(20));

	// btn_CTA
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(57.5,544.45);
	this.instance_1._off = true;
	var instance_1Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-3,-3,191,52);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(264).to({_off:false},0).to({y:534.45},14,cjs.Ease.get(1)).to({_off:true},68).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(264).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(1)).wait(1));

	// Text_3
	this.instance_2 = new lib.g_title_3("synched",0);
	this.instance_2.setTransform(-52.45,387.15,1,1,0,0,0,111.3,31.4);
	this.instance_2._off = true;
	var instance_2Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_3];
	this.instance_2.cache(-2,-2,298,172);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(245).to({_off:false},0).to({x:108.55},14,cjs.Ease.get(0.8)).to({_off:true},87).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_3).wait(245).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(0.8)).wait(1));

	// Text_3_Bg
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgiM0IAAgFIAA5iIAsAAIAAIFIAZAAIAAJcIgxAAIAAIBIAAAFg");
	this.shape_40.setTransform(-6.525,436.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AidM0IAA5nIDYAAIAAIFIBjAAIAAJcIh8AAIAAIGg");
	this.shape_41.setTransform(6.725,436.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AkTM0IAA5nIF8AAIAAIFICrAAIAAJcIjEAAIAAIGg");
	this.shape_42.setTransform(19.35,436.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AmEM0IAA5nIIZAAIAAIFIDwAAIAAJcIkJAAIAAIGg");
	this.shape_43.setTransform(31.4,436.25);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AnuM0IAA5nIKuAAIAAIFIEwAAIAAJcIlKAAIAAIGg");
	this.shape_44.setTransform(42.85,436.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("ApUM0IAA5nIM8AAIAAIFIFtAAIAAJcImGAAIAAIGg");
	this.shape_45.setTransform(53.675,436.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AqzM0IAA5nIPAAAIAAIFIGnAAIAAJcInAAAIAAIGg");
	this.shape_46.setTransform(63.925,436.25);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AsNM0IAA5nIQ+AAIAAIFIHdAAIAAJcIn2AAIAAIGg");
	this.shape_47.setTransform(73.525,436.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AtiM0IAA5nIS0AAIAAIFIIQAAIAAJcIooAAIAAIGg");
	this.shape_48.setTransform(82.55,436.25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AuwM0IAA5nIUiAAIAAIFII/AAIAAJcIpYAAIAAIGg");
	this.shape_49.setTransform(91,436.25);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("Av5M0IAA5nIWHAAIAAIFIJsAAIAAJcIqFAAIAAIGg");
	this.shape_50.setTransform(98.825,436.25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("Aw9M0IAA5nIXmAAIAAIFIKUAAIAAJcIqtAAIAAIGg");
	this.shape_51.setTransform(106.05,436.25);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Ax7M0IAA5nIY8AAIAAIFIK7AAIAAJcIrUAAIAAIGg");
	this.shape_52.setTransform(112.675,436.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AyzM0IAA5nIaLAAIAAIFILcAAIAAJcIr1AAIAAIGg");
	this.shape_53.setTransform(118.675,436.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AzlM0IAA5nIbQAAIAAIFIL7AAIAAJcIsUAAIAAIGg");
	this.shape_54.setTransform(124.125,436.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("A0SM0IAA5nIcPAAIAAIFIMWAAIAAJcIsvAAIAAIGg");
	this.shape_55.setTransform(128.925,436.25);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("A06M0IAA5nIdGAAIAAIFIMvAAIAAJcItIAAIAAIGg");
	this.shape_56.setTransform(133.15,436.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("A1cM0IAA5nId2AAIAAIFINCAAIAAJcItbAAIAAIGg");
	this.shape_57.setTransform(136.75,436.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("A13M0IAA5nIecAAIAAIFINUAAIAAJcItsAAIAAIGg");
	this.shape_58.setTransform(139.75,436.25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("A2OM0IAA5nIe8AAIAAIFINhAAIAAJcIt6AAIAAIGg");
	this.shape_59.setTransform(142.175,436.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("A2fM0IAAgFIAA5iIfUAAIAAIFINrAAIAAJcIuEAAIAAIBIAAAFg");
	this.shape_60.setTransform(143.975,436.25);

	var maskedShapeInstanceList = [this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_40}]},236).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[]},90).wait(1));

	// Text_2
	this.instance_3 = new lib.g_title_2("synched",0);
	this.instance_3.setTransform(-52.45,417.15,1,1,0,0,0,111.3,31.4);
	this.instance_3._off = true;
	var instance_3Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_4];
	this.instance_3.cache(-2,-2,285,224);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(157).to({_off:false},0).to({x:108.55},14,cjs.Ease.get(0.8)).wait(40).to({startPosition:0},0).to({x:-117.45},16,cjs.Ease.get(0.8)).to({_off:true},1).wait(119));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_4).wait(157).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(0.8)).wait(40).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 16,cjs.Ease.get(0.8)).wait(119));

	// Text_2_Bg
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgnQ5MAAAghxIAPAAIAAI3IBAAAIAAIvIgsAAIAAGvIAnAAIAAJcg");
	this.shape_61.setTransform(-1.025,492.375);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AibQ5MAAAghxIC8AAIAAIzIBxAAIAAIzIhNAAIAAGvIBWAAIAAJcg");
	this.shape_62.setTransform(11,492.375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AkLQ5MAAAghxIFjAAIAAIvICcAAIAAI3IhpAAIAAGvICBAAIAAJcg");
	this.shape_63.setTransform(22.65,492.375);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Al2Q5MAAAghxIICAAIAAIrIDGAAIAAI7IiFAAIAAGvICqAAIAAJcg");
	this.shape_64.setTransform(33.775,492.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AncQ5MAAAghxIKYAAIAAInIDwAAIAAI/IihAAIAAGvIDSAAIAAJcg");
	this.shape_65.setTransform(44.35,492.375);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("Ao8Q5MAAAghxIMnAAIAAIjIEVAAIAAJDIi5AAIAAGvID2AAIAAJcg");
	this.shape_66.setTransform(54.35,492.375);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AqXQ5MAAAghxIOuAAIAAIgIE5AAIAAJGIjRAAIAAGvIEZAAIAAJcg");
	this.shape_67.setTransform(63.8,492.375);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("ArtQ5MAAAghxIQtAAIAAIdIFbAAIAAJJIjnAAIAAGvIE7AAIAAJcg");
	this.shape_68.setTransform(72.7,492.375);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("As+Q5MAAAghxISlAAIAAIaIF7AAIAAJMIj8AAIAAGvIFZAAIAAJcg");
	this.shape_69.setTransform(81.025,492.375);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AuJQ5MAAAghxIUUAAIAAIXIGYAAIAAJPIkPAAIAAGvIF2AAIAAJcg");
	this.shape_70.setTransform(88.825,492.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AvPQ5MAAAghxIV7AAIAAIUIG1AAIAAJSIkiAAIAAGvIGQAAIAAJcg");
	this.shape_71.setTransform(96.05,492.375);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AwPQ5MAAAghxIXaAAIAAISIHOAAIAAJUIkzAAIAAGvIGqAAIAAJcg");
	this.shape_72.setTransform(102.725,492.375);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AxKQ5MAAAghxIYyAAIAAIQIHlAAIAAJWIlCAAIAAGvIHAAAIAAJcg");
	this.shape_73.setTransform(108.825,492.375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Ax/Q5MAAAghxIaBAAIAAIOIH6AAIAAJYIlQAAIAAGvIHVAAIAAJcg");
	this.shape_74.setTransform(114.4,492.375);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AyvQ5MAAAghxIbIAAIAAIMIINAAIAAJaIldAAIAAGvIHoAAIAAJcg");
	this.shape_75.setTransform(119.4,492.375);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AzbQ5MAAAghxIcJAAIAAIKIIeAAIAAJcIloAAIAAGvIH4AAIAAJcg");
	this.shape_76.setTransform(123.85,492.375);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("A0AQ5MAAAghxIdAAAIAAIJIItAAIAAJdIlyAAIAAGvIIGAAIAAJcg");
	this.shape_77.setTransform(127.75,492.375);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("A0gQ5MAAAghxIdvAAIAAIIII6AAIAAJeIl7AAIAAGvIITAAIAAJcg");
	this.shape_78.setTransform(131.075,492.375);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("A07Q5MAAAghxIeXAAIAAIHIJEAAIAAJfImBAAIAAGvIIdAAIAAJcg");
	this.shape_79.setTransform(133.85,492.375);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("A1QQ5MAAAghxIe2AAIAAIGIJNAAIAAJgImHAAIAAGvIIlAAIAAJcg");
	this.shape_80.setTransform(136.075,492.375);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("A1hQ5MAAAghxIfPAAIAAIFIJTAAIAAJhImLAAIAAGvIIrAAIAAJcg");
	this.shape_81.setTransform(137.75,492.375);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AzeQ5MAAAghxIcNAAIAAIKIIgAAIAAJcIlpAAIAAGvIH5AAIAAJcg");
	this.shape_82.setTransform(124.175,492.375);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AxiQ5MAAAghxIZVAAIAAIPIHvAAIAAJXIlJAAIAAGvIHKAAIAAJcg");
	this.shape_83.setTransform(111.325,492.375);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AvsQ5MAAAghxIWnAAIAAITIHAAAIAAJTIkqAAIAAGvIGcAAIAAJcg");
	this.shape_84.setTransform(99.125,492.375);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("At+Q5MAAAghxIUEAAIAAIXIGUAAIAAJPIkNAAIAAGvIFyAAIAAJcg");
	this.shape_85.setTransform(87.65,492.375);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AsVQ5MAAAghxIRoAAIAAIbIFrAAIAAJLIjxAAIAAGvIFJAAIAAJcg");
	this.shape_86.setTransform(76.825,492.375);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AqzQ5MAAAghxIPXAAIAAIfIFEAAIAAJHIjYAAIAAGvIElAAIAAJcg");
	this.shape_87.setTransform(66.7,492.375);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("ApZQ5MAAAghxINRAAIAAIiIEhAAIAAJEIjBAAIAAGvIECAAIAAJcg");
	this.shape_88.setTransform(57.275,492.375);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AoEQ5MAAAghxILUAAIAAIlID/AAIAAJBIirAAIAAGvIDhAAIAAJcg");
	this.shape_89.setTransform(48.525,492.375);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("Am3Q5MAAAghxIJiAAIAAIoIDgAAIAAI+IiXAAIAAGvIDEAAIAAJcg");
	this.shape_90.setTransform(40.45,492.375);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AlvQ5MAAAghxIH3AAIAAIrIDEAAIAAI7IiDAAIAAGvICnAAIAAJcg");
	this.shape_91.setTransform(33.075,492.375);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AkvQ5MAAAghxIGYAAIAAItICrAAIAAI5IhzAAIAAGvICPAAIAAJcg");
	this.shape_92.setTransform(26.375,492.375);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Aj1Q5MAAAghxIFCAAIAAIvICUAAIAAI3IhkAAIAAGvIB5AAIAAJcg");
	this.shape_93.setTransform(20.375,492.375);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AjCQ5MAAAghxID3AAIAAIxIB/AAIAAI1IhWAAIAAGvIBkAAIAAJcg");
	this.shape_94.setTransform(15.05,492.375);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AiVQ5MAAAghxIC1AAIAAIzIBtAAIAAIzIhLAAIAAGvIBUAAIAAJcg");
	this.shape_95.setTransform(10.4,492.375);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AhvQ5MAAAghxIB8AAIAAI0IBeAAIAAIyIhAAAIAAGvIBFAAIAAJcg");
	this.shape_96.setTransform(6.475,492.375);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AhQQ5MAAAghxIBPAAIAAI2IBRAAIAAIwIg4AAIAAGvIA5AAIAAJcg");
	this.shape_97.setTransform(3.2,492.375);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("Ag4Q5MAAAghxIApAAIAAI3IBIAAIAAIvIgyAAIAAGvIAwAAIAAJcg");
	this.shape_98.setTransform(0.75,492.375);

	var maskedShapeInstanceList = [this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_61}]},148).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},47).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_61}]},1).to({state:[]},1).to({state:[]},112).wait(1));

	// Photo_4
	this.instance_4 = new lib.g_pic04("synched",0);
	this.instance_4._off = true;
	var instance_4Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_5];
	this.instance_4.cache(-2,-2,304,948);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(127).to({_off:false},0).to({startPosition:0},18,cjs.Ease.get(0.8)).to({_off:true},201).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_5).wait(127).to(new cjs.ColorFilter(1,1,1,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(0.8)).wait(1));

	// Text_1_A
	this.instance_5 = new lib.g_title_1_A("synched",0);
	this.instance_5.setTransform(-29.95,373.8,1,1,0,0,0,111.3,31.4);
	this.instance_5._off = true;
	var instance_5Filter_6 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_6];
	this.instance_5.cache(-2,-2,256,224);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(33).to({_off:false},0).to({x:108.55},19,cjs.Ease.get(0.8)).wait(56).to({startPosition:0},0).to({x:-88.95},14,cjs.Ease.get(0.8)).to({_off:true},6).wait(219));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_6).wait(33).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(56).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(219));

	// Text_1_A_Bg
	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgQQ8MAAAgh3IAhAAIAAJdIgdAAIAAG2IATAAIAARkg");
	this.shape_99.setTransform(-3.725,448.875);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AhwQ8MAAAgh3IDhAAIAAJdIhQAAIAAG2IAzAAIAARkg");
	this.shape_100.setTransform(6.3,448.875);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AjNQ8MAAAgh3IGbAAIAAJdIiBAAIAAG2IBRAAIAARkg");
	this.shape_101.setTransform(15.9,448.875);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AkmQ8MAAAgh3IJNAAIAAJdIiwAAIAAG2IBuAAIAARkg");
	this.shape_102.setTransform(25.125,448.875);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("Al7Q8MAAAgh3IL3AAIAAJdIjdAAIAAG2ICJAAIAARkg");
	this.shape_103.setTransform(33.975,448.875);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AnMQ8MAAAgh3IOZAAIAAJdIkHAAIAAG2ICjAAIAARkg");
	this.shape_104.setTransform(42.4,448.875);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AoZQ8MAAAgh3IQzAAIAAJdIkwAAIAAG2IC8AAIAARkg");
	this.shape_105.setTransform(50.45,448.875);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("ApjQ8MAAAgh3ITHAAIAAJdIlXAAIAAG2IDUAAIAARkg");
	this.shape_106.setTransform(58.075,448.875);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AqoQ8MAAAgh3IVRAAIAAJdIl7AAIAAG2IDqAAIAARkg");
	this.shape_107.setTransform(65.35,448.875);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("ArqQ8MAAAgh3IXWAAIAAJdImeAAIAAG2ID/AAIAARkg");
	this.shape_108.setTransform(72.2,448.875);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AspQ8MAAAgh3IZTAAIAAJdIm/AAIAAG2IEUAAIAARkg");
	this.shape_109.setTransform(78.675,448.875);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AtjQ8MAAAgh3IbHAAIAAJdIndAAIAAG2IEmAAIAARkg");
	this.shape_110.setTransform(84.75,448.875);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AuaQ8MAAAgh3Ic0AAIAAJdIn6AAIAAG2IE5AAIAARkg");
	this.shape_111.setTransform(90.4,448.875);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AvMQ8MAAAgh3IeZAAIAAJdIoUAAIAAG2IFIAAIAARkg");
	this.shape_112.setTransform(95.675,448.875);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("Av7Q8MAAAgh3If3AAIAAJdIotAAIAAG2IFXAAIAARkg");
	this.shape_113.setTransform(100.575,448.875);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AwmQ8MAAAgh3MAhOAAAIAAJdIpFAAIAAG2IFmAAIAARkg");
	this.shape_114.setTransform(105.05,448.875);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AxOQ8MAAAgh3MAidAAAIAAJdIpZAAIAAG2IFyAAIAARkg");
	this.shape_115.setTransform(109.175,448.875);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AxxQ8MAAAgh3MAjkAAAIAAJdIpsAAIAAG2IF+AAIAARkg");
	this.shape_116.setTransform(112.85,448.875);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AyRQ8MAAAgh3MAkjAAAIAAJdIp8AAIAAG2IGIAAIAARkg");
	this.shape_117.setTransform(116.175,448.875);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AytQ8MAAAgh3MAlbAAAIAAJdIqLAAIAAG2IGRAAIAARkg");
	this.shape_118.setTransform(119.075,448.875);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AzFQ8MAAAgh3MAmLAAAIAAJdIqXAAIAAG2IGYAAIAARkg");
	this.shape_119.setTransform(121.6,448.875);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AzaQ8MAAAgh3MAm1AAAIAAJdIqjAAIAAG2IGgAAIAARkg");
	this.shape_120.setTransform(123.725,448.875);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AzrQ8MAAAgh3MAnWAAAIAAJdIqrAAIAAG2IGlAAIAARkg");
	this.shape_121.setTransform(125.45,448.875);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("Az3Q8MAAAgh3MAnvAAAIAAJdIqyAAIAAG2IGpAAIAARkg");
	this.shape_122.setTransform(126.775,448.875);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AxuQ8MAAAgh3MAjdAAAIAAJdIpqAAIAAG2IF9AAIAARkg");
	this.shape_123.setTransform(112.5,448.875);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AvtQ8MAAAgh3IfbAAIAAJdIomAAIAAG2IFSAAIAARkg");
	this.shape_124.setTransform(99.05,448.875);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AtzQ8MAAAgh3IbnAAIAAJdInmAAIAAG2IEsAAIAARkg");
	this.shape_125.setTransform(86.4,448.875);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AsBQ8MAAAgh3IYDAAIAAJdImqAAIAAG2IEHAAIAARkg");
	this.shape_126.setTransform(74.575,448.875);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AqXQ8MAAAgh3IUvAAIAAJdIlyAAIAAG2IDlAAIAARkg");
	this.shape_127.setTransform(63.575,448.875);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("Ao1Q8MAAAgh3IRrAAIAAJdIk+AAIAAG2IDFAAIAARkg");
	this.shape_128.setTransform(53.375,448.875);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AnbQ8MAAAgh3IO3AAIAAJdIkQAAIAAG2ICpAAIAARkg");
	this.shape_129.setTransform(44,448.875);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AmJQ8MAAAgh3IMTAAIAAJdIjkAAIAAG2ICNAAIAARkg");
	this.shape_130.setTransform(35.425,448.875);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("Ak+Q8MAAAgh3IJ9AAIAAJdIi9AAIAAG2IB2AAIAARkg");
	this.shape_131.setTransform(27.675,448.875);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("Aj8Q8MAAAgh3IH4AAIAAJdIiZAAIAAG2IBgAAIAARkg");
	this.shape_132.setTransform(20.75,448.875);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AjBQ8MAAAgh3IGDAAIAAJdIh7AAIAAG2IBNAAIAARkg");
	this.shape_133.setTransform(14.625,448.875);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AiOQ8MAAAgh3IEdAAIAAJdIhgAAIAAG2IA8AAIAARkg");
	this.shape_134.setTransform(9.325,448.875);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AhjQ8MAAAgh3IDGAAIAAJdIhJAAIAAG2IAuAAIAARkg");
	this.shape_135.setTransform(4.85,448.875);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("Ag/Q8MAAAgh3IB/AAIAAJdIg2AAIAAG2IAjAAIAARkg");
	this.shape_136.setTransform(1.175,448.875);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgkQ8MAAAgh3IBJAAIAAJdIgoAAIAAG2IAaAAIAARkg");
	this.shape_137.setTransform(-1.675,448.875);

	var maskedShapeInstanceList = [this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_99}]},24).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_122}]},65).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_99}]},1).to({state:[]},1).wait(218));

	// Photo00
	this.instance_6 = new lib.g_pic00("single",0);
	var instance_6Filter_7 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_6.filters = [instance_6Filter_7];
	this.instance_6.cache(-2,-2,304,604);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({startPosition:0},23,cjs.Ease.get(0.8)).to({_off:true},105).wait(219));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_7).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 23,cjs.Ease.get(0.8)).wait(219));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance, startFrame:24, endFrame:24, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:0, endFrame:0, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:25, endFrame:47, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:48, endFrame:128, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:145, endFrame:145, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:146, endFrame:164, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:165, endFrame:346, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance, startFrame:346, endFrame:347, x:-27, y:-2, w:178, h:132});
	this.filterCacheList.push({instance: this.instance_1, startFrame:264, endFrame:264, x:-3, y:-3, w:191, h:52});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-3, y:-3, w:191, h:52});
	this.filterCacheList.push({instance: this.instance_1, startFrame:265, endFrame:278, x:-3, y:-3, w:191, h:52});
	this.filterCacheList.push({instance: this.instance_1, startFrame:279, endFrame:346, x:-3, y:-3, w:191, h:52});
	this.filterCacheList.push({instance: this.instance_1, startFrame:346, endFrame:347, x:-3, y:-3, w:191, h:52});
	this.filterCacheList.push({instance: this.instance_2, startFrame:245, endFrame:245, x:-2, y:-2, w:298, h:172});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:298, h:172});
	this.filterCacheList.push({instance: this.instance_2, startFrame:246, endFrame:259, x:-2, y:-2, w:298, h:172});
	this.filterCacheList.push({instance: this.instance_3, startFrame:157, endFrame:157, x:-2, y:-2, w:285, h:224});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:285, h:224});
	this.filterCacheList.push({instance: this.instance_3, startFrame:158, endFrame:171, x:-2, y:-2, w:285, h:224});
	this.filterCacheList.push({instance: this.instance_3, startFrame:211, endFrame:211, x:-2, y:-2, w:285, h:224});
	this.filterCacheList.push({instance: this.instance_3, startFrame:212, endFrame:227, x:-2, y:-2, w:285, h:224});
	this.filterCacheList.push({instance: this.instance_4, startFrame:127, endFrame:127, x:-2, y:-2, w:304, h:948});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-2, y:-2, w:304, h:948});
	this.filterCacheList.push({instance: this.instance_4, startFrame:128, endFrame:145, x:-2, y:-2, w:304, h:948});
	this.filterCacheList.push({instance: this.instance_5, startFrame:33, endFrame:33, x:-2, y:-2, w:256, h:224});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:256, h:224});
	this.filterCacheList.push({instance: this.instance_5, startFrame:34, endFrame:52, x:-2, y:-2, w:256, h:224});
	this.filterCacheList.push({instance: this.instance_5, startFrame:108, endFrame:108, x:-2, y:-2, w:256, h:224});
	this.filterCacheList.push({instance: this.instance_5, startFrame:109, endFrame:122, x:-2, y:-2, w:256, h:224});
	this.filterCacheList.push({instance: this.instance_6, startFrame:1, endFrame:23, x:-2, y:-2, w:304, h:604});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-2, w:304, h:604});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,150,300);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FAFAFA",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;