(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_1", frames: [[509,184,501,120],[0,184,507,120],[454,306,462,120],[0,306,452,132],[730,0,260,56],[730,58,260,56],[730,116,260,56],[0,0,728,90],[0,92,728,90]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_31 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7copy = function() {
	this.initialize(ss["index_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.g_title_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250.5,60);


(lib.g_title_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_30();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,253.5,60);


(lib.g_title_1_A = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,231,60);


(lib.g_SFU_SOC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.instance = new lib.CachedBmp_28();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AzhKBIAAzCIAAg/MAnDAAAIAAA/IAATCg");
	this.shape.setTransform(125,32.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-31.3,250,128.20000000000002);


(lib.g_pic04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Bitmap4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.g_pic00 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Bitmap7copy();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_25();
	this.instance.setTransform(0,1.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_26();
	this.instance_1.setTransform(0,1.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_27();
	this.instance_2.setTransform(0,1.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(2));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape.setTransform(65,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AqJifIUTAAIAAE/I0TAAg");
	this.shape_1.setTransform(65,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqJCgIAAk/IUTAAIAAE/g");
	this.shape_2.setTransform(65,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,132,34);


// stage content:
(lib.Farmer_728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg43AHCIAAuDMBxvAAAIAAODg");
	mask.setTransform(364,45);

	// Mask_Color
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_1.setTransform(364,45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_2.setTransform(364,45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.29)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_3.setTransform(364,45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.376)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_4.setTransform(364,45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.459)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_5.setTransform(364,45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.533)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_6.setTransform(364,45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_7.setTransform(364,45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.667)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_8.setTransform(364,45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.722)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_9.setTransform(364,45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.776)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_10.setTransform(364,45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.824)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_11.setTransform(364,45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.863)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_12.setTransform(364,45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.902)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_13.setTransform(364,45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.929)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_14.setTransform(364,45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.957)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_15.setTransform(364,45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.976)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_16.setTransform(364,45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.988)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_17.setTransform(364,45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.996)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_18.setTransform(364,45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_19.setTransform(364,45);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},346).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).wait(2));

	// Mask_Color
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_20.setTransform(364,45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.102)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_21.setTransform(364,45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.2)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_22.setTransform(364,45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,255,255,0.29)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_23.setTransform(364,45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.376)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_24.setTransform(364,45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(255,255,255,0.459)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_25.setTransform(364,45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.533)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_26.setTransform(364,45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_27.setTransform(364,45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.667)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_28.setTransform(364,45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(255,255,255,0.722)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_29.setTransform(364,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.776)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_30.setTransform(364,45);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.824)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_31.setTransform(364,45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.863)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_32.setTransform(364,45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.902)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_33.setTransform(364,45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.929)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_34.setTransform(364,45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.957)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_35.setTransform(364,45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.976)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_36.setTransform(364,45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.988)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_37.setTransform(364,45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.996)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_38.setTransform(364,45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_39.setTransform(364,45);

	var maskedShapeInstanceList = [this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_20}]},108).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[]},1).to({state:[]},237).wait(2));

	// Logo_SOC
	this.instance = new lib.g_SFU_SOC_Logo("single",0);
	this.instance.setTransform(-200,20,0.8,0.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).to({x:0},17,cjs.Ease.get(0.8)).to({_off:true},96).wait(10).to({_off:false,alpha:0},0).to({alpha:1},15,cjs.Ease.get(0.9)).to({_off:true},213).wait(1));

	// btn_CTA
	this.instance_1 = new lib.btn_CTA();
	this.instance_1.setTransform(339,54);
	this.instance_1._off = true;
	var instance_1Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_1.filters = [instance_1Filter_1];
	this.instance_1.cache(-3,-3,136,38);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(275).to({_off:false},0).to({y:49},17,cjs.Ease.get(1)).to({_off:true},74).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_1).wait(275).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 17,cjs.Ease.get(1)).wait(1));

	// Text_3
	this.instance_2 = new lib.g_title_3("synched",0);
	this.instance_2.setTransform(57.55,41.15,1,1,0,0,0,111.3,31.4);
	this.instance_2._off = true;
	var instance_2Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_2];
	this.instance_2.cache(-2,-2,255,64);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(256).to({_off:false},0).to({x:308.55},15,cjs.Ease.get(0.8)).to({_off:true},95).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_2).wait(256).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 15,cjs.Ease.get(0.8)).wait(1));

	// Text_3_Bg
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgUEYIAAkEIgCAAIAAkrIAsAAIAAEtIgSAAIAAECg");
	this.shape_40.setTransform(199.75,38.025);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Ah/EYIAAkEIgBAAIAAkrIEBAAIAAEtIiRAAIAAECg");
	this.shape_41.setTransform(210.6,38.025);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AjkEYIAAkEIgBAAIAAkrIHLAAIAAEtIkLAAIAAECg");
	this.shape_42.setTransform(220.95,38.025);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AlEEYIAAkEIgCAAIAAkrIKNAAIAAEtImAAAIAAECg");
	this.shape_43.setTransform(230.825,38.025);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AmgEYIAAkEIgCAAIAAkrINFAAIAAEtInuAAIAAECg");
	this.shape_44.setTransform(240.175,38.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("An3EYIAAkEIgBAAIAAkrIPyAAIAAEtIpXAAIAAECg");
	this.shape_45.setTransform(249.05,38.025);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("ApJEYIAAkEIgCAAIAAkrISXAAIAAEtIq6AAIAAECg");
	this.shape_46.setTransform(257.425,38.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AqWEYIAAkEIgCAAIAAkrIUxAAIAAEtIsWAAIAAECg");
	this.shape_47.setTransform(265.325,38.025);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("ArfEYIAAkEIgBAAIAAkrIXBAAIAAEtIttAAIAAECg");
	this.shape_48.setTransform(272.725,38.025);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AsiEYIAAkEIgCAAIAAkrIZJAAIAAEtIu/AAIAAECg");
	this.shape_49.setTransform(279.6,38.025);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AthEYIAAkEIgCAAIAAkrIbHAAIAAEtIwKAAIAAECg");
	this.shape_50.setTransform(286.025,38.025);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AubEYIAAkEIgCAAIAAkrIc7AAIAAEtIxQAAIAAECg");
	this.shape_51.setTransform(291.925,38.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AvQEYIAAkEIgCAAIAAkrIelAAIAAEtIyQAAIAAECg");
	this.shape_52.setTransform(297.375,38.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AwBEYIAAkEIgBAAIAAkrMAgFAAAIAAEtIzKAAIAAECg");
	this.shape_53.setTransform(302.3,38.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AwsEYIAAkEIgCAAIAAkrMAhdAAAIAAEtIz/AAIAAECg");
	this.shape_54.setTransform(306.725,38.025);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AxTEYIAAkEIgBAAIAAkrMAipAAAIAAEtI0sAAIAAECg");
	this.shape_55.setTransform(310.675,38.025);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("Ax1EYIAAkEIgBAAIAAkrMAjtAAAIAAEtI1VAAIAAECg");
	this.shape_56.setTransform(314.125,38.025);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AyREYIAAkEIgCAAIAAkrMAknAAAIAAEtI15AAIAAECg");
	this.shape_57.setTransform(317.1,38.025);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AyqEYIAAkEIgBAAIAAkrMAlXAAAIAAEtI2VAAIAAECg");
	this.shape_58.setTransform(319.55,38.025);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("Ay9EYIAAkEIgBAAIAAkrMAl+AAAIAAEtI2tAAIAAECg");
	this.shape_59.setTransform(321.5,38.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AzLEYIAAkEIgCAAIAAkrMAmbAAAIAAEtI2+AAIAAECg");
	this.shape_60.setTransform(323,38.025);

	var maskedShapeInstanceList = [this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_40}]},247).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[]},99).wait(1));

	// Text_2
	this.instance_3 = new lib.g_title_2("synched",0);
	this.instance_3.setTransform(57.55,51.15,1,1,0,0,0,111.3,31.4);
	this.instance_3._off = true;
	var instance_3Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_3];
	this.instance_3.cache(-2,-2,258,64);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(157).to({_off:false},0).to({x:308.55},14,cjs.Ease.get(0.8)).wait(48).to({startPosition:0},0).to({x:57.55},16,cjs.Ease.get(0.8)).to({_off:true},1).wait(131));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_3).wait(157).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 14,cjs.Ease.get(0.8)).wait(48).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 16,cjs.Ease.get(0.8)).wait(131));

	// Text_2_Bg
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgfEYIAAkEIgBAAIAAkrIAiAAIAAEEIAfAAIAAErg");
	this.shape_61.setTransform(203.325,48.025);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AiJEYIAAkEIgCAAIAAkrIDqAAIAAEEIAsAAIAAErg");
	this.shape_62.setTransform(213.95,48.025);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AjuEYIAAkEIgCAAIAAkrIGoAAIAAEEIA5AAIAAErg");
	this.shape_63.setTransform(224.1,48.025);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AlPEYIAAkEIgCAAIAAkrIJeAAIAAEEIBEAAIAAErg");
	this.shape_64.setTransform(233.75,48.025);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AmrEYIAAkEIgBAAIAAkrIMJAAIAAEEIBQAAIAAErg");
	this.shape_65.setTransform(242.925,48.025);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AoCEYIAAkEIgBAAIAAkrIOsAAIAAEEIBbAAIAAErg");
	this.shape_66.setTransform(251.625,48.025);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("ApUEYIAAkEIgCAAIAAkrIRHAAIAAEEIBlAAIAAErg");
	this.shape_67.setTransform(259.85,48.025);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AqhEYIAAkEIgCAAIAAkrITXAAIAAEEIBwAAIAAErg");
	this.shape_68.setTransform(267.575,48.025);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("ArpEYIAAkEIgCAAIAAkrIVfAAIAAEEIB4AAIAAErg");
	this.shape_69.setTransform(274.8,48.025);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AstEYIAAkEIgCAAIAAkrIXeAAIAAEEICBAAIAAErg");
	this.shape_70.setTransform(281.575,48.025);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AtsEYIAAkEIgCAAIAAkrIZUAAIAAEEICIAAIAAErg");
	this.shape_71.setTransform(287.85,48.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AumEYIAAkEIgCAAIAAkrIbAAAIAAEEICQAAIAAErg");
	this.shape_72.setTransform(293.65,48.025);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AvbEYIAAkEIgCAAIAAkrIckAAIAAEEICWAAIAAErg");
	this.shape_73.setTransform(298.95,48.025);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AwLEYIAAkEIgCAAIAAkrId+AAIAAEEICdAAIAAErg");
	this.shape_74.setTransform(303.8,48.025);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("Aw3EYIAAkEIgBAAIAAkrIfQAAIAAEEIChAAIAAErg");
	this.shape_75.setTransform(308.125,48.025);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AxdEYIAAkEIgCAAIAAkrMAgYAAAIAAEEICnAAIAAErg");
	this.shape_76.setTransform(312,48.025);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("Ax/EYIAAkEIgCAAIAAkrMAhYAAAIAAEEICrAAIAAErg");
	this.shape_77.setTransform(315.375,48.025);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AycEYIAAkEIgCAAIAAkrMAiPAAAIAAEEICuAAIAAErg");
	this.shape_78.setTransform(318.275,48.025);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("Ay0EYIAAkEIgCAAIAAkrMAi7AAAIAAEEICyAAIAAErg");
	this.shape_79.setTransform(320.7,48.025);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AzIEYIAAkEIgBAAIAAkrMAjgAAAIAAEEICzAAIAAErg");
	this.shape_80.setTransform(322.625,48.025);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AzWEYIAAkEIgCAAIAAkrMAj7AAAIAAEEIC2AAIAAErg");
	this.shape_81.setTransform(324.075,48.025);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AxnEYIAAkEIgBAAIAAkrMAgpAAAIAAEEICoAAIAAErg");
	this.shape_82.setTransform(312.725,48.025);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("Av8EYIAAkEIgCAAIAAkrIdiAAIAAEEICbAAIAAErg");
	this.shape_83.setTransform(301.9,48.025);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AuXEYIAAkEIgCAAIAAkrIalAAIAAEEICOAAIAAErg");
	this.shape_84.setTransform(291.625,48.025);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("As4EYIAAkEIgBAAIAAkrIXxAAIAAEEICCAAIAAErg");
	this.shape_85.setTransform(281.9,48.025);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("ArdEYIAAkEIgCAAIAAkrIVIAAIAAEEIB3AAIAAErg");
	this.shape_86.setTransform(272.725,48.025);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AqIEYIAAkEIgCAAIAAkrISpAAIAAEEIBsAAIAAErg");
	this.shape_87.setTransform(264.075,48.025);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("Ao4EYIAAkEIgCAAIAAkrIQTAAIAAEEIBiAAIAAErg");
	this.shape_88.setTransform(256,48.025);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AnvEYIAAkEIgBAAIAAkrIOIAAIAAEEIBZAAIAAErg");
	this.shape_89.setTransform(248.45,48.025);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AmpEYIAAkEIgCAAIAAkrIMHAAIAAEEIBQAAIAAErg");
	this.shape_90.setTransform(241.45,48.025);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AlqEYIAAkEIgBAAIAAkrIKPAAIAAEEIBIAAIAAErg");
	this.shape_91.setTransform(234.975,48.025);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AkwEYIAAkEIgBAAIAAkrIIiAAIAAEEIBBAAIAAErg");
	this.shape_92.setTransform(229.075,48.025);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Aj7EYIAAkEIgBAAIAAkrIG/AAIAAEEIA6AAIAAErg");
	this.shape_93.setTransform(223.7,48.025);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AjLEYIAAkEIgCAAIAAkrIFmAAIAAEEIA1AAIAAErg");
	this.shape_94.setTransform(218.875,48.025);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AihEYIAAkEIgCAAIAAkrIEXAAIAAEEIAwAAIAAErg");
	this.shape_95.setTransform(214.575,48.025);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("Ah9EYIAAkEIgBAAIAAkrIDSAAIAAEEIArAAIAAErg");
	this.shape_96.setTransform(210.85,48.025);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AhdEYIAAkEIgCAAIAAkrICXAAIAAEEIAnAAIAAErg");
	this.shape_97.setTransform(207.65,48.025);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AhDEYIAAkEIgBAAIAAkrIBlAAIAAEEIAkAAIAAErg");
	this.shape_98.setTransform(205,48.025);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AguEYIAAkEIgBAAIAAkrIA+AAIAAEEIAhAAIAAErg");
	this.shape_99.setTransform(202.9,48.025);

	var maskedShapeInstanceList = [this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_61,p:{x:203.325}}]},148).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},60).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_61,p:{x:201.325}}]},1).to({state:[]},2).wait(118));

	// Photo_4
	this.instance_4 = new lib.g_pic04("synched",0);
	this.instance_4._off = true;
	var instance_4Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_4];
	this.instance_4.cache(-2,-2,732,94);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(127).to({_off:false},0).to({startPosition:0},18,cjs.Ease.get(0.8)).to({_off:true},221).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_4).wait(127).to(new cjs.ColorFilter(1,1,1,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 18,cjs.Ease.get(0.8)).wait(1));

	// Text_1_A
	this.instance_5 = new lib.g_title_1_A("synched",0);
	this.instance_5.setTransform(20.05,49.8,1,1,0,0,0,111.3,31.4);
	this.instance_5._off = true;
	var instance_5Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_5.filters = [instance_5Filter_5];
	this.instance_5.cache(-2,-2,235,64);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39).to({_off:false},0).to({x:308.55},19,cjs.Ease.get(0.8)).wait(50).to({startPosition:0},0).to({x:20.05},14,cjs.Ease.get(0.8)).to({_off:true},6).wait(239));
	this.timeline.addTween(cjs.Tween.get(instance_5Filter_5).wait(39).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 19,cjs.Ease.get(0.8)).wait(50).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 14,cjs.Ease.get(0.8)).wait(239));

	// Text_1_A_Bg
	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgJEaIAAouIAAgFIAFAAIAAAFIAAD/IAOAAIAAEvg");
	this.shape_100.setTransform(188.5,46.525);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AhgEaIAAozICsAAIAAEEIAWAAIAAEvg");
	this.shape_101.setTransform(198.2,46.525);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("Ai0EaIAAozIFPAAIAAEEIAaAAIAAEvg");
	this.shape_102.setTransform(207.525,46.525);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AkFEaIAAozIHrAAIAAEEIAgAAIAAEvg");
	this.shape_103.setTransform(216.45,46.525);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AlSEaIAAozIKAAAIAAEEIAlAAIAAEvg");
	this.shape_104.setTransform(225,46.525);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AmcEaIAAozIMPAAIAAEEIAqAAIAAEvg");
	this.shape_105.setTransform(233.175,46.525);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AniEaIAAozIOWAAIAAEEIAvAAIAAEvg");
	this.shape_106.setTransform(240.975,46.525);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AokEaIAAozIQXAAIAAEEIAyAAIAAEvg");
	this.shape_107.setTransform(248.35,46.525);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("ApkEaIAAozISSAAIAAEEIA3AAIAAEvg");
	this.shape_108.setTransform(255.375,46.525);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AqgEaIAAozIUGAAIAAEEIA7AAIAAEvg");
	this.shape_109.setTransform(262.025,46.525);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("ArYEaIAAozIVzAAIAAEEIA+AAIAAEvg");
	this.shape_110.setTransform(268.3,46.525);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AsNEaIAAozIXZAAIAAEEIBCAAIAAEvg");
	this.shape_111.setTransform(274.15,46.525);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("As/EaIAAozIY5AAIAAEEIBFAAIAAEvg");
	this.shape_112.setTransform(279.65,46.525);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AtsEaIAAozIaSAAIAAEEIBIAAIAAEvg");
	this.shape_113.setTransform(284.75,46.525);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AuXEaIAAozIbkAAIAAEEIBLAAIAAEvg");
	this.shape_114.setTransform(289.5,46.525);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("Au+EaIAAozIcwAAIAAEEIBNAAIAAEvg");
	this.shape_115.setTransform(293.85,46.525);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AviEaIAAozId1AAIAAEEIBQAAIAAEvg");
	this.shape_116.setTransform(297.8,46.525);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AwDEaIAAozIe0AAIAAEEIBTAAIAAEvg");
	this.shape_117.setTransform(301.4,46.525);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AwfEaIAAozIfsAAIAAEEIBTAAIAAEvg");
	this.shape_118.setTransform(304.6,46.525);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("Aw5EaIAAozMAgdAAAIAAEEIBWAAIAAEvg");
	this.shape_119.setTransform(307.425,46.525);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AxOEaIAAozMAhGAAAIAAEEIBYAAIAAEvg");
	this.shape_120.setTransform(309.85,46.525);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AxhEaIAAozMAhrAAAIAAEEIBYAAIAAEvg");
	this.shape_121.setTransform(311.9,46.525);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AxwEaIAAozMAiIAAAIAAEEIBZAAIAAEvg");
	this.shape_122.setTransform(313.575,46.525);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("Ax8EaIAAouIAAgFMAifAAAIAAAFIAAD/IBaAAIAAEvg");
	this.shape_123.setTransform(314.875,46.525);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AwYEaIAAozIfdAAIAAEEIBUAAIAAEvg");
	this.shape_124.setTransform(303.75,46.525);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("Au4EaIAAozIckAAIAAEEIBNAAIAAEvg");
	this.shape_125.setTransform(293.125,46.525);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AtdEaIAAozIZ0AAIAAEEIBHAAIAAEvg");
	this.shape_126.setTransform(283.025,46.525);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AsGEaIAAozIXMAAIAAEEIBBAAIAAEvg");
	this.shape_127.setTransform(273.425,46.525);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("Aq0EaIAAozIUtAAIAAEEIA8AAIAAEvg");
	this.shape_128.setTransform(264.325,46.525);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("ApnEaIAAozISYAAIAAEEIA3AAIAAEvg");
	this.shape_129.setTransform(255.725,46.525);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AoeEaIAAozIQLAAIAAEEIAyAAIAAEvg");
	this.shape_130.setTransform(247.65,46.525);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AnaEaIAAozIOHAAIAAEEIAtAAIAAEvg");
	this.shape_131.setTransform(240.05,46.525);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AmaEaIAAozIMMAAIAAEEIApAAIAAEvg");
	this.shape_132.setTransform(232.975,46.525);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AlfEaIAAozIKZAAIAAEEIAlAAIAAEvg");
	this.shape_133.setTransform(226.4,46.525);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AkoEaIAAozIIvAAIAAEEIAiAAIAAEvg");
	this.shape_134.setTransform(220.35,46.525);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("Aj2EaIAAozIHOAAIAAEEIAfAAIAAEvg");
	this.shape_135.setTransform(214.775,46.525);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AjIEaIAAozIF2AAIAAEEIAbAAIAAEvg");
	this.shape_136.setTransform(209.725,46.525);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AifEaIAAozIEmAAIAAEEIAZAAIAAEvg");
	this.shape_137.setTransform(205.175,46.525);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("Ah7EaIAAozIDgAAIAAEEIAXAAIAAEvg");
	this.shape_138.setTransform(201.125,46.525);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AhbEaIAAozICiAAIAAEEIAVAAIAAEvg");
	this.shape_139.setTransform(197.6,46.525);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AhAEaIAAozIBuAAIAAEEIATAAIAAEvg");
	this.shape_140.setTransform(194.575,46.525);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgpEaIAAozIBBAAIAAEEIASAAIAAEvg");
	this.shape_141.setTransform(192.05,46.525);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgXEaIAAozIAfAAIAAEEIAQAAIAAEvg");
	this.shape_142.setTransform(190.025,46.525);

	var maskedShapeInstanceList = [this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_100}]},30).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_123}]},55).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_100}]},1).to({state:[]},1).wait(238));

	// Photo00
	this.instance_6 = new lib.g_pic00("single",0);
	var instance_6Filter_6 = new cjs.ColorFilter(1,1,1,1,255,255,255,0);
	this.instance_6.filters = [instance_6Filter_6];
	this.instance_6.cache(-2,-2,732,94);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({startPosition:0},23,cjs.Ease.get(0.8)).to({_off:true},105).wait(239));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_6).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 23,cjs.Ease.get(0.8)).wait(239));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_1, startFrame:275, endFrame:275, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:0, endFrame:0, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:276, endFrame:292, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:293, endFrame:366, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_1, startFrame:366, endFrame:367, x:-3, y:-3, w:136, h:38});
	this.filterCacheList.push({instance: this.instance_2, startFrame:256, endFrame:256, x:-2, y:-2, w:255, h:64});
	this.filterCacheList.push({instance: this.instance_2, startFrame:0, endFrame:0, x:-2, y:-2, w:255, h:64});
	this.filterCacheList.push({instance: this.instance_2, startFrame:257, endFrame:271, x:-2, y:-2, w:255, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:157, endFrame:157, x:-2, y:-2, w:258, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-2, y:-2, w:258, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:158, endFrame:171, x:-2, y:-2, w:258, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:219, endFrame:219, x:-2, y:-2, w:258, h:64});
	this.filterCacheList.push({instance: this.instance_3, startFrame:220, endFrame:235, x:-2, y:-2, w:258, h:64});
	this.filterCacheList.push({instance: this.instance_4, startFrame:127, endFrame:127, x:-2, y:-2, w:732, h:94});
	this.filterCacheList.push({instance: this.instance_4, startFrame:0, endFrame:0, x:-2, y:-2, w:732, h:94});
	this.filterCacheList.push({instance: this.instance_4, startFrame:128, endFrame:145, x:-2, y:-2, w:732, h:94});
	this.filterCacheList.push({instance: this.instance_5, startFrame:39, endFrame:39, x:-2, y:-2, w:235, h:64});
	this.filterCacheList.push({instance: this.instance_5, startFrame:0, endFrame:0, x:-2, y:-2, w:235, h:64});
	this.filterCacheList.push({instance: this.instance_5, startFrame:40, endFrame:58, x:-2, y:-2, w:235, h:64});
	this.filterCacheList.push({instance: this.instance_5, startFrame:108, endFrame:108, x:-2, y:-2, w:235, h:64});
	this.filterCacheList.push({instance: this.instance_5, startFrame:109, endFrame:122, x:-2, y:-2, w:235, h:64});
	this.filterCacheList.push({instance: this.instance_6, startFrame:1, endFrame:23, x:-2, y:-2, w:732, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-2, w:732, h:94});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,364,45);
// library properties:
lib.properties = {
	id: 'C38F8E925B074A239B4A15BB5DD6BAC8',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FAFAFA",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_1.png", id:"index_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C38F8E925B074A239B4A15BB5DD6BAC8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;