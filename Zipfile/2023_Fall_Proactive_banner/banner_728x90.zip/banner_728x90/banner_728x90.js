(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"banner_728x90_atlas_1", frames: [[0,0,561,186],[563,0,421,116],[730,322,162,81],[835,118,164,41],[0,372,164,41],[563,118,270,66],[730,186,270,66],[730,254,270,66],[0,188,728,90],[0,280,728,90]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_75 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["banner_728x90_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.gtext12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.instance = new lib.CachedBmp_75();
	this.instance.setTransform(-280.7,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-280.7,0,280.5,93);


(lib.gpic02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(718,0);

	this.instance_1 = new lib.Bitmap18();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1446,90);


(lib.g_txtSFUMedicalSchool = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_74();
	this.instance.setTransform(-210.6,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-210.6,0,210.5,58);


(lib.g_SFULogohorizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.instance = new lib.CachedBmp_71();
	this.instance.setTransform(90.4,20,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_72();
	this.instance_1.setTransform(90.4,20,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// icon
	this.instance_2 = new lib.CachedBmp_73();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,172.4,40.5);


(lib.btn_CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TEXT
	this.instance = new lib.CachedBmp_68();
	this.instance.setTransform(13,-1.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_69();
	this.instance_1.setTransform(13,-1.9,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_70();
	this.instance_2.setTransform(13,-1.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0633").s().p("AsfCbIAAk1IY/AAIAAE1g");
	this.shape.setTransform(80,15.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0633").ss(1,1,1).p("AsfiaIY/AAIAAE1I4/AAg");
	this.shape_1.setTransform(80,15.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AsfCbIAAk1IY/AAIAAE1g");
	this.shape_2.setTransform(80,15.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1.9,162,33.9);


(lib.g_study_dr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.instance = new lib.g_SFULogohorizontal("single",1);
	this.instance.setTransform(40,0.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// B_W
	this.instance_1 = new lib.Bitmap16();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


// stage content:
(lib.banner_728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {school:23};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Transition
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,51,51,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(90,90,90,0.188)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_1.setTransform(364,45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(125,125,125,0.361)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_2.setTransform(364,45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(155,155,155,0.51)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_3.setTransform(364,45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(182,182,182,0.643)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_4.setTransform(364,45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(205,205,205,0.753)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_5.setTransform(364,45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(223,223,223,0.843)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_6.setTransform(364,45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(238,238,238,0.918)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_7.setTransform(364,45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(248,248,248,0.969)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_8.setTransform(364,45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_9.setTransform(364,45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(69,69,69,0.086)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_10.setTransform(364,45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(86,86,86,0.173)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_11.setTransform(364,45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(102,102,102,0.251)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_12.setTransform(364,45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(118,118,118,0.329)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_13.setTransform(364,45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(133,133,133,0.4)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_14.setTransform(364,45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(146,146,146,0.467)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_15.setTransform(364,45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(160,160,160,0.533)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_16.setTransform(364,45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(172,172,172,0.592)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_17.setTransform(364,45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(183,183,183,0.647)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_18.setTransform(364,45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(194,194,194,0.702)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_19.setTransform(364,45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(204,204,204,0.749)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_20.setTransform(364,45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(213,213,213,0.792)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_21.setTransform(364,45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(221,221,221,0.831)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_22.setTransform(364,45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(228,228,228,0.867)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_23.setTransform(364,45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(235,235,235,0.902)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_24.setTransform(364,45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(240,240,240,0.929)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_25.setTransform(364,45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(245,245,245,0.953)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_26.setTransform(364,45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(249,249,249,0.973)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_27.setTransform(364,45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(253,253,253,0.988)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_28.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},97).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[]},1).to({state:[{t:this.shape}]},129).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_9}]},1).to({state:[]},2).wait(14));

	// Transition
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_29.setTransform(364,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.914)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_30.setTransform(364,45);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0.827)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_31.setTransform(364,45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.749)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_32.setTransform(364,45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.671)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_33.setTransform(364,45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.6)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_34.setTransform(364,45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.533)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_35.setTransform(364,45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.467)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_36.setTransform(364,45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.408)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_37.setTransform(364,45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.353)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_38.setTransform(364,45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.298)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_39.setTransform(364,45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.251)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_40.setTransform(364,45);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.208)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_41.setTransform(364,45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.169)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_42.setTransform(364,45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.133)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_43.setTransform(364,45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.098)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_44.setTransform(364,45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.071)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_45.setTransform(364,45);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.047)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_46.setTransform(364,45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.027)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_47.setTransform(364,45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.012)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_48.setTransform(364,45);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_49.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29}]}).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[]},1).to({state:[]},86).wait(165));

	// Red_Bg__Animate__Mask_ (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_23 = new cjs.Graphics().p("AgxHCIAAuDIBjAAIAAODg");
	var mask_graphics_24 = new cjs.Graphics().p("Ak5HCIAAuDIJzAAIAAODg");
	var mask_graphics_25 = new cjs.Graphics().p("AovHCIAAuDIRfAAIAAODg");
	var mask_graphics_26 = new cjs.Graphics().p("AsVHCIAAuDIYrAAIAAODg");
	var mask_graphics_27 = new cjs.Graphics().p("AvpHCIAAuDIfUAAIAAODg");
	var mask_graphics_28 = new cjs.Graphics().p("AyuHCIAAuDMAldAAAIAAODg");
	var mask_graphics_29 = new cjs.Graphics().p("A1gHCIAAuDMArBAAAIAAODg");
	var mask_graphics_30 = new cjs.Graphics().p("A4CHCIAAuDMAwFAAAIAAODg");
	var mask_graphics_31 = new cjs.Graphics().p("A6SHCIAAuDMA0lAAAIAAODg");
	var mask_graphics_32 = new cjs.Graphics().p("A8SHCIAAuDMA4lAAAIAAODg");
	var mask_graphics_33 = new cjs.Graphics().p("A+AHCIAAuDMA8BAAAIAAODg");
	var mask_graphics_34 = new cjs.Graphics().p("A/eHCIAAuDMA+9AAAIAAODg");
	var mask_graphics_35 = new cjs.Graphics().p("EggqAHCIAAuDMBBVAAAIAAODg");
	var mask_graphics_36 = new cjs.Graphics().p("EghmAHCIAAuDMBDNAAAIAAODg");
	var mask_graphics_37 = new cjs.Graphics().p("EgiRAHCIAAuDMBEjAAAIAAODg");
	var mask_graphics_38 = new cjs.Graphics().p("EgiqAHCIAAuDMBFVAAAIAAODg");
	var mask_graphics_39 = new cjs.Graphics().p("EgizAHCIAAuDMBFnAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(23).to({graphics:mask_graphics_23,x:-5,y:45}).wait(1).to({graphics:mask_graphics_24,x:22.575,y:45}).wait(1).to({graphics:mask_graphics_25,x:48.375,y:45}).wait(1).to({graphics:mask_graphics_26,x:72.4,y:45}).wait(1).to({graphics:mask_graphics_27,x:94.65,y:45}).wait(1).to({graphics:mask_graphics_28,x:115.1,y:45}).wait(1).to({graphics:mask_graphics_29,x:133.8,y:45}).wait(1).to({graphics:mask_graphics_30,x:150.7,y:45}).wait(1).to({graphics:mask_graphics_31,x:165.825,y:45}).wait(1).to({graphics:mask_graphics_32,x:179.175,y:45}).wait(1).to({graphics:mask_graphics_33,x:190.725,y:45}).wait(1).to({graphics:mask_graphics_34,x:200.5,y:45}).wait(1).to({graphics:mask_graphics_35,x:208.525,y:45}).wait(1).to({graphics:mask_graphics_36,x:214.75,y:45}).wait(1).to({graphics:mask_graphics_37,x:219.2,y:45}).wait(1).to({graphics:mask_graphics_38,x:221.85,y:45}).wait(1).to({graphics:mask_graphics_39,x:222.75,y:45}).wait(233));

	// SFU_Logo
	this.instance = new lib.g_SFULogohorizontal("single",0);
	this.instance.setTransform(40,0.1,1,1,0,0,0,0.1,0.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(23).to({_off:false},0).to({_off:true},84).wait(165));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_41 = new cjs.Graphics().p("EgizAHCIAAuDMBFnAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(41).to({graphics:mask_1_graphics_41,x:222.75,y:45}).wait(231));

	// Text_SFU_Medical_School
	this.instance_1 = new lib.g_txtSFUMedicalSchool("synched",0);
	this.instance_1.setTransform(483.8,113,1,1,0,0,0,-162.3,77);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(41).to({_off:false},0).to({x:287.05},18,cjs.Ease.get(1)).to({_off:true},48).wait(165));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_23 = new cjs.Graphics().p("Eg43AHCIAAuDMBxvAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(23).to({graphics:mask_2_graphics_23,x:364,y:45}).wait(249));

	// Red_Bg__Animate_
	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#CC0633").s().p("AgxHCIAAuDIBjAAIAAODg");
	this.shape_50.setTransform(-5,45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#CC0633").s().p("Ak5HCIAAuDIJzAAIAAODg");
	this.shape_51.setTransform(22.575,45);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#CC0633").s().p("AovHCIAAuDIRfAAIAAODg");
	this.shape_52.setTransform(48.375,45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#CC0633").s().p("AsVHCIAAuDIYrAAIAAODg");
	this.shape_53.setTransform(72.4,45);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#CC0633").s().p("AvpHCIAAuDIfUAAIAAODg");
	this.shape_54.setTransform(94.65,45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#CC0633").s().p("AyuHCIAAuDMAldAAAIAAODg");
	this.shape_55.setTransform(115.1,45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#CC0633").s().p("A1gHCIAAuDMArBAAAIAAODg");
	this.shape_56.setTransform(133.8,45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#CC0633").s().p("A4CHCIAAuDMAwFAAAIAAODg");
	this.shape_57.setTransform(150.7,45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#CC0633").s().p("A6SHCIAAuDMA0lAAAIAAODg");
	this.shape_58.setTransform(165.825,45);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#CC0633").s().p("A8SHCIAAuDMA4lAAAIAAODg");
	this.shape_59.setTransform(179.175,45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#CC0633").s().p("A+AHCIAAuDMA8BAAAIAAODg");
	this.shape_60.setTransform(190.725,45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#CC0633").s().p("A/eHCIAAuDMA+9AAAIAAODg");
	this.shape_61.setTransform(200.5,45);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#CC0633").s().p("EggqAHCIAAuDMBBVAAAIAAODg");
	this.shape_62.setTransform(208.525,45);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#CC0633").s().p("EghmAHCIAAuDMBDNAAAIAAODg");
	this.shape_63.setTransform(214.75,45);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#CC0633").s().p("EgiRAHCIAAuDMBEjAAAIAAODg");
	this.shape_64.setTransform(219.2,45);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#CC0633").s().p("EgiqAHCIAAuDMBFVAAAIAAODg");
	this.shape_65.setTransform(221.85,45);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#CC0633").s().p("EgizAHCIAAuDMBFnAAAIAAODg");
	this.shape_66.setTransform(222.75,45);

	var maskedShapeInstanceList = [this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_50}]},23).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[]},68).wait(165));

	// Photo
	this.instance_2 = new lib.g_study_dr("single",0);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({_off:true},106).wait(165));

	// Mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_107 = new cjs.Graphics().p("Eg43AHCIAAuDMBxvAAAIAAODg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(107).to({graphics:mask_3_graphics_107,x:364,y:45}).wait(165));

	// CTA
	this.instance_3 = new lib.btn_CTA();
	this.instance_3.setTransform(122.65,88.95,1,1,0,0,0,83,25.5);
	this.instance_3._off = true;
	var instance_3Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_3.filters = [instance_3Filter_1];
	this.instance_3.cache(-3,-4,166,38);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.btn_CTA(), 3);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(143).to({_off:false},0).to({y:78.95},21,cjs.Ease.get(0.9)).to({_off:true},93).wait(15));
	this.timeline.addTween(cjs.Tween.get(instance_3Filter_1).wait(143).to(new cjs.ColorFilter(0,0,0,1,255,255,255,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 21,cjs.Ease.get(0.9)).wait(15));

	// SFU_Logo
	this.instance_4 = new lib.g_SFULogohorizontal("single",1);
	this.instance_4.setTransform(40,-48.95,1,1,0,0,0,0.1,0);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(143).to({_off:false},0).to({regY:0.1,y:0.1},20,cjs.Ease.get(1)).to({_off:true},94).wait(15));

	// Text
	this.instance_5 = new lib.gtext12("synched",0);
	this.instance_5.setTransform(872.8,47,1,1,0,0,0,-144.7,45);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(114).to({_off:false},0).to({x:585.05},15,cjs.Ease.get(0.9)).to({_off:true},128).wait(15));

	// REd_Bg
	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#CC0633").s().p("AgaG+IAAncIAbAAIAAmfIAaAAIAAN7g");
	this.shape_67.setTransform(732.525,45.125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CC0633").s().p("AiyG+IAAncIBOAAIAAmfIEXAAIAAN7g");
	this.shape_68.setTransform(716.925,45.125);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CC0633").s().p("AlCG+IAAncIB+AAIAAmfIIGAAIAAN7g");
	this.shape_69.setTransform(702.25,45.125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#CC0633").s().p("AnIG+IAAncICpAAIAAmfILoAAIAAN7g");
	this.shape_70.setTransform(688.475,45.125);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#CC0633").s().p("ApGG+IAAncIDTAAIAAmfIO6AAIAAN7g");
	this.shape_71.setTransform(675.55,45.125);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#CC0633").s().p("Aq8G+IAAncID6AAIAAmfIR+AAIAAN7g");
	this.shape_72.setTransform(663.55,45.125);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#CC0633").s().p("AsoG+IAAncIEdAAIAAmfIU0AAIAAN7g");
	this.shape_73.setTransform(652.425,45.125);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#CC0633").s().p("AuMG+IAAncIE+AAIAAmfIXbAAIAAN7g");
	this.shape_74.setTransform(642.175,45.125);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#CC0633").s().p("AvnG+IAAncIFcAAIAAmfIZzAAIAAN7g");
	this.shape_75.setTransform(632.85,45.125);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#CC0633").s().p("Aw6G+IAAncIF4AAIAAmfIb9AAIAAN7g");
	this.shape_76.setTransform(624.4,45.125);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#CC0633").s().p("AyEG+IAAncIGQAAIAAmfId4AAIAAN7g");
	this.shape_77.setTransform(616.8,45.125);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CC0633").s().p("AzFG+IAAncIGlAAIAAmfIfmAAIAAN7g");
	this.shape_78.setTransform(610.15,45.125);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#CC0633").s().p("Az9G+IAAncIG3AAIAAmfMAhEAAAIAAN7g");
	this.shape_79.setTransform(604.35,45.125);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#CC0633").s().p("A0sG+IAAncIHGAAIAAmfMAiTAAAIAAN7g");
	this.shape_80.setTransform(599.45,45.125);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#CC0633").s().p("A1UG+IAAncIHUAAIAAmfMAjVAAAIAAN7g");
	this.shape_81.setTransform(595.425,45.125);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#CC0633").s().p("A1yG+IAAncIHeAAIAAmfMAkHAAAIAAN7g");
	this.shape_82.setTransform(592.325,45.125);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#CC0633").s().p("A2IG+IAAncIHlAAIAAmfMAksAAAIAAN7g");
	this.shape_83.setTransform(590.1,45.125);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#CC0633").s().p("A2VG+IAAncIHpAAIAAmfMAlCAAAIAAN7g");
	this.shape_84.setTransform(588.775,45.125);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#CC0633").s().p("A2ZG+IAAncIHqAAIAAmfMAlJAAAIAAN7g");
	this.shape_85.setTransform(588.325,45.125);

	var maskedShapeInstanceList = [this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_67}]},107).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[]},132).wait(15));

	// Layer_1
	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#F2F2F2").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_86.setTransform(114.25,45);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(242,242,242,0.976)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_87.setTransform(114.25,45);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(242,242,242,0.953)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_88.setTransform(114.25,45);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(242,242,242,0.929)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_89.setTransform(114.25,45);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(242,242,242,0.906)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_90.setTransform(114.25,45);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(242,242,242,0.882)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_91.setTransform(114.25,45);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(242,242,242,0.859)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_92.setTransform(114.25,45);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(242,242,242,0.835)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_93.setTransform(114.25,45);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(242,242,242,0.816)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_94.setTransform(114.25,45);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(242,242,242,0.792)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_95.setTransform(114.25,45);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(242,242,242,0.769)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_96.setTransform(114.25,45);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(242,242,242,0.745)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_97.setTransform(114.25,45);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(242,242,242,0.722)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_98.setTransform(114.25,45);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(242,242,242,0.698)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_99.setTransform(114.25,45);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(242,242,242,0.675)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_100.setTransform(114.25,45);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(242,242,242,0.651)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_101.setTransform(114.25,45);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(242,242,242,0.627)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_102.setTransform(114.25,45);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("rgba(242,242,242,0.604)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_103.setTransform(114.25,45);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("rgba(242,242,242,0.58)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_104.setTransform(114.25,45);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("rgba(242,242,242,0.557)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_105.setTransform(114.25,45);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("rgba(242,242,242,0.533)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_106.setTransform(114.25,45);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("rgba(242,242,242,0.51)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_107.setTransform(114.25,45);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("rgba(242,242,242,0.49)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_108.setTransform(114.25,45);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("rgba(242,242,242,0.467)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_109.setTransform(114.25,45);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("rgba(242,242,242,0.443)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_110.setTransform(114.25,45);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("rgba(242,242,242,0.42)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_111.setTransform(114.25,45);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("rgba(242,242,242,0.396)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_112.setTransform(114.25,45);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(242,242,242,0.373)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_113.setTransform(114.25,45);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("rgba(242,242,242,0.349)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_114.setTransform(114.25,45);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("rgba(242,242,242,0.325)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_115.setTransform(114.25,45);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("rgba(242,242,242,0.302)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_116.setTransform(114.25,45);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("rgba(242,242,242,0.278)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_117.setTransform(114.25,45);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("rgba(242,242,242,0.255)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_118.setTransform(114.25,45);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("rgba(242,242,242,0.231)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_119.setTransform(114.25,45);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("rgba(242,242,242,0.208)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_120.setTransform(114.25,45);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("rgba(242,242,242,0.184)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_121.setTransform(114.25,45);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("rgba(242,242,242,0.165)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_122.setTransform(114.25,45);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("rgba(242,242,242,0.141)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_123.setTransform(114.25,45);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("rgba(242,242,242,0.118)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_124.setTransform(114.25,45);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("rgba(242,242,242,0.094)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_125.setTransform(114.25,45);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("rgba(242,242,242,0.071)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_126.setTransform(114.25,45);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("rgba(242,242,242,0.047)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_127.setTransform(114.25,45);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("rgba(242,242,242,0.024)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_128.setTransform(114.25,45);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("rgba(242,242,242,0)").s().p("Ax2HCIAAuDMAjKAAAIAjODg");
	this.shape_129.setTransform(114.25,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_86}]},107).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[]},1).wait(121));

	// Pic_Dad_Girl
	this.instance_6 = new lib.gpic02("synched",0);
	this.instance_6.setTransform(703,45,1,1,0,0,0,723,45);
	this.instance_6._off = true;
	var instance_6Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_6.filters = [instance_6Filter_2];
	this.instance_6.cache(-2,-2,1450,94);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(107).to({_off:false},0).to({startPosition:0},55,cjs.Ease.get(0.9)).to({_off:true},95).wait(15));
	this.timeline.addTween(cjs.Tween.get(instance_6Filter_2).wait(107).to(new cjs.ColorFilter(0.75,0.75,0.75,1,180,180,180,0), 0).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 55,cjs.Ease.get(0.9)).wait(15));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_3, startFrame:143, endFrame:143, x:-3, y:-4, w:166, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:0, endFrame:0, x:-3, y:-4, w:166, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:144, endFrame:164, x:-3, y:-4, w:166, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:165, endFrame:257, x:-3, y:-4, w:166, h:38});
	this.filterCacheList.push({instance: this.instance_3, startFrame:257, endFrame:272, x:-3, y:-4, w:166, h:38});
	this.filterCacheList.push({instance: this.instance_6, startFrame:107, endFrame:107, x:-2, y:-2, w:1450, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:0, endFrame:0, x:-2, y:-2, w:1450, h:94});
	this.filterCacheList.push({instance: this.instance_6, startFrame:108, endFrame:162, x:-2, y:-2, w:1450, h:94});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1426,90);
// library properties:
lib.properties = {
	id: 'B8909188F943443AB461DBFA97228CEF',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/banner_728x90_atlas_1.png", id:"banner_728x90_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B8909188F943443AB461DBFA97228CEF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;